<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$qq=$_REQUEST["qq"]?:$uin;
$msg=$_REQUEST["msg"]?:"来源于小白API";
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$jcry=date("Y.m.d");//现在时间
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Host: h5.qzone.qq.com","accept: application/json","user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","content-type: application/x-www-form-urlencoded","origin: https://user.qzone.qq.com","referer: https://user.qzone.qq.com/","accept-encoding: gzip, deflate","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$url="https://user.qzone.qq.com/p/h5/checkinv2/pc";
$data=curl($url,$data,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
$s=count($json["content"]);
$s=mt_rand(0,$s-1);
$y=$json["content"][$s]["desc"];
$img=$json["content"][$s]["previewBg"];
$y=file_get_contents("http://api.klizi.cn/API/other/yy.php");
$data='{"html":"\n                <!DOCTYPE html>\n                <html style=\"background:transparent;\">\n                    <head>\n                        <meta charset=\"UTF-8\">\n                        <link rel=\"stylesheet\" type=\"text/css\" href=\"http://qzonestyle.gtimg.cn/touch/proj-qzone-app/checkin-pc/index.css\">\n                    </head>\n                    <body style=\"background:transparent;\">\n                        <div class=\"checkIn-days\" style=\"background: transparent;\"><div class=\"template-area screenshot dark style-ten\"><div class=\"pic-area j-pic-area\"><div class=\"upload-pic j-upload-pic\"><img src=\"'.$img.'\"></div> <div class=\"operate-area j-operate-area\" style=\"background-image: url(&quot;data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7&quot;);\"></div> <div class=\"camera-wrap\"><i class=\"icon icon-camera\"></i></div></div> <div class=\"date-area\"><div class=\"month\">SEP /</div><div class=\"date-detail\">'.$jcry.'</div></div> <div class=\"word-area j-word-area edit-state\"><div class=\"word-main\"><p class=\"word j-word\">'.$y.'</p> <textarea class=\"wordTextarea\" style=\"overflow: hidden; line-height: 44px;\">'.$y.'</textarea><textarea class=\"wordTextarea\" style=\"overflow: hidden; visibility: hidden; position: absolute;\"></textarea></div> <div class=\"word-side j-edit-btn\"><button class=\"btn-refresh\"><i class=\"icon-refresh\"></i></button></div></div></div></div>\n                    </body>\n                </html>","viewport":{"width":820,"height":820},"type":"png","cache":true}';
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Content-Type: application/json; charset=UTF-8","Host: h5.qzone.qq.com");
$url='https://h5.qzone.qq.com/services/picGenerator?cmd=stringToUrl&t=0.25740329992233';
$img=curl($url,$data,$header);
$img=json_decode($img,true);
$img=urlencode($img["picUrl"]["sOriUrl"]);
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Host: h5.qzone.qq.com","accept: application/json","user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","content-type: application/x-www-form-urlencoded","origin: https://user.qzone.qq.com","referer: https://user.qzone.qq.com/","accept-encoding: gzip, deflate","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$img=$img.'&bo=NAM0AzQDNAMDEDU!&s_width=400';
$dat='uin='.$uin.'&content='.urlencode($msg).'&issynctoweibo=0&isWinPhone=2&richtype=1&richval='.urlencode('aurl='.$img.'&s_width=400&s_height=300&murl='.$img.'&m_width=600&m_length=450&burl='.$img.'&b_width=800&b_length=600&pic_type=10&templateId=1&who=2').'&sourceName=&frames=10&source.subtype=33&extend_info.checkinfall='.urlencode('{"uuid":"'.msectime().'"}').'&right_info.ugc_right=1&stored_extend_info.is_diy=1&stored_extend_info.event_tags='.urlencode('小白API: ".ym."').'&stored_extend_info.pic_jump_type=0&stored_extend_info.signin_group_id=1&stored_extend_info.signin_seal_id=345&stored_extend_info.signin_op=1&stored_extend_info.sign_content='.urlencode($y).'&format=json&inCharset=utf-8&outCharset=utf-8';
$url="https://h5.qzone.qq.com/webapp/json/publishDiyMood/publishmood?qzonetoken=undefined&t=0.5169890717679406&g_tk=".getGTK($pskey);
$data=curl($url,$dat,$header);
$data=str_replace('_Callback(','',$data);
$data=str_replace(');','',$data);
$json=json_decode($data,true);
print_r($data);

function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    
    return $msectime;
}




