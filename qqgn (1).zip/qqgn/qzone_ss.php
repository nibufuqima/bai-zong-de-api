<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: Cookie:uin=o1242619315;p_uin=o1242619315;p_skey=lhbH1HhQis8Ui-VPSwP2A5M5H0SBZvVu2LHXputXGnw_;skey=@Yk6sodmj2","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/ic2.qzone.qq.com/cgi-bin/feeds/feeds3_html_more?uin=1242619315&scope=0&view=1&daylist=&uinlist=&gid=&flag=1&filter=all&applist=all&refresh=0&aisortEndTime=0&aisortOffset=0&getAisort=0&aisortBeginTime=0&pagenum=1&externparam=undefined&firstGetGroup=0&icServerTime=0&mixnocache=0&scene=0&begintime=undefined&count=10&dayspac=undefined&sidomain=qzonestyle.gtimg.cn&useutf8=1&outputhtmlfeed=1&rd=0.7121387738901408&usertime=1628826648128&windowId=0.05717649513780798&g_tk=2001743040&g_tk=2001743040";
$data=curl($url,$data,$header);
$data=str_replace('_Callback(','',$data);
$data=str_replace(');','',$data);
$json=json_decode($data,true);
$Dat=$_REQUEST["data"];
//if($Dat=="json"){
print_r($data);
//}else{
