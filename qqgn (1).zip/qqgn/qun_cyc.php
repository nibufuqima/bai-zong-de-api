<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$switch=$_REQUEST["switch"];
$uin=$_REQUEST["uin"];
$qq=$_REQUEST["qq"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://zb.vip.qq.com/srf/QC_UniBusinessLogicServer_UniBusinessLogicObj/uniSet?g_tk=".getGTK($skey);
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Host: zb.vip.qq.com","Connection: keep-alive","Accept: application/json, text/plain, */*","traceparent: 00-c911eeac0335cc998ddfb25972a04215-158c6e38071c4f44-01","User-Agent: Mozilla/5.0 (Linux; Android 12; Redmi K30 Build/SKQ1.210908.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/046011 Mobile Safari/537.36 V1_AND_SQ_8.8.88_2770_YYB_D A_8088800 QQ/8.8.88.7830 NetType/4G WebP/0.3.0 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537117930","Content-Type: application/json;charset=UTF-8","Origin: https://zb.vip.qq.com","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Referer: https://zb.vip.qq.com/v2/pages/nudgeMall?_wv=2&actionId=1","Accept-Encoding: gzip, deflate, br","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Q-UA2: QV=3&PL=ADR&PR=QQ&PP=com.tencent.mobileqq&PPVN=8.8.88&TBSVC=44166&CO=BK&COVC=046011&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO=Unknown&RL=1080*2261&OS=12&API=31","Q-GUID: d8214e8260d8ba6283e3ba7813b788cb","q-header-ctrl: 3","Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b");
$data='{"stLogin":{"iKeyType":1,"iOpplat":2,"lUin":'.$uin.',"sClientIp":"","sClientVer":"8.8.88","sSKey":"'.$skey.'"},"stUniBusinessItem":{"appid":46,"itemid":1},"stNudge":{"ischangeswitch":1,"isclose":'.$switch.'}}';
$data=curl($url,$data,$header);
print_r($data);