<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$imei=$_REQUEST["imei"];
$Dat=$_REQUEST["data"];
$type=$_REQUEST["type"]?:"1";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Content-Type: application/json; charset=","UTF-8Host: ti.qq.com");
$url="https://ti.qq.com/hybrid-h5/api/json/daily_attendance/WritePushRemind";
$data='{"uin":"'.$uin.'","op":1}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$ret=$json["ret"];
if($Dat=="json"){
print_r($data);
}else{
if($ret=="-3000"){
print_r("Cookie已失效!请重新获取!");
}elseif($ret=="0"){
print_r("打卡报名成功!");
}}
