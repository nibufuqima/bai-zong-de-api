<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$group=$_REQUEST['group'];
$type=$_REQUEST["type"]?:"1";
$qq=$_REQUEST["qq"];
$time=$_REQUEST["time"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qinfo.clt.qq.com/cgi-bin/qun_info/set_group_shutup";
$header=array("Cookie: RK=ZJbgfBX7mx; pgv_pvid=893247738; ptcz=6f33856d6cd1038b6cdd2029fc8a63754a49cf613a0078893256c870c682327f; p_skey=".$pskey."; p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; traceid=a9cba1831b");
if($type=="1"){
$data="src=qinfo_v3&_ti=".msectime()."&gc=".$group."&bkn=".getGTK($skey)."&all_shutup=4294967295";
}elseif($type=="2"){
$data="src=qinfo_v3&_ti=".msectime()."&gc=".$group."&bkn=".getGTK($skey)."&all_shutup=0";
}elseif($type=="3"){
$data='shutup_list='.urlencode('[{"uin":'.$qq.',"t":'.$time.'}]').'&gc='.$group.'&bkn='.getGTK($skey).'&src=qinfo_v3&_ti='.msectime();
}
$data=curl($url,$data,$header);
print_r($data);
function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    
    return $msectime;
}
