<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$url=$_REQUEST["url"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$group=$_REQUEST["group"];
getImg($url,'2.jpg');
define('FORM_BOUNDARY', uniqid('----WebKitFormBoundary'));
define('FORM_HYPHENS', '--');
define('FORM_EOL', "\r\n");
define('FORM_IMG_FIELD_NAME', 'img[]');
global $post_data;
         $value="2.jpg";
         $image_type = getimagesize($value)[2];
         $mime_type = image_type_to_mime_type($image_type);
         $post_data .= "bkn=".GetBkn($skey)."&source=troopNotice&m=0". FORM_EOL . FORM_EOL
               .FORM_HYPHENS . FORM_BOUNDARY . FORM_EOL
               . "Content-Disposition: form-data; name=\"image\"; filename=\"blob\"" . FORM_EOL
               . "Content-Type: multipart/form-data" . FORM_EOL . FORM_EOL
               . file_get_contents($value) . FORM_EOL.FORM_HYPHENS . FORM_BOUNDARY ."--". FORM_EOL;
               $url="https://web.qun.qq.com/cgi-bin/announce/upload_img";
             $header=array("User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.131 Mobile Safari/537.36","content-type: multipart/form-data; boundary=". FORM_BOUNDARY."","Connection: Keep-Alive","Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey.";pvid=2882679314;qq_locale_id=2052;traceid=8df6b94c9e;_tc_unionid=c4e61a57-1932-4ffb-842a-fdfd625dd61f;traceid=73b9c2b9b9;idt=1641095449");
          $data=curl($url,$post_data,$header);
          print_r($data);
          function getImg($url, $filename){
    //去除URL连接上面可能的引号
    $hander = curl_init();
    $fp = fopen($filename, 'wb');
    curl_setopt($hander, CURLOPT_URL, $url);
    curl_setopt($hander, CURLOPT_FILE, $fp);
    curl_setopt($hander, CURLOPT_HEADER, 0);
    curl_setopt($hander, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($hander, CURLOPT_TIMEOUT, 60);
    curl_exec($hander);
    curl_close($hander);
    fclose($fp);
    return true;
}