接口地址:".ym."/API/qqgn/yqk.php?uin=&skey=&pskey=
pskey来源:ti.qq.com
①type=open
允许成员打开一起看
".ym."/API/qqgn/yqk.php?uin=&skey=&pskey=&type=open&group=1021789873
②type=close
拒绝成员打开一起看
".ym."/API/qqgn/yqk.php?uin=&skey=&pskey=&type=close&group=1021789873
③type=stop
停止一起看
携带参数roomId=(开启一起看返回数据有roomId值)
".ym."/API/qqgn/yqk.php?uin=&skey=&pskey=&type=stop&group=1021789873&roomId=
④type=list
一起看列表
".ym."/API/qqgn/yqk.php?uin=&skey=&pskey=&type=list&group=1021789873
⑤type=list&msg=
一起看类型(msg不能为空)
".ym."/API/qqgn/yqk.php?uin=&skey=&pskey=&type=list&msg=游戏&group=1021789873
⑥type=list&msg=&n=
一起看类型列表(msg，n不能为空)
".ym."/API/qqgn/yqk.php?uin=&skey=&pskey=&type=list&msg=游戏&group=1021789873&n=1
⑥type=start&n=&m=&msg=
开启一起看(msg，n，m不能为空)
m为集数
n为类型中的选择
".ym."/API/qqgn/yqk.php?uin=&skey=&pskey=&type=start&msg=游戏&group=1021789873&n=1&m=3


