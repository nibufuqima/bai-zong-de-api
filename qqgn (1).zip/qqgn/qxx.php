<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$time=time();
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qinfo.clt.qq.com/cgi-bin/qun_info/get_group_info_all?gc=".$group."&bkn=".getGTK($skey)."&src=qinfo_v3&_ti=".msectime();
$header=array("Cookie: RK=wD2p2BhUmd; ts_uid=5731736283; pgv_pvid=3749191880; ptcz=66121c257260068a1f4e605d027b92b229dfdbc9d9ff8a9270bc808c2240c8c3; traceid=aaeca99da3; p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; o_cookie=".$uin.";","Host: qinfo.clt.qq.com","Connection: keep-alive","Accept: */*","User-Agent: Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) QQ/9.6.7.28815 Chrome/43.0.2357.134 Safari/537.36 QBCore/3.43.1298.400 QQBrowser/9.0.2524.400","X-Requested-With: XMLHttpRequest","Referer: https://qinfo.clt.qq.com/qinfo_v3/member.html?groupuin=".$group."","Accept-Encoding: gzip, deflate","Accept-Language: en-US,en;q=0.8");
$return=get_result($url,$data,$header);
$data=json_decode($return,true);
date_default_timezone_set("PRC");
$time = date("Y-m-d H:i:s", $data["gCrtTime"]);
$Dat=$_REQUEST["data"];
$data=str_replace('&nbsp;',' ',$data);
$data=str_replace('&lt;','<',$data);
$data=str_replace('&gt;','>',$data);
if($Dat=="json"){
print_r($return);
}else{
$array=array(
'gc'=>$data["gc"],
'gName'=>$data["gName"],
'gOwner'=>$data["gOwner"],
'gMemNum'=>$data["gMemNum"],
'gMaxMem'=>$data["gMaxMem"],
'class'=>$data["class"],
'time'=>$time,
'gIntro'=>$data["gIntro"]
);
Back($array);
}
function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    
    return $msectime;
}
