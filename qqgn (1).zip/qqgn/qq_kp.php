<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$max=$_REQUEST["max"]?:"10";
$lx=$_REQUEST["lx"];
$Dat=$_REQUEST["data"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data=curl("https://ti.qq.com/hybrid-h5/api/json/daily_attendance/MyCardFolderList?count=20&traceInfo=&uin=".$uin."&c=20&fk=&QYY=3&qua=V1_AND_SQ_8.8.12_1900_YYB_D",null,$header);
$json=json_decode($data,true);
if($Dat=="json"){
print_r($data);
}else{
if($json["ret"]=="-3000"){
print_r("Cookie失效，请重新获取！");
exit();
}
if($data=="json"){
print_r(jsonjx($json));
}
else{
foreach ($json["data"]["vecCardFolderInfo"]["value"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["folderName"]."\n";
echo $value["doc"]."\n";
}
}}
