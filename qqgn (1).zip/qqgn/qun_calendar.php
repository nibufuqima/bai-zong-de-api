<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$group=$_REQUEST["group"];
$msg=$_REQUEST["msg"];
$title=$_REQUEST["title"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$time=strtotime(date('Y-m-d H:i:s',strtotime('+1 hour')));
$time2=strtotime(date('Y-m-d H:i:s',strtotime('+2 hour')));
$time3=strtotime(date('Y-m-d H:i:s',strtotime('+1hour 30minute')));
$url="https://qun.qq.com/cgi-bin/calendar/publish/add";
$header=array("Cookie: p_uin=o".$uin."; p_skey=".$pskey."; uin=o".$uin."; skey=".$skey."; ");
$data=curl($url,"start_time=" . (time() + 10) . "&end_time=${time2}&remind_time=${time3}&allday=false&name=".$title."&desc=".$msg."&gc={$group}&bkn=" . GetBkn($skey),$header);
print_r($data);