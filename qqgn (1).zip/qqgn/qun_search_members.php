<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$msg=str_replace(' ','+',$_REQUEST["msg"]?:"solo dance");
$msg=$_REQUEST["msg"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$group=$_REQUEST["group"];
$max=$_REQUEST["max"]?:"10";
$url="https://qun.qq.com/cgi-bin/qun_mgr/search_group_members";
$data=curl($url,"gc=".$group."&st=0&end=20&sort=0&key=".$msg."&bkn=".getGTK($skey),array("Host: qun.qq.com","Connection: keep-alive","Accept: application/json, text/javascript, */*; q=0.01","X-Requested-With: XMLHttpRequest","User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","Content-Type: application/x-www-form-urlencoded; charset=UTF-8","Origin: https://qun.qq.com","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Referer: https://qun.qq.com/member.html","Accept-Encoding: gzip, deflate, br","Accept-Language: zh-CN,zh;q=0.9","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; "));
$data=json_decode($data,true);
foreach ($data["mems"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo "账号:".$value["uin"]."\n";
echo "马甲:".$value["card"]."\n";
echo "昵称:".$value["nick"]."\n";
echo "---------------------\n";
}
echo "以上为本次搜索结果!";