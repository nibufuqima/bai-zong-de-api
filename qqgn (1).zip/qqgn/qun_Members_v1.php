<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$qq=$_REQUEST['qq'];
$pskey=$_REQUEST['pskey'];
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qinfo.clt.qq.com/cgi-bin/qun_info/get_members_info_v1?friends=1&name=1&gc=".$group."&bkn=".getGTK($skey)."&src=qinfo_v3&_ti=".msectime();
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data=curl($url,null,$header);
$json=json_decode($data,true);
$adm=$json["adm"];
$owner=$json["owner"];
if(in_array($qq,$adm)){
echo "1";
}elseif($qq==$owner){
echo "0";
}else{
echo "2";
}



function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    
    return $msectime;
}
