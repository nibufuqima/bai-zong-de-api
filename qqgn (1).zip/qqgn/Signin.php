<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
set_time_limit(0);
require_once './qqsign.class.php';
include("./function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$p_skey=$_REQUEST["pskey"];
if(!$uin) {
	echo json(1001,"text","请输入操作者QQ！");
	exit();
} else if(!$skey) {
	echo json(1002,"text","请输入SKEY！");
	exit();
} else if(!$p_skey) {
	echo json(1003,"text","请输入P_skey！");
	exit();
}

$Business=new qqsign($uin,$sid,$skey,$p_skey);
$Business->bigvip();
$Business->dldqd();
$Business->dongman();
$Business->gameqd();
$Business->qqmusic();
$Business->video();
$Business->vipqd();
$Business->yqd();
$Business->hzqd();
$Business->jpgame();
$Business->bookqd();
$Business->farm();

	foreach($Business->msg as $result){
$array["data"][]=str_replace($uin.' ',"",$result);
	}
echo json(1000,null,null,$array);
?>