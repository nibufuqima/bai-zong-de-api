<?php
/*
 *腾讯签到功能类
 *Author：消失的彩虹海 & 云上的影子
*/
class qqsign{
	public $msg;
	public $skeyzt;
	public function __construct($uin,$sid=null,$skey=null,$pskey=null){
		$this->uin=$uin;
		$this->sid=$sid;
		$this->skey=$skey;
		$this->gtk2=$this->getGTK2($skey);
		$this->gtk4=$this->getGTK($skey);
		if($pskey==null){
			$this->gtk=$this->getGTK($skey);
			$this->cookie='pt2gguin=o0'.$uin.'; uin=o0'.$uin.'; skey='.$skey;
		}else{
			$this->pskey=$pskey;
			$this->gtk=$this->getGTK($pskey);
			$this->cookie='pt2gguin=o0'.$uin.'; uin=o0'.$uin.'; skey='.$skey.'; p_skey='.$pskey.'; p_uin=o0'.$uin;
		}
	}
	public function get_curl($url,$post=0,$referer=1,$cookie=0,$header=0,$ua=0,$nobaody=0,$addheader=0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$httpheader[] = "Accept: application/json";
		$httpheader[] = "Accept-Encoding: gzip,deflate,sdch";
		$httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
		$httpheader[] = "Connection: close";
		if($addheader){
			$httpheader = array_merge($httpheader, $addheader);
		}
		curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
		if($post){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		}
		if($header){
			curl_setopt($ch, CURLOPT_HEADER, TRUE);
		}
		if($cookie){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
		if($referer){
			if($referer==1){
				curl_setopt($ch, CURLOPT_REFERER, 'http://m.qzone.com/infocenter?g_f=');
			}else{
				curl_setopt($ch, CURLOPT_REFERER, $referer);
			}
		}
		if($ua){
			curl_setopt($ch, CURLOPT_USERAGENT,$ua);
		}else{
			curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (Linux; U; Android 4.4.1; zh-cn) AppleWebKit/533.1 (KHTML, like Gecko)Version/4.0 MQQBrowser/5.5 Mobile Safari/533.1');
		}
		if($nobaody){
			curl_setopt($ch, CURLOPT_NOBODY,1);
		}
		curl_setopt($ch, CURLOPT_TIMEOUT, 5);
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		$ret = curl_exec($ch);
		curl_close($ch);
		//$ret=mb_convert_encoding($ret, "UTF-8", "UTF-8");
		return $ret;
	}
	private function getGTK($skey){
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
            $hash &= 2147483647;
        }
        return $hash & 2147483647;
    }
	private function getGTK2($skey){
		$salt = 5381;
		$md5key = 'tencentQQVIP123443safde&!%^%1282';
		$hash = array();
		$hash[] = ($salt << 5);
		for($i = 0; $i < strlen($skey); $i ++)
		{
			$ASCIICode = mb_convert_encoding($skey[$i], 'UTF-32BE', 'UTF-8');
			$ASCIICode = hexdec(bin2hex($ASCIICode));
			$hash[] = (($salt << 5) + $ASCIICode);
			$salt = $ASCIICode;
		}
		$md5str = md5(implode($hash) . $md5key);
		return $md5str;
	}
	private function getGTK3($skey){
		$salt = 108;
		$md5key = 'tencent.mobile.qq.csrfauth';
		$hash = array();
		$hash[] = ($salt << 5);
		for($i = 0; $i < strlen($skey); $i ++)
		{
			$ASCIICode = mb_convert_encoding($skey[$i], 'UTF-32BE', 'UTF-8');
			$ASCIICode = hexdec(bin2hex($ASCIICode));
			$hash[] = (($salt << 5) + $ASCIICode);
			$salt = $ASCIICode;
		}
		$md5str = md5(implode($hash) . $md5key);
		return $md5str;
	}
	private function getToken($token){
		$len = strlen($token);
		$hash = 0;
		for ($i = 0; $i < $len; $i++) {
			$hash = fmod($hash * 33 + ord($token[$i]), 4294967296);
		}
        return $hash;
    }
	private function getToken2($token){
		$len = strlen($token);
        $hash = 0;
        for ($i = 0; $i < $len; $i++) {
            $hash += ($hash << 5 & 2147483647) + ord($token[$i]) & 2147483647;
            $hash &= 2147483647;
        }
        return $hash & 2147483647;
    }
	private function jsonp_decode($jsonp, $assoc = false)
	{
		$jsonp = trim($jsonp);
		if(isset($jsonp[0]) && $jsonp[0] !== '[' && $jsonp[0] !== '{') {
			$begin = strpos($jsonp, '(');
			if(false !== $begin)
			{
				$end = strrpos($jsonp, ')');
				if(false !== $end)
				{
					$jsonp = substr($jsonp, $begin + 1, $end - $begin - 1);
				}
			}
		}
		return json_decode($jsonp, $assoc);
	}
	public function vipqd()
	{
		

		$data=$this->get_curl('https://iyouxi3.vip.qq.com/ams3.0.php?_c=page&actid=23074&format=json&g_tk='.$this->gtk2,0,'https://vip.qq.com/',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 会员积分手机端签到成功！';
		elseif($arr['ret']==10601)
			$this->msg[] = $this->uin.' 会员积分手机端今天已经签到！';
		elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 会员积分手机端签到失败！SKEY过期';
		}else
			$this->msg[] = $this->uin.' 会员积分手机端签到失败！'.$arr['msg'];


		$this->get_curl('https://iyouxi3.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=27754&_='.time(),0,'https://vip.qq.com/',$this->cookie);//超级会员每月成长值
		$this->get_curl('https://iyouxi3.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=27755&_c=page&_='.time(),0,'https://vip.qq.com/',$this->cookie);//超级会员每月积分
		$this->get_curl('https://iyouxi3.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=22894&_c=page&_='.time(),0,'https://vip.qq.com/',$this->cookie);//每月分享积分
		$this->get_curl('https://iyouxi4.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=239371&_c=page&format=json&_='.time(),0,'https://vip.qq.com/',$this->cookie);//每周薪水积分
		$this->get_curl('https://iyouxi3.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=22887&_c=page&format=json&_='.time(),0,'https://vip.qq.com/',$this->cookie);//每周邀请好友积分
		$this->get_curl('https://iyouxi3.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=202041&_c=page&format=json&_='.time(),0,'https://vip.qq.com/',$this->cookie);//手Q每日签到
		$this->get_curl('https://iyouxi3.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=202049&_c=page&format=json&_='.time(),0,'https://vip.qq.com/',$this->cookie);//手Q每日SVIP签到
	}
	public function hzqd()
	{
		
		//大会员师徒
		$url = 'https://h5.qzone.qq.com/v2/vip/dhy/trpc/home/ReportShare';
		$post = '{"g_tk":'.$this->gtk.',"head":{"uid":"'.$this->uin.'","skey":"'.$this->skey.'"},"uid":"'.$this->uin.'"}';
		$data=$this->get_curl($url,$post,0,$this->cookie);
		$arr=json_decode($data,true);
//		print_r($data);
/*		if(array_key_exists('code',$arr) && $arr['code']==0)
			$this->msg[] = $this->uin.' 大会员签到成功！当前已签到'.$arr['data']['curCheckInDays'].'天';
		elseif($arr['ret']==-3000){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 大会员签到失败！SKEY过期';
		}else
			$this->msg[] = $this->uin.' 大会员签到失败！'.$arr['message'];
*/


	}
	public function svipPraise(){
		$toUin = rand(1111111,199999999);
		$url="https://mq.vip.qq.com/m/growth/doPraise?method=0&toUin=".$toUin."&g_tk=".$this->gtk2;
		$data = $this->get_curl($url,0,'https://mq.vip.qq.com/m/growth/loadfrank?pn=1&g_tk='.$this->gtk2,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='SVIP好友点赞成功！';
		}else{
			$this->msg[]='SVIP好友点赞失败！'.$data;
		}
	}
	public function bigvip(){
		//大会员签到
		$url = 'https://vip.qzone.qq.com/fcg-bin/v2/fcg_vip_task_checkin?t=0.'.time().'082161&g_tk='.$this->gtk;
		$post = 'appid=qq_big_vip&op=CheckIn&uin='.$this->uin.'&format=json&inCharset=utf-8&outCharset=utf-8';
		$data=$this->get_curl($url,$post,0,$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('code',$arr) && $arr['code']==0)
			$this->msg[] = $this->uin.' 大会员签到成功！当前已签到'.$arr['data']['curCheckInDays'].'天';
		elseif($arr['ret']==-3000){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 大会员签到失败！SKEY过期';
		}else
			$this->msg[] = $this->uin.' 大会员签到失败！'.$arr['message'];

		//登录我的访客
		$url = 'https://h5.qzone.qq.com/qzone/visitor?_wv=3&_wwv=1024&_proxy=1';
		$this->get_curl($url,0,0,$this->cookie);

		$url = 'https://h5.qzone.qq.com/webapp/json/QQBigVipTask/CompleteTask?t=0.'.time().'906319&g_tk='.$this->gtk;
		$post = 'outCharset=utf-8&iAppId=0&llTime='.time().'&format=json&iActionType=6&strUid='.$this->uin.'&uin='.$this->uin.'&inCharset=utf-8';
		$data=$this->get_curl($url,$post,0,$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0)
			$this->msg[] = $this->uin.' 登录我的访客成功！';
		elseif($arr['ret']==-3000){
			$this->skeyzt=1;
			$this->msg[] = $this->uin.' 登录我的访客失败！SKEY过期';
		}else
			$this->msg[] = $this->uin.' 登录我的访客失败！'.$arr['msg'];

	}
	public function yqd(){
		$url = 'https://h5.qzone.qq.com/proxy/domain/vip.qzone.qq.com/fcg-bin/v2/fcg_mobile_vip_site_checkin?t=0.89457'.time().'&g_tk='.$this->gtk.'&qzonetoken=423659183';
		$post = 'uin='.$this->uin.'&format=json';
		$referer='https://h5.qzone.qq.com/vipinfo/index?plg_nld=1&source=qqmail&plg_auth=1&plg_uin=1&_wv=3&plg_dev=1&plg_nld=1&aid=jh&_bid=368&plg_usr=1&plg_vkey=1&pt_qzone_sig=1';
		$data = $this->get_curl($url,$post,$referer,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='黄钻签到成功！';
		}elseif(array_key_exists('code',$arr) && $arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='黄钻签到失败！SKEY已失效';
		}elseif(array_key_exists('code',$arr)){
			$this->msg[]='黄钻签到失败！'.$arr['message'];
		}else{
			$this->msg[]='黄钻签到失败！'.$data;
		}

		$url = 'https://h5.qzone.qq.com/proxy/domain/vip.qzone.qq.com/fcg-bin/v2/fcg_vip_task_checkin?t=0.89457'.time().'&g_tk='.$this->gtk.'&qzonetoken=423659183';
		$post = 'op=CheckIn&outCharset=utf-8&appid=qz_svip&format=json&uin='.$this->uin.'&inCharset=utf-8';
		$referer='https://h5.qzone.qq.com/vipinfo/index?plg_nld=1&source=qqmail&plg_auth=1&plg_uin=1&_wv=3&plg_dev=1&plg_nld=1&aid=jh&_bid=368&plg_usr=1&plg_vkey=1&pt_qzone_sig=1';
		$data = $this->get_curl($url,$post,$referer,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='黄钻签到2成功！';
		}elseif(array_key_exists('code',$arr) && $arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='黄钻签到2失败！SKEY已失效';
		}elseif(array_key_exists('code',$arr)){
			$this->msg[]='黄钻签到2失败！'.$arr['message'];
		}else{
			$this->msg[]='黄钻签到2失败！'.$data;
		}

		$url = 'https://activity.qzone.qq.com/fcg-bin/fcg_huangzuan_daily_signing?t=0.'.time().'906035&g_tk='.$this->gtk.'&qzonetoken=-1';
		$post = 'option=sign&uin='.$this->uin.'&format=json';
		$data = $this->get_curl($url,$post,$url,$this->cookie);
		$data = mb_convert_encoding($data, "UTF-8", "GB2312");
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='黄钻公众号签到成功！';
		}elseif(array_key_exists('code',$arr) && $arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='黄钻公众号签到失败！SKEY已失效';
		}elseif($arr['code']==-90002){
			$this->msg[]='黄钻公众号签到失败！非黄钻用户无法签到';
		}elseif(array_key_exists('code',$arr)){
			$this->msg[]='黄钻公众号签到失败！'.$arr['message'];
		}else{
			$this->msg[]='黄钻公众号签到失败！'.$data;
		}
	}
		public function dongman(){
		$url = 'https://comic.vip.qq.com/cgi-bin/coupon_coin?merge=1&pageVersion=288192_online&platId=109&version=1&_='.time().'516&g_tk='.$this->gtk.'&p_tk=&sequence='.time().'431';
		$post = 'param=%7B%220%22%3A%7B%22param%22%3A%7B%22tt%22%3A0%7D%2C%22module%22%3A%22comic_sign_in_svr%22%2C%22method%22%3A%22SignIn%22%2C%22timestamp%22%3A'.time().'424%7D%7D';
		$data = $this->get_curl($url,$post,$url,$this->cookie);
		$arr = json_decode($data, true);
		if($arr = $arr['data']['0']['retBody']){
			if(array_key_exists('result',$arr) && $arr['result']==0){
				$this->msg[]='手机QQ动漫签到成功！萌点+2，本月已累计签到'.$arr['data']['singedDayOfMonth'].'天';
			}elseif($arr['result']==-120000){
				$this->skeyzt=1;
				$this->msg[]='手机QQ动漫签到失败！SKEY已失效';
			}else{
				$this->msg[]='手机QQ动漫签到失败！'.$arr['message'];
			}
		}else{
			$this->msg[]='手机QQ动漫签到失败！'.$data;
		}

		$url = 'https://iyouxi.vip.qq.com/ams3.0.php?g_tk='.$this->gtk2.'&actid=105321&merge=1&plat=1&qqVersion=6.6.9.3060&_='.time().'749';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='手机QQ动漫领取奖励成功！';
		}elseif($arr['ret']==20226){
			$this->msg[]='累计签到天数不足，无法领取额外奖励';
		}elseif($arr['ret']==10002){
			$this->skeyzt=1;
			$this->msg[]='手机QQ动漫领取奖励失败！SKEY过期';
		}else{
			$this->msg[]='手机QQ动漫领取奖励失败！'.$arr['msg'];
		}
	}
	public function gameqd(){
		$url = 'http://social.minigame.qq.com/cgi-bin/social/welcome_panel_operate?format=json&cmd=2&uin='.$this->uin.'&g_tk='.$this->gtk;
		$data = $this->get_curl($url,0,'http://minigame.qq.com/appdir/social/cloudHall/src/index/welcome.html',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('result',$arr) && $arr['result']==0) {
			if($arr['do_ret']==11)
				$this->msg[]='游戏大厅今天已签到！';
			else
				$this->msg[]='游戏大厅签到成功！';
		}elseif($arr['result']==1000005){
			$this->skeyzt=1;
			$this->msg[]='游戏大厅签到失败！SKEY已失效。';
		}else{
			$this->msg[]='游戏大厅签到失败！'.$arr['resultstr'];
		}

		$url = 'http://social.minigame.qq.com/cgi-bin/social/welcome_panel_operate?format=json&cmd=1&uin='.$this->uin.'&g_tk='.$this->gtk;
		$data = $this->get_curl($url,0,'http://minigame.qq.com/appdir/social/cloudHall/src/index/welcome.html',$this->cookie);

		$url = 'http://social.minigame.qq.com/cgi-bin/social/CheckInPanel_Operate?Cmd=CheckIn_Operate&g_tk='.$this->gtk;
		$data = $this->get_curl($url,0,'http://minigame.qq.com/appdir/social/cloudHall/src/index/welcome.html',$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('result',$arr) && $arr['result']==0) {
			if($arr['do_ret']==11)
				$this->msg[]='游戏大厅2今天已签到！';
			else
				$this->msg[]='游戏大厅2签到成功！';
		}elseif($arr['result']==1000005){
			$this->skeyzt=1;
			$this->msg[]='游戏大厅2签到失败！SKEY已失效。';
		}else{
			$this->msg[]='游戏大厅2签到失败！'.$arr['resultstr'];
		}

		$url = 'http://info.gamecenter.qq.com/cgi-bin/gc_my_tab_async_fcgi?merge=1&ver=0&st='.time().'746&sid=&uin='.$this->uin.'&number=0&path=489&plat=qq&gamecenter=1&_wv=1031&_proxy=1&gc_version=2&ADTAG=gamecenter&notShowPub=1&param=%7B%220%22%3A%7B%22param%22%3A%7B%22platform%22%3A1%2C%22tt%22%3A1%7D%2C%22module%22%3A%22gc_my_tab%22%2C%22method%22%3A%22sign_in%22%7D%7D&g_tk='.$this->gtk;
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr=json_decode($data,true);
		if(array_key_exists('ecode',$arr) && $arr['ecode']==0) {
			$arr=$arr['data']['0'];
			if(array_key_exists('retCode',$arr) && $arr['retCode']==0) {
				$this->msg[]='手Q游戏中心签到成功！已连续签到'.$arr['retBody']['data']['cur_continue_sign'].'天';
			}else{
				$this->msg[]='手Q游戏中心签到失败！'.$arr['retBody']['message'];
			}
		}elseif($arr['ecode']==-120000){
			$this->skeyzt=1;
			$this->msg[]='手Q游戏中心签到失败！SKEY已失效。';
		}else{
			$this->msg[]='手Q游戏中心签到失败！'.$arr['data']['0']['retBody']['message'];
		}
	}
	public function dldqd(){
		$url = 'https://fight.pet.qq.com/cgi-bin/petpk?cmd=award&op=1&type=0';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$data = mb_convert_encoding($data, "UTF-8", "GB2312");
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]=$arr['ContinueLogin'].' + '.$arr['DailyAward'];
		}elseif($arr['ret']==-1){
			$this->msg[]=$arr['ContinueLogin'];
			$this->msg[]=$arr['DailyAward'];
		}elseif($arr['result']==-5){
			$this->skeyzt=1;
			$this->msg[]='大乐斗领礼包失败！SKEY已失效';
		}else{
			$this->msg[]='大乐斗领礼包失败！'.$arr['msg'];
		}
	}
	public function weiyun(){
		$url = 'https://h5.weiyun.com/sign_in';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		preg_match('!window\.__INITIAL_STATE__=(.*?)<\/script>!is',$data,$match);
		$arr = json_decode($match[1], true);
		if(array_key_exists('detail',$arr)){
			$this->msg[]='微云签到成功！已连续签到'.$arr['index']['consecutiveSignInCount'].'天，当前金币 '.$arr['global']['totalCoin'];
		}else{
			$this->msg[]='微云签到失败！';
		}
	}
	public function fzqd(){
		$url='http://x.pet.qq.com/vip_platform?cmd=set_sign_info&format=json&_='.time().'9008';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('result',$arr) && $arr['result']==0){
			$this->msg[]=$this->uin.' 粉钻签到成功！';
		}elseif($arr['result']==-101){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' 粉钻签到失败！SKEY已失效';
		}else{
			$this->msg[]=$this->uin.' 粉钻签到失败！'.$arr['msg'];
		}
	}
	public function video(){
		$url='https://vip.video.qq.com/fcgi-bin/comm_cgi?name=hierarchical_task_system&cmd=2&_='.time().'8906';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		preg_match('/QZOutputJson=\((.*?)\)/is',$data,$json);
		$arr = json_decode($json[1], true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]=$this->uin.' 腾讯视频VIP会员签到成功！获得'.$arr['checkin_score'].'成长值';
		}elseif($arr['ret']==-10006){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' 腾讯视频VIP会员签到失败！SKEY已失效';
		}elseif($arr['ret']==-10019){
			$this->msg[]=$this->uin.' 你不是腾讯视频VIP会员，无法签到';
		}else{
			$this->msg[]=$this->uin.' 腾讯视频VIP会员签到失败！'.$arr['msg'];
		}

		$url='https://vip.video.qq.com/fcgi-bin/comm_cgi?name=spp_novel_checkin&cmd=2&_='.time().'676';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		preg_match('/QZOutputJson=\((.*?)\)/is',$data,$json);
		$arr = json_decode($json[1], true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]=$this->uin.' 腾讯视频小说频道签到成功！获得'.$arr['goodsFacevalueInToday'].'书卷';
		}elseif($arr['ret']==-1006){
			$this->msg[]=$this->uin.' 腾讯视频小说频道当天已经签过到';
		}elseif($arr['ret']==-11){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' 腾讯视频小说频道签到失败！SKEY已失效';
		}else{
			$this->msg[]=$this->uin.' 腾讯视频小说频道签到失败！'.$arr['msg'];
		}
	}
	public function videos(){

		$url='https://growth.video.qq.com/fcgi-bin/sync_task?callback=&otype=json&taskid=22&platform=1&_='.time().'8906';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		preg_match('/QZOutputJson=(.*?)\;/is',$data,$json);
		$arr = json_decode($json[1], true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]=$this->uin.' 腾讯视频PC端签到成功！';
		}elseif($arr['ret']==-13004){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' 腾讯视频PC端签到失败！SKEY已失效';
		}else{
			$this->msg[]=$this->uin.' 腾讯视频PC端签到失败！'.$arr['errmsg'];
		}

	}
	public function qqmusic(){
		$addheader = array("Content-Type: application/json");
		$url='https://u.y.qq.com/cgi-bin/musicu.fcg';
		$post='{"req_0":{"module":"UserGrow.UserGrowScore","method":"receive_score","param":{"musicid":"'.$this->uin.'","type":15}},"comm":{"g_tk":'.$this->gtk.',"uin":'.$this->uin.',"format":"json","ct":23,"cv":0}}';
		$data = $this->get_curl($url,$post,$url,$this->cookie,0,0,0,$addheader);
		$arr = json_decode($data, true);
		$arr = $arr['req_0']['data'];
		if(array_key_exists('retCode',$arr) && $arr['retCode']==0){
			$this->msg[]=$this->uin.' QQ音乐签到成功！获得积分:'.$arr['todayScore'].',签到天数:'.$arr['totalDays'].',总积分:'.$arr['totalScore'];
		}elseif($arr['retCode']==40001){
			$this->msg[]=$this->uin.' QQ音乐今日已签到！';
		}elseif($arr['ret']==-13004){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' QQ音乐签到失败！SKEY已失效';
		}else{
			$this->msg[]=$this->uin.' QQ音乐签到失败！'.$arr['errMsg'];
		}

		$post='{"comm":{"g_tk":'.$this->gtk.',"uin":'.$this->uin.',"format":"json","inCharset":"utf-8","outCharset":"utf-8","notice":0,"platform":"h5","needNewCode":1,"ct":23,"cv":0},"req_0":{"module":"music.activeCenter.ActiveCenterSignSvr","method":"DoSignIn","param":{}}}';
		$data = $this->get_curl($url,$post,$url,$this->cookie,0,0,0,$addheader);
		$arr = json_decode($data, true);
		$arr = $arr['req_0']['data'];
		if(array_key_exists('retCode',$arr) && $arr['retCode']==0){
			$this->msg[]=$this->uin.' QQ音乐活动签到成功！已连续签到'.$arr['signInfo']['continuousDays'].'天,累计签到'.$arr['signInfo']['totalDays'].'天';
		}elseif($arr['retCode']==40004){
			$this->msg[]=$this->uin.' QQ音乐活动今日已签到！';
		}elseif($arr['ret']==-13004){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' QQ音乐活动签到失败！SKEY已失效';
		}else{
			$this->msg[]=$this->uin.' QQ音乐活动签到失败！'.$arr['errMsg'];
		}

		$post='{"req_0":{"module":"UserGrow.UserGrowScore","method":"receive_score","param":{"musicid":"'.$this->uin.'","type":1}},"comm":{"g_tk":'.$this->gtk.',"uin":'.$this->uin.',"format":"json","ct":23,"cv":0}}';
		$data = $this->get_curl($url,$post,$url,$this->cookie,0,0,0,$addheader);
		$arr = json_decode($data, true);
		$arr = $arr['req_0']['data'];
		if(array_key_exists('retCode',$arr) && $arr['retCode']==0){
			$this->msg[]=$this->uin.' QQ音乐分享成功！获得积分:'.$arr['todayScore'].',签到天数:'.$arr['totalDays'].',总积分:'.$arr['totalScore'];
		}elseif($arr['retCode']==40001){
			$this->msg[]=$this->uin.' QQ音乐今日已分享！';
		}elseif($arr['retCode']==40002){
			$this->msg[]=$this->uin.' QQ音乐今日分享未完成！';
		}elseif($arr['ret']==-13004){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' QQ音乐分享失败！SKEY已失效';
		}else{
			$this->msg[]=$this->uin.' QQ音乐分享失败！'.$arr['errMsg'];
		}

		$post='{"req_0":{"module":"Radio.RadioLucky","method":"clockIn","param":{"platform":2}},"comm":{"g_tk":'.$this->gtk.',"uin":'.$this->uin.',"format":"json"}}';
		$data = $this->get_curl($url,$post,$url,$this->cookie,0,0,0,$addheader);
		$arr = json_decode($data, true);
		$arr = $arr['req_0']['data'];
		if(array_key_exists('retCode',$arr) && $arr['retCode']==0){
			$this->msg[]=$this->uin.' QQ音乐电台锦鲤打卡成功！积分+'.$arr['score'];
		}elseif($arr['retCode']==40001){
			$this->msg[]=$this->uin.' QQ音乐电台锦鲤已打卡！';
		}elseif($arr['ret']==-13004){
			$this->skeyzt=1;
			$this->msg[]=$this->uin.' QQ音乐电台锦鲤打卡失败！SKEY已失效';
		}else{
			$this->msg[]=$this->uin.' QQ音乐电台锦鲤打卡失败！'.$arr['errMsg'];
		}

		$this->get_curl('https://service-n157vbwh-1252343050.ap-beijing.apigateway.myqcloud.com/release/lzz_qqmusic?qq='.$this->uin.'&hour=2');
		$this->msg[]=$this->uin.' QQ音乐刷听歌时间成功！需要手动登录一下QQ音乐才可加速成功';
	}
	public function qqmgr(){
		$url='http://p.guanjia.qq.com/bin/user/qrycheckin.php?op=checkin&emotionId=120&Uin='.$this->uin.'&skey='.$this->skey.'&gjtk='.$this->gtk.'&_='.time().'051';
		$data = $this->get_curl($url,0,'http://s.pcmgr.qq.com/user_v2/inc/sign.html',$this->cookie);
		preg_match('/jsonpCallback\((.*?)\)/is',$data,$json);
		$arr = json_decode($json[1], true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='腾讯电脑管家签到成功！';
		}elseif($arr['code']==8){
			$this->skeyzt=1;
			$this->msg[]='腾讯电脑管家签到失败！SKEY已失效';
		}elseif(array_key_exists('code',$arr)){
			$this->msg[]='腾讯电脑管家签到失败！'.$arr['msg'];
		}else{
			$this->msg[]='腾讯电脑管家签到失败！'.$data;
		}
	}
	public function dnfjf(){
		$url = 'https://apps.game.qq.com/cms/index.php?serviceType=dnf&actId=2&sAction=duv&sModel=Data&retType=json';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('iRet',$arr) && $arr['iRet']==0){
			if($arr['jData']['iLotteryRet']==100002){
				$this->msg[]='DNF社区积分已领取！';
			}else{
				$this->msg[]='DNF社区积分领取成功！';
			}
		}else{
			$this->msg[]='DNF社区积分领取失败！'.$arr['sMsg'];
		}
	}
	public function gamesafe(){
		$url = 'https://act.gamesafe.qq.com/cgi-bin/signin';
		$data = $this->get_curl($url,0,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('result',$arr) && $arr['result']==0){
			$this->msg[]='安全盾签到成功！获得安全盾+'.$arr['shields'].' 已连续签到'.$arr['days'];
		}elseif($arr['result']==1400){
			$this->msg[]='安全盾今天已签到！';
		}else{
			$this->msg[]='安全盾签到失败！'.$arr['errmsg'];
		}
	}

	public function sweet_send($id=1){
		$luin = $this->sweet_sign();
		if(!$luin)return false;

		$url = 'https://sweet.snsapp.qq.com/v2/cgi-bin/sweet_chat_sendmsg?g_tk='.$this->gtk;
		$post = 'luin='.$luin.'&opuin='.$this->uin.'&type=8&rid=&content=&richval=%5B%7B%22id%22%3A'.$id.'%2C%22subid%22%3A1%2C%22type%22%3A%22interect%22%7D%5D&src=1&uin='.$this->uin.'&plat=0&outputformat=4';
		$json=$this->get_curl($url,$post,$url,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='发送密语成功！今日已获得积分:'.$arr['expDetail']['totalExp'].'，总共积分:'.($arr['exp']/10);
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='发送密语失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='发送密语失败！'.$arr['message'];
		}
	}
	public function sweet_tree(){
		$luin = $this->sweet_sign();
		if(!$luin)return false;

		$url = 'https://sweet.snsapp.qq.com/v2/cgi-bin/sweet_tree_index?g_tk='.$this->gtk.'&luin='.$luin.'&outputformat=4&opuin='.$this->uin.'&src=1&uin='.$this->uin;
		$json=$this->get_curl($url,0,'https://sweet.snsapp.qq.com/',$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='登录情侣树成功！当前经验值:'.$arr['exp'];

		$url = 'https://sweet.snsapp.qq.com/v2/cgi-bin/sweet_tree_operate?g_tk='.$this->gtk;
		$post = 'opuin='.$this->uin.'&luin='.$luin.'&outputformat=4&uin='.$this->uin.'&src=1&cmd=1';
		$json=$this->get_curl($url,$post,$url,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='情侣树浇水成功！获得经验值:'.$arr['exp'].'，总经验值:'.$arr['exp_total'];
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='情侣树浇水失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='情侣树浇水失败！'.$arr['message'];
		}
		$post = 'opuin='.$this->uin.'&luin='.$luin.'&outputformat=4&uin='.$this->uin.'&src=1&cmd=2';
		$json=$this->get_curl($url,$post,$url,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='情侣树施肥成功！获得经验值:'.$arr['exp'].'，总经验值:'.$arr['exp_total'];
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='情侣树施肥失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='情侣树施肥失败！'.$arr['message'];
		}
		$post = 'opuin='.$this->uin.'&luin='.$luin.'&outputformat=4&uin='.$this->uin.'&src=1&cmd=3';
		$json=$this->get_curl($url,$post,$url,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='情侣树阳光成功！获得经验值:'.$arr['exp'].'，总经验值:'.$arr['exp_total'];
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='情侣树阳光失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='情侣树阳光失败！'.$arr['message'];
		}

		$url = 'https://sweet.snsapp.qq.com/v2/cgi-bin/sweet_tree_gain?g_tk='.$this->gtk;
		$post = 'opuin='.$this->uin.'&luin='.$luin.'&trunk_id=1&outputformat=4&uin='.$this->uin.'&src=1';
		$json=$this->get_curl($url,$post,$url,$this->cookie);
		$arr=json_decode($json,true);
		if(@array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='情侣树收获果实成功！获得经验值:'.$arr['exp'].'，总经验值:'.$arr['exp_total'];
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='情侣树收获果实失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='情侣树收获果实失败！'.$arr['message'];
		}

		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='登录情侣树失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='登录情侣树失败！'.$arr['message'];
		}
		
	}
	public function sweet_sign(){
		$url = 'https://sweet.snsapp.qq.com/v2/cgi-bin/sweet_signlove_get?cmd=0&startts=1453564800&endts=1457280000&opuin='.$this->uin.'&uin='.$this->uin.'&plat=0&outputformat=4&g_tk='.$this->gtk;
		$data = $this->get_curl($url,0,'https://sweet.snsapp.qq.com/',$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('code',$arr) && $arr['code']==0){
			$this->msg[]='情侣空间签到成功！';
			return $arr['data']['lover']['uin'];
		}elseif($arr['code']==-3000){
			$this->skeyzt=1;
			$this->msg[]='情侣空间签到失败！原因:SKEY已过期！';
			return false;
		}else{
			$this->msg[]='情侣空间签到失败！'.$arr['message'];
			return false;
		}
	}
	public function bookqd(){
		$url = "http://ubook.3g.qq.com/8/user/myMission?k1={$this->skey}&u1=o0{$this->uin}";
        $data = $this->get_curl($url, 0, 'http://ubook.qq.com/8/mymission.html');
        $arr = json_decode($data, true);
        if ($arr['isLogin'] == 'true' && $arr['signMap']['code'] == 0) {
            $this->msg[] = '图书签到成功！';
        } elseif ($arr['signMap']['code'] == -2) {
            $this->msg[] = '图书今日已经签到！';
        } elseif ($arr['isLogin'] == false) {
			$this->skeyzt=1;
            $this->msg[] = '图书签到失败！SKEY过期！';
        } else {
            $this->msg[] = '图书签到失败！数据异常';
        }

		$guid = md5($this->uin.time());
		$url = "https://novelsns.html5.qq.com/ajax?m=task&type=sign&aid=20&t=".time()."586";
		$data = $this->get_curl($url,0,'https://bookshelf.html5.qq.com/discovery.html','Q-H5-ACCOUNT='.$this->uin.'; Q-H5-SKEY='.$this->skey.'; luin='.$this->uin.'; Q-H5-USERTYPE=1; Q-H5-GUID='.$guid.';');
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='小说书架签到成功！已连续签到'.$arr['continuousDays'].'天,获得书豆'.$arr['beans'];
		}elseif($arr['ret']==-2){
			$this->msg[]='小说书架今天已签到！已连续签到'.$arr['continuousDays'].'天,获得书豆'.$arr['beans'];
		}else{
			$this->msg[]='小说书架签到失败！'.$arr['msg'];
		}

		$url = "https://novelsns.html5.qq.com/ajax?m=shareSignPageObtainBeans&aid=20&t=".time()."586";
		$data = $this->get_curl($url,0,'https://bookshelf.html5.qq.com/discovery.html','Q-H5-ACCOUNT='.$this->uin.'; Q-H5-SKEY='.$this->skey.'; luin='.$this->uin.'; Q-H5-USERTYPE=1; Q-H5-GUID='.$guid.';');
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='小说书架分享成功！获得书豆'.$arr['beans'];
		}else{
			$this->msg[]='小说书架分享失败！'.$arr['msg'];
		}

		$url = 'http://reader.sh.vip.qq.com/cgi-bin/reader_page_csrf_cgi?merge=2&ditch=100020&cfrom=account&current=sign_index&tf=2&sid='.$this->uin.'&client=1&version=qqreader_1.0.669.0001_android_qqplugin&channel=00000&_bid=2036&ChannelID=100020&plat=1&qqVersion=0&_from=sign_index&_='.time().'017&g_tk='.$this->gtk.'&p_tk=&sequence='.time().'755';
		$post = 'param=%7B%220%22%3A%7B%22param%22%3A%7B%22tt%22%3A0%7D%2C%22module%22%3A%22reader_sign_manage_svr%22%2C%22method%22%3A%22UserTodaySign%22%7D%2C%221%22%3A%7B%22param%22%3A%7B%22tt%22%3A0%7D%2C%22module%22%3A%22reader_sign_manage_svr%22%2C%22method%22%3A%22GetSignGifts%22%7D%7D';
		$data = $this->get_curl($url,$post,$url,$this->cookie);
		$arr = json_decode($data, true);
		if($arr = $arr['data']['0']['retBody']){
			if(array_key_exists('result',$arr) && $arr['result']==0){
				$this->msg[]='手机QQ阅读签到成功！获得书券'.$arr['data']['awards'][0]['awardNum'].',已连续签到'.$arr['data']['lastDays'].'天';
			}else{
				$this->msg[]='手机QQ阅读签到失败！'.$arr['message'];
			}
		}else{
			$this->msg[]='手机QQ阅读签到失败！'.$data;
		}

		$url = 'http://reader.sh.vip.qq.com/cgi-bin/reader_page_csrf_cgi?merge=1&ditch=100020&cfrom=account&current=sign_index&tf=2&sid='.$this->uin.'&client=1&version=qqreader_1.0.669.0001_android_qqplugin&channel=00000&_bid=2036&ChannelID=100020&plat=1&qqVersion=0&_from=sign_index&_='.time().'017&g_tk='.$this->gtk.'&p_tk=&sequence='.time().'755';
		$post = 'param=%7B%220%22%3A%7B%22param%22%3A%7B%22tt%22%3A0%7D%2C%22module%22%3A%22reader_sign_manage_svr%22%2C%22method%22%3A%22GrantBigGift%22%7D%7D';
		$data = $this->get_curl($url,$post,$url,$this->cookie);
		$arr = json_decode($data, true);
		if($arr = $arr['data']['0']['retBody']){
			if(array_key_exists('result',$arr) && $arr['result']==0){
				$this->msg[]='手机QQ阅读抽奖成功！获得奖品'.$arr['data']['newlyGift']['giftName'];
			}elseif($arr['result']==1004){
				$this->msg[]='手机QQ阅读抽奖：需要连续签到5天才可以抽奖';
			}else{
				$this->msg[]='手机QQ阅读抽奖失败！'.$arr['message'];
			}
		}else{
			$this->msg[]='手机QQ阅读抽奖失败！'.$data;
		}
	}
	public function daoju(){
		$url = "https://apps.game.qq.com/ams/ame/ame.php?ameVersion=0.3&sServiceType=dj&iActivityId=11117&sServiceDepartment=djc&set_info=djc";
		$post = "iActivityId=11117&iFlowId=96939&g_tk=".$this->gtk."&e_code=0&g_code=0&sServiceDepartment=djc&sServiceType=dj";
		$data = $this->get_curl($url,$post,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr['modRet']) && $arr['modRet']['ret']==0){
			$this->msg[]='道聚城签到成功！';
		}elseif($arr['modRet']['ret']==600){
			$this->msg[]='道聚城今天已签到！';
		}else{
			$this->msg[]='道聚城签到失败！'.$arr['modRet']['msg'];
		}

		/*$post = "gameId=&sArea=&iSex=&sRoleId=&iGender=&sServiceType=dj&objCustomMsg=&areaname=&roleid=&rolelevel=&rolename=&areaid=&iActivityId=11117&iFlowId=96910&g_tk=".$this->gtk."&e_code=0&g_code=0&sServiceDepartment=djc";
		$data = $this->get_curl($url,$post,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('iRet',$arr['modRet']) && $arr['modRet']['iRet']==0){
			$this->msg[]=$arr['modRet']['sMsg'];
		}elseif($arr['ret']==600){
			$this->msg[]=$arr['msg'];
		}else{
			$this->msg[]=$arr['msg'];
		}*/
	}
	public function xinyue(){
		$url = "https://apps.game.qq.com/ams/ame/ame.php?ameVersion=0.3&sServiceType=tgclub&iActivityId=21547&sServiceDepartment=xinyue&set_info=xinyue";
		$post = "iActivityId=21547&iFlowId=149694&g_tk=".$this->gtk."&e_code=0&g_code=0&sServiceDepartment=xinyue&sServiceType=tgclub";
		$data = $this->get_curl($url,$post,0,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='心锐VIP签到成功！';
		}elseif($arr['ret']==600){
			$this->msg[]='心锐VIP今天已签到！';
		}else{
			$this->msg[]='心锐VIP签到失败！'.$arr['msg'];
		}
	}
	public function jpgame(){
		$url = "https://1.game.qq.com/app/sign?start=".date("Y-m")."&g_tk=".$this->gtk."&_t=0.6780016267291531";
		$data = $this->get_curl($url,0,$url,$this->cookie,"Content-Type: application/x-www-form-urlencoded;charset=UTF-8");
		preg_match('/var sign_index = (.*?);/is', $data, $json);
		$arr = json_decode($json[1], true);
		$arr = $arr['jData']['signInfo'];
		if(array_key_exists('ret',$arr) && $arr['ret']==0){
			$this->msg[]='精品页游签到成功！';
		}elseif($arr['ret']==1){
			$this->msg[]='精品页游今天已签到！';
		}else{
			$this->msg[]='精品页游签到失败！'.$arr['msg'];
		}
	}
	public function webface(){
		$url='https://face.qq.com/client/webface.php';
		$post='cmd=get_used_items&g_tk='.$this->gtk2.'&callback=callback';
		$data=$this->get_curl($url,$post,$url,$this->cookie);
		preg_match('/callback\((.*?)\);/is', $data, $json);
		$arr=json_decode($json[1],true);
		if(@array_key_exists('result',$arr) && $arr['result']==0){
			$faces=array();
			foreach($arr['data'] as $row){
				if($row['hash'])$faces[]=$row['hash'];
			}
			$hash=$faces[array_rand($faces,1)];
			$url='https://face.qq.com/client/webface_share.php';
			$post='hash='.$hash.'&type=0&cmd=set_used_face&g_tk='.$this->gtk2.'&callback=callback';
			$data=$this->get_curl($url,$post,$url,$this->cookie);
			$this->msg[]='更换头像成功！更换头像的范围在你所使用过的头像中，修改头像种类请<a href="https://ptlogin2.qq.com/jump?uin='.$this->uin.'&skey='.$this->skey.'&u1=https%3A%2F%2Fstyle.qq.com%2Fface%2Fmanage.html" target="_blank" rel="noreferrer">点此进入</a>';
		}elseif($arr['result']==1001){
			$this->skeyzt=1;
			$this->msg[]='更换头像失败！原因:SKEY已过期！';
		}else{
			$this->msg[]='更换头像失败！'.$data;
		}
	}
	public function farm(){
		$url = 'https://nc.qzone.qq.com/cgi-bin/cgi_farm_month_signin_day?g_tk='.$this->gtk;
		$post = 'uinY='.$this->uin;
		$data = $this->get_curl($url,$post,$url,$this->cookie);
		$arr = json_decode($data, true);
		if(array_key_exists('ecode',$arr) && $arr['ecode']==0){
			$this->msg[]='QQ农场签到成功！';
		}elseif($arr['ecode']==-102){
			$this->msg[]='QQ农场今日已经签到';
		}elseif($arr['ecode']==-10004){
			$this->skeyzt=1;
			$this->msg[]='QQ农场签到失败！SKEY过期';
		}else{
			$this->msg[]='QQ农场签到失败！'.$arr['errorContent'];
		}
	}
}