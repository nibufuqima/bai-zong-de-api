<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$group=$_REQUEST["group"];
$uin=$_REQUEST["uin"];
$lx=$_REQUEST["lx"];
$qq=$_REQUEST["qq"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$Dat=$_REQUEST["data"];
$switch=$_REQUEST["switch"]?:"1";
if(!$uin || !$skey || !$pskey || !$qq){
print_r("参数不完整!需要参数:uin，skey，pskey，qq");
exit();
}
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey.";  p_skey=".$pskey.";","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Referer: https://ti.qq.com/interactive_logo/word?target_uin=".$qq."&auto_take=1&_wv=67108865&_nav_txtclr=FFFFFF&_wvSb=0","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Content-Type: application/json; charset=UTF-8","Host: ti.qq.com");
$url="https://ti.qq.com/interactive_logo/word/proxy/domain/oidb.tim.qq.com/v3/oidbinterface/oidb_0xdd2_0?sdkappid=39998&actype=2&bkn=".GetBkn($skey);
$data='{"uin":'.$uin.',"frd_uin":'.$qq.',"switch":'.$switch.'}';
$json=curl($url,$data,$header);
//$data=base64_decode($data);
$data=json_decode($json,true);
if($Dat=="json"){
print_r($json);
}else{
$ErrorCode=$data["ErrorCode"];
if($ErrorCode=="307"){
print_r("Cookie失效，请重新获取！");
exit();
}
if($data["ActionStatus"]=="OK"){
print_r("操作成功！");
exit();
}}