<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$type=$_REQUEST["type"];
$header=array("Host: ti.qq.com","Connection: keep-alive","Accept: application/json, text/plain, */*","qname-service: ","qname-space: Production","User-Agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/045912 Mobile Safari/537.36 V1_AND_SQ_8.3.9_343_TIM_D QQ/3.4.3.3048 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1015712","Content-Type: application/json","Origin: https://ti.qq.com","X-Requested-With: com.tencent.tim","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Accept-Encoding: gzip, deflate, br","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Cookie: uin=o".$uin.";skey=".$skey.";p_skey=".$pskey.";p_uin=o".$uin."; a2=6E8C901B9F98C3375BE9E2F1F0F0F9621DF54EF843A496A74B63B630A1B855797856F455081CD232821949A80EEE5807564BF070C0D8661FB16E30DD5EE3FE874E2000DA1469C0E3; pgv_info=ssid=s930570908; ts_last=ti.qq.com/friendship_auth/index.html; pgv_pvid=8224990244; ts_uid=9256424975","Q-UA2: QV=3&PL=ADR&PR=TRD&PP=com.tencent.tim&PPVN=3.4.3&TBSVC=44090&CO=BK&COVC=045912&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= RedmiK30 &RL=1080*2261&OS=11&API=30","Q-GUID: 24ddbae09e556090ea5d668413b788cb","Q-QIMEI: fa96e4eb0f6fad3937877892100019215205","QIMEI36: b53787c1c4a31f0f9d4fd4ea10001c315206","q-header-ctrl: 7","Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b");
$url="https://ti.qq.com/proxy/domain/oidb.tim.qq.com/v3/oidbinterface/oidb_0x587_75?sdkappid=39998&actype=2&bkn=".getGTK($pskey);
if($type=="1"){
$data='{"uint32_allow":1}';
}elseif($type=="2"){
$data='{"uint32_allow":2}';
}
$data=curl($url,$data,$header);
print_r($data);