<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$qq=$_GET['uin'];
$skey=$_GET['skey'];
$get=getGTK($skey);
$timy=date("Y");
$timm=date("m");
$timm=str_replace("01", "1",$timm);
$timm=str_replace("02", "2",$timm);
$timm=str_replace("03", "3",$timm);
$timm=str_replace("04", "4",$timm);
$timm=str_replace("05", "5",$timm);
$timm=str_replace("06", "6",$timm);
$timm=str_replace("07", "7",$timm);
$timm=str_replace("08", "8",$timm);
$timm=str_replace("09", "9",$timm);
$timm=str_replace("10", "10",$timm);
$timm=str_replace("11", "11",$timm);
$timm=str_replace("12", "12",$timm);
$url="https://proxy.vac.qq.com/cgi-bin/srfentry.fcgi?ts=1584749452821&g_tk=".$get;
$post='{"13357":{"month":'.$timm.',"pageIndex":1,"pageSize":20,"sUin":"'.$qq.'","year":'.$timy.'}}';
$header=array("Cookie: uin=o".$qq.";skey=".$skey.";p_skey=".$pskey.";p_uin=o".$qq.";ldw=".$ldw."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36");
$data=curl($url,$post,$header);
$data=json_decode($data,true);
$aa=date('Y-m-d H:i:s',$aa);
echo "QQ:".$qq."\n--成长来源--\n";
foreach ($data["13357"]["data"]["growthRecord"]["record"] as $key => $value)
{
if(date('Ymd', $value["acttime"]) == date('Ymd')) {
if(empty($value["actname"])){
$actname="活动赠送";
}else{
$actname=$value["actname"];
}
echo "[".$actname."]:+".$value["finaladd"]."成长值\n";
}else{
}
}

