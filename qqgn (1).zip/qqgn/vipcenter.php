<?php
header("Content-Type:text/html;charset=UTF-8");//输出头
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$uin=$_GET['uin'];
$skey=$_GET['skey'];
$pskey=$_GET['pskey'];
$url="https://m.vip.qq.com/default/userv2?ADTAG=vipcenter&_nav_alpha=true&_nav_txtclr=000000&_nav_titleclr=000000&_wv=1025&_wwv=4";
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_uin=o".$uin.";p_skey=".$pskey."");
$data=curl($url,null,$header);
$json=getSubstr($data,'var G_INFO = ',';');
preg_match_all('/currentSpeed:(.*?),/',$json,$currentSpeed);
preg_match_all('/maxSpeed:(.*?),/',$json,$maxSpeed);
preg_match_all('/<em>(.*?)<\/em><span>(.*?)<\/span>/',$data,$data);
$maxSpeed=$maxSpeed[1][0];
$currentSpeed=$currentSpeed[1][0];
$total=$data[1][0];
$rank=$data[1][1];
$array=array('uin'=>$uin,'currentSpeed'=>$currentSpeed,'maxSpeed'=>$maxSpeed,'totalSpeed'=>$total,'friendrank'=>$rank);
print_r(jsonjx($array));


