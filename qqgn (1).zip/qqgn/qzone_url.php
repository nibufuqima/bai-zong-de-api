<?php
//说说链接
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$n=$_REQUEST["n"];
$qq=$_REQUEST["qq"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://user.qzone.qq.com/proxy/domain/taotao.qq.com/cgi-bin/emotion_cgi_msglist_v6?uin=".$qq."&ftype=0&sort=0&pos=0&num=20&replynum=100&g_tk=".getGTK($pskey)."&callback=_preloadCallback&code_version=1&format=jsonp&need_private_comment=1&g_tk=".getGTK($pskey);
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com","accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
$json=curl($url,null,$header);
$data=getSubstr($json,'_preloadCallback(',');');
$json=json_decode($data,true);
$data=$json["msglist"][$n-1];
if($json["msglist"]==null){
echo "该好友空间没有说说!";
exit();
}
if($n==null){
foreach ($json["msglist"] as $key => $value)
{

echo ($key+1).":".substr($value["conlist"][0]["con"],0,60)."…\n";

}
}else{
$dat=$data["conlist"][0]["con"]?:"这是一条高级说说。";
//print_r("内容:".$dat."\n\nmobile.qzone.qq.com/l?g=279&_wv=1&i=".$data["tid"]."&u=".$qq."&a=311&sg=84&sharetag=&jumptoqzone=1");
print_r('{"app":"com.tencent.structmsg","desc":"音乐","view":"music","ver":"0.0.0.1","prompt":"[分享]空间说说","appID":"","sourceName":"","actionData":"","actionData_A":"","sourceUrl":"","meta":{"music":{"action":"","Android_pkg_name":"","app_type":1,"appid":100495085,"desc":"'.$dat.'","jumpUrl":"http://mobile.qzone.qq.com/l?g=279&_wv=1&i='.$data["tid"].'&u='.$qq.'&a=311&sg=84&sharetag=&jumptoqzone=1","musicUrl":"","preview":"http://q1.qlogo.cn/g?b=qq&nk='.$qq.'&s=640","sourceMsgId":"0","source_icon":"","source_url":"","tag":"空间说说","title":"空间说说"}},"text":"","sourceAd":""}');
}