<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$group=$_REQUEST["group"];
$Dat=$_REQUEST["lx"];
$Dat=$_REQUEST["data"];
$max=$_REQUEST["max"]?:"10";
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$type=$_REQUEST['type']?:"龙王";
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$bdlb=array(
"龙王" => "https://qun.qq.com/interactive/honorlist?gc=".$group."&type=1&_wv=3&_wwv=129",
"善财福禄寿" => "https://qun.qq.com/interactive/honorlist?gc=".$group."&type=14&_wv=3&_wwv=129",
"快乐源泉" => "https://qun.qq.com/interactive/honorlist?gc=".$group."&type=6&_wv=3&_wwv=28",
"群聊之火" => "https://qun.qq.com/interactive/honorlist?gc=".$group."&type=2&_wv=3&_wwv=28",
"群聊炽焰" => "https://qun.qq.com/interactive/honorlist?gc=".$group."&type=3&_wv=3&_wwv=28"
);
$url=$bdlb[$type];
$header=array("User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.5_1858_YYB_D A_8080500 QQ/8.8.5.5570 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data=null;
$return=get_result($url,$data,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$url=getSubstr($return,$left,$right);
$json=json_decode($url,true);
if($Dat=="json"){
print_r(jsonjx($json));
}
else{
if($type=="龙王"){
$data=$json["talkativeList"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["name"]."-".$value["uin"]."\n";
echo $value["desc"]."\n";

}
}elseif($type=="快乐源泉"){
$data=$json["actorList"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["name"]."-".$value["uin"]."\n";
echo $value["desc"]."\n";

}
}elseif($type=="群聊之火"){
$data=$json["actorList"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["name"]."-".$value["uin"]."\n";
echo $value["desc"]."\n";

}
}elseif($type=="群聊炽焰"){
$data=$json["actorList"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["name"]."-".$value["uin"]."\n";
echo $value["desc"]."\n";

}
}elseif($type=="redpacketHonnorList"){
$data=$json["redpacketHonnorList"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["name"]."-".$value["uin"]."\n";
echo $value["desc"]."\n";

}
}
}

