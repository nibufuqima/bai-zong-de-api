<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$title=$_REQUEST['title']?:"小白";
$msg=$_REQUEST['msg']?:"小白";
$group=$_REQUEST['group'];
$max=$_REQUEST["max"]?:"15";
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qun.qq.com/cgi-bin/homework/hw/assign_hw.fcg";
$data='homework_id=&group_id='.$group.'&course_id=2&course_name='.$title.'&title=作业&need_feedback=0&c={"c":[{"type":"str","text":"\n'.$msg.'}]}&team_id=0&hw_type=0&tsfeedback=&syncgids=&client_type=1&bkn='.getGTK($skey);
$header=array("Cookie: RK=ZJbgfBX7mx; pgv_pvid=893247738; ptcz=6f33856d6cd1038b6cdd2029fc8a63754a49cf613a0078893256c870c682327f; p_skey=".$pskey."; p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; traceid=a9cba1831b");
$data=curl($url,$data,$header);
$json=json_decode($data,true);
if($json["retcode"]!="0"){
print_r("执行错误！");
exit();
}
print_r($data);