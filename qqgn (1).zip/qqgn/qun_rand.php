<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$group=$_REQUEST["group"];
$lx=$_REQUEST["lx"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$filename="data/qun/a".$group.date("d").".php";
if (file_exists($filename)) {
$list=curl("".ym."/API/qqgn/".$filename);
$list=json_decode($list);
if($lx==null){
print_r(jsonjx($list));
}else if($lx=="rand"){
$s=mt_rand(0,count($list)-1);
print_r($list[$s]);
}
} else {
$header=array("User-Agent: Mozilla/5.0 (Linux; Android 9; Redmi 6 Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.5_1858_YYB_D A_8080500 QQ/8.8.5.5570 NetType/WIFI WebP/0.3.0 Pixel/720 StatusBarHeight/49 SimpleUISwitch/1 QQTheme/2920 InMagicWin/0 StudyMode/0","Cookie: uin=o".$uin.";p_uin=o".$uin.";skey=".$skey.";p_skey=".$pskey."");
$data=curl("https://qun.qq.com/cgi-bin/qun_mgr/search_group_members?gc=".$group."&st=0&end=40&sort=0&bkn=".GetBkn($skey),null,$header);
$json=json_decode($data,true);
$start=40;
$end=80;
$array=[];
if($json["count"]<="40")
{
foreach($json["mems"] as $value)
{
$list[]=$value["uin"];

}
print_r(jsonjx($list));
}else{
$count=($json["count"]/40);
foreach($json["mems"] as $value)
{
$list[]=$value["uin"];

}
$count=($json["count"]/40);
for($i=0;$i<$count;$i++)
{
$data=curl("https://qun.qq.com/cgi-bin/qun_mgr/search_group_members?gc=".$group."&st=".$start."&end=".$end."&sort=0&bkn=".GetBkn($skey),null,$header);
$json=json_decode($data,true);
foreach($json["mems"] as $value)
{
$list[]=$value["uin"];

}
$start+40;
$end+80;
}
if($lx==null){
print_r(Back($list));
}else if($lx=="rand"){
$s=mt_rand(0,count($list)-1);
print_r($list[$s]["uin"]);
}else{
print_r(jsonjx($list));
}
}
$str = "<?php return " . var_export($list, true) . "; ";
file_put_contents($filename, $str);
file_put_contents($filename,jsonjx($list));
unlike("data/qun/a".$group.(date("d")-1).".php");
}