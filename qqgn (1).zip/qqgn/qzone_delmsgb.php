<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$id=$_REQUEST["id"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_uin=o".$uin.";p_skey=".$pskey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Referer: https://user.qzone.qq.com/","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: h5.qzone.qq.com");
$data="hostUin=".$uin."&idList=".$id."&uinList=".$uin."&format=fs&iNotice=1&inCharset=utf-8&outCharset=utf-8&ref=qzone&json=1&g_tk=".getGTK($skey)."&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2Fproxy%2Fdomain%2Fqzs.qq.com%2Fqzone%2Fmsgboard%2Fmsgbcanvas.html%23page%3D1";
$url="https://h5.qzone.qq.com/proxy/domain/m.qzone.qq.com/cgi-bin/new/del_msgb?&g_tk=".getGTK($skey);
$data=curl($url,$data,$header);
$data=getSubstr($data,'frameElement.callback(',');');
$json=json_decode($data,true);
$code=$json["code"];
$message=$json["message"];
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
if($code=="-3000"){
print_r($message);
}
if($code=="0"){
print_r($message);
}
if($code=="-4404"){
print_r("留言不存在或已被删除");
}}


