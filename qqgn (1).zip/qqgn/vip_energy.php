<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$max=$_REQUEST["max"]?:"20";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; Redmi K30 Build/SKQ1.210908.001) V1_AND_SQ_8.8.85_2712_YYB_D A_8088500 QQ/8.8.85.7685 NetType/WIFI WebP/0.4.1 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537116199","Content-Type: application/json","Host: club.vip.qq.com","Connection: Keep-Alive","Accept-Encoding: gzip","Cookie: p_uin=o".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ");
$url="https://club.vip.qq.com/qqvalue/rank?gc=";
$data=curl($url,0,$header);
$data=getSubstr($data, "window.__INITIAL_STATE__=", ";(function()");
$data=json_decode($data,true);
Back($data["qqvalue-rank"]["value"]);

