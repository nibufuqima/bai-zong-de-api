<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$group=$_REQUEST["group"];
$type=$_REQUEST["type"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Host: qun.qq.com","accept: application/json, text/plain, */*","qname-service: 976321:131072","qname-space: Production","traceparent: 00-9033141f1f507e5370ce6cde7bf24fc3-e66c71adb5308031-01","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/045909 Mobile Safari/537.36 V1_AND_SQ_8.8.50_2324_YYB_D A_8085000 QQ/8.8.50.6735 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/2001182 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0","content-type: application/json;charset=UTF-8","origin: https://qun.qq.com","sec-fetch-site: same-origin","sec-fetch-mode: cors","sec-fetch-dest: empty","Referer: https://qun.qq.com/v2/luckyword/index?qunid=".$group."&_wv=67108865&_nav_txtclr=FFFFFF&_wvSb=0&source=enter","accept-encoding: gzip, deflate, br","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","q-ua2: QV=3&PL=ADR&PR=QQ&PP=com.tencent.mobileqq&PPVN=8.8.50&TBSVC=44126&CO=BK&COVC=045909&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= RedmiK30 &RL=1080*2261&OS=11&API=30","q-guid: 21d8b77b9a1747d1f878318113b788cb","q-qimei: fa96e4eb0f6fad3937877892100019215205","qimei36: b53787c1c4a31f0f9d4fd4ea10001c315206","q-header-ctrl: 7","q-auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b");
$url="https://qun.qq.com/v2/luckyword/proxy/domain/qun.qq.com/cgi-bin/group_lucky_word/setting?bkn=".GetBkn($skey);
$data='{"group_code":'.$group.',"cmd":"'.$type.'"}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
print_r($data);