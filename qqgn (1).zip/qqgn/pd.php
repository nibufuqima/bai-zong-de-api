<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$url=file_get_contents("http://api.unipay.qq.com/v1/r/1450000172/wechat_query?cmd=7&session_id=uin&session_type=skey&openid=".$uin."&openkey=".$skey);
$json=json_decode($url,true);
print_r($json["ret"]);
