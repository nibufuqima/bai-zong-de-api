
<html>
<title>腾讯QQ支付-API</title>
  <!-- Bootstrap core CSS -->
  <link href="//lib.baomitu.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
  <!-- Component CSS -->
  <link rel="stylesheet" type="text/css" href="/static/css/components.min.css">
  <link rel="stylesheet" type="text/css" href="/static/css/style.css">
  <!-- Required Javascript Files -->
  <script type="text/javascript" src="//lib.baomitu.com/jquery/1.12.4/jquery.min.js"></script>
  <script type="text/javascript" src="//lib.baomitu.com/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="//lib.baomitu.com/layer/3.1.1/layer.js"></script>
  <link rel="stylesheet" href="//lib.baomitu.com/layer/3.1.1/theme/default/layer.css?v=3.1.1" id="layuicss-layer">
  <!--[if lt IE 9]>
<script src="//lib.baomitu.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="//lib.baomitu.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
                    <div class="tabbed" id="req">
                  <div class="panel panel-info">
                    <div class="panel-heading">
                      <h3 class="panel-title">请求地址</h3>
                    </div>
                    <div class="panel-body">
                     http://xiaobai.klizi.cn/API/qqgn/tenxun_hb.php
                    </div>
<h6>特别提示，本API非PHP架设，采用腾讯官方技术进行特殊服务，如您有本事您可以找后台</h6>
                  </div>
                  <div class="panel panel-info">
                    <div class="panel-heading">提交参数</div>
                    <table class="table">
                      <thead>
                        <tr class="active">
                          <th>参数名</th>
                          <th>类型</th>
                          <th>是否必须</th>
                          <th>描述</th>
                          <th>示例值</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>uin</td>
                          <td>String</td>
                          <td>是</td>
                          <td>QQ号</td>
                          <td>10001</td>
                        </tr>

                        <tr>
                          <td>je</td>
                          <td>String</td>
                          <td>是</td>
                          <td>发送金额（1为0.01元）</td>
                          <td>1</td>
                        </tr>
<tr>
                         <td>sl</td>
                          <td>String</td>
                          <td>是</td>
                          <td>发送的数量</td>
                          <td>1</td>
                        </tr>
                        <tr>
                         <td>zf</td>
                          <td>String</td>
                          <td>否</td>
                          <td>红包的祝福</td>
                          <td>恭喜发财</td>
                        </tr>
                        <tr>
                         <td>pskey</td>
                          <td>String</td>
                          <td>是</td>
                          <td>财付通的pskey</td>
                          <td></td>
                        </tr> 
                        <tr>
                         <td>zfmm</td>
                          <td>String</td>
                          <td>是</td>
                          <td>您的6位数支付密码</td>
                          <td>123456</td>
                        </tr> 
                        
                        <tr>
                         <td>jsdx</td>
                          <td>String</td>
                          <td>是</td>
                          <td>群为群号好友为QQ讨论组为讨论组ID</td>
                          <td>123456789</td>
                        </tr> 
<tr>
                         <td>xxlx</td>
                          <td>String</td>
                          <td>是</td>
                          <td>1.好友；2.讨论组；3.群</td>
                          <td>123456789</td>
                        </tr> 
<tr>
                         <td>zflx</td>
                          <td>String</td>
                          <td>是</td>
                          <td>1.拼手气； 2.普通；3.口令；4.语音；5.专享；6.转账</td>
                          <td>2</td>
                        </tr> 
<tr>
                         <td>kqdx</td>
                          <td>String</td>
                          <td>否</td>
                          <td>专享的接收对象</td>
                          <td>10001</td>
                        </tr> 
<tr>
                         <td>hbpf</td>
                          <td>String</td>
                          <td>否</td>
                          <td>红包的皮肤（不填为默认）</td>
                          <td></td>
                        </tr> 
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                      </tbody>
                    </table>
                  </div>

                  <div class="section">
                    <h6 class="pre_tit">回调返回结果示例</h6>
                    <pre class="well">
                    {
                    "retcode":"0",
                    "retmsg":"ok",
                    "send_listid":"10000452012107113600103364815500",
                    "send_uin":"10001",
                    "send_name":"NSW",
                    "state":"1",
                    "bus_type":"1"
                    }
</pre>
                  </div>
                </div>

  <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="/static/js/chosen/chosen.jquery.min.js"></script>
  <script type="text/javascript" src="/clipboard.min.js"></script>
  <script type="text/javascript" src="/static/js/iCheck/icheck.min.js"></script>
  <script type="text/javascript" src="/static/application.fn.js"></script>
  <script type="text/javascript" src="/static/application.js"></script>
  <script type="text/javascript" src="/static/server.js"></script>
  <script type="text/javascript">var clipboard = new ClipboardJS('#copy');
</html>





































