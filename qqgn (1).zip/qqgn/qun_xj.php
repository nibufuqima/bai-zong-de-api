<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$group=$_REQUEST["group"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.5_1858_YYB_D A_8080500 QQ/8.8.5.5570 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1046369 InMagicWin/0 StudyMode/0","Referer: https://qqweb.qq.com/m/business/qunlevel/index.html?gc=".$group."&from=0&_wv=1027");
$url="https://qqweb.qq.com/c/activedata/get_credit_level_info?bkn=".GetBkn($skey)."&uin=".$uin."&gc=".$group;
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
$array=array('group_role'=>$json["info"]["group_role"],'group_name'=>$json["info"]["group_name"],'group_owner'=>$json["info"]["group_owner"],'group_uin'=>$json["info"]["group_uin"],'uiGroupLevel'=>$json["info"]["uiGroupLevel"]);
print_r(jsonjx($array));
}
