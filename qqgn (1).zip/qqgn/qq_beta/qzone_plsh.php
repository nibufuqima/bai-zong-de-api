<?php
//评论审核
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$max=$_REQUEST["max"]?:"10";
$type=$_REQUEST["type"]?:"1";
$lx=$_REQUEST["lx"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://user.qzone.qq.com/proxy/domain/m.qzone.qq.com/cgi-bin/new/msgb_verify_switch.cgi?&g_tk=".getGTK($pskey);
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$bdlb=array(
"1" => "uin=".$uin."&turn_on=1&ref=qzone&format=fs&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fprofile%2Fpermi",//开
"2" => "uin=".$uin."&turn_on=0&ref=qzone&format=fs&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fprofile%2Fpermit",//关
);
$data=$bdlb[$type];
$json=curl($url,$data,$header);
$data=getSubstr($json,'frameElement.callback(',');');
$json=json_decode($data,true);
$code=$json["code"];
if($code=="-3000"){
print_r("Cookie失效，请重新获取！");
}elseif($code=="0"){
print_r("操作成功!");
}else{
print_r("操作失败!");
}

