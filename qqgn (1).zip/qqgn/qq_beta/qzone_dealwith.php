<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$n=$_REQUEST["n"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$type=$_REQUEST["type"];
$max=$_REQUEST["max"]?:"10";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_uin=o".$uin.";p_skey=".$pskey."","Host: user.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/r.qzone.qq.com/cgi-bin/tfriend/getfriendmsglist.cgi?uin=".$uin."&fupdate=1&rd=&version=8&g_tk=".getGTK($pskey)."&g_tk=".getGTK($pskey);
$data=curl($url,null,$header);
$data=str_replace('_Callback(','',$data);
$data=str_replace(');','',$data);
$data=str_replace('0x0','"0x0"',$data);
$json=json_decode($data,true);
$qq=$json["data"]["items"][$n -1]["uin"];
$name=$json["data"]["items"][$n -1]["name"];
$time=$json["data"]["items"][$n -1]["time"];
if(empty($n)){
foreach ($json["data"]["items"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["name"]."(".$value["uin"].")\n";
echo "状态:".str_replace('no','未处理',str_replace('yes','已处理',$value["isfrd"]))."\n";
echo "-----------------\n";
}
}else{
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_uin=o".$uin.";p_skey=".$pskey."","Host: user.qzone.qq.com","user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","content-type: application/x-www-form-urlencoded;charset=UTF-8","accept: */*","origin: https://user.qzone.qq.com","x-requested-with: mark.via","sec-fetch-site: same-origin","sec-fetch-mode: cors","sec-fetch-dest: empty","referer: https://user.qzone.qq.com/1242619315/infocenter?via=toolbar&_t_=0.5540275878033614","accept-encoding: gzip, deflate","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$url="https://user.qzone.qq.com/proxy/domain/w.qzone.qq.com/cgi-bin/tfriend/procfriendreq.cgi?=&g_tk=".getGTK($pskey);
$dat="uin=".$uin."&ouin=".$qq."&flag=100&key=".$qq."&msgTime=".$time."&type=".$type."&groupId=0&from_source=11";
$data=curl($url,$dat,$header);
$data=getSubstr($data,'frameElement.callback(',');');
print_r($data);

}

