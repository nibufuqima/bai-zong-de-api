<?php
error_reporting(0);
include("../../inc/config.php");
$database_name=$dbconfig["database_name"];
$username=$dbconfig["username"];
$password=$dbconfig["password"];
$mysql=@new mysqli("localhost",$username,$password,$database_name);

function tongji($id)
{
$sql="SELECT * FROM `transfer` WHERE id = '".$id."'";
$data=$GLOBALS["mysql"]->query($sql);
if($data->num_rows==0)
{
$date=json_encode(array(date("Y-m-d")=>1));
$sql="INSERT INTO `transfer` (`id`, `date`, `total`) VALUES ('".$id."', '".$date."', '1')";
}else{
$info=$data->fetch_assoc();
$array=json_decode($info["date"],true);
if(!$array[date("Y-m-d")])
{
$array[date("Y-m-d")]=0;
}
foreach($array as $key=>$value)
{
if($key==date("Y-m-d"))
{
$arr[$key]=$value+1;
}else{
$arr[$key]=$value;
}
}
$arr=json_encode($arr);
$sql="UPDATE transfer SET date='".$arr."',total='".($info["total"]+1)."' WHERE id = '".$id."'";
}
$GLOBALS["mysql"]->query($sql);
}

?>