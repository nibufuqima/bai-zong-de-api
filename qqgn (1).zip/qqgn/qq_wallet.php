<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$Dat=$_REQUEST["data"];
$time=date("Y-m-d");
if(!$uin || !$skey){
print_r("参数不完整!需要参数:uin，skey");
exit();
}
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey.";  p_skey=".$pskey.";","Host: myun.tenpay.com","accept: application/json","cache-control: no-cache, no-store","x-requested-with: XMLHttpRequest","sec-fetch-mode: cors","sec-fetch-site: same-origin","accept-encoding: gzip, deflate, br","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$url="https://myun.tenpay.com/cgi-bin/clientv1.0/qwallet_account_list.cgi?limit=10&offset=0&s_time=".$time."&time_type=0&source_type=7&pay_type=2&ref_param=&skey=".$skey."&skey_type=2&uin=".$uin;
$json=curl($url,null,$header);
$json=json_decode($json,true);
$money=($json["records"][0]["balance"]/100);
$url=file_get_contents("http://api.unipay.qq.com/v1/r/1450000186/wechat_query?cmd=4&pf=vip_m-pay_html5-html5&pfkey=pfkey&from_h5=1&from_https=1&format=jsonp__getQBBalance&openid=".$uin."&openkey=".$skey."&session_id=uin&session_type=skey");
preg_match_all('/"ret" : (.*?),/',$url,$ret);
$ret=$ret[1][0];
preg_match_all('/"qb_balance" : (.*?),/',$url,$qb_balance);
$qb_balance=$qb_balance[1][0];
$qb_balance=($qb_balance/100);
$array=array('retcode'=>$json["retcode"],'retmsg'=>$json["retmsg"],'money'=>$money,'qb'=>$qb_balance);
print_r(jsonjx($array));

