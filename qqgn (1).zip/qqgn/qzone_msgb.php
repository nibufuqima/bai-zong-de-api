<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$qq=$_REQUEST["qq"]?:$uin;
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$qq){
print_r("参数不完整!需要参数:uin，skey，pskey，qq");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_uin=o".$uin.";p_skey=".$pskey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Referer: ","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/m.qzone.qq.com/cgi-bin/new/get_msgb?uin=".$uin."&hostUin=".$qq."&num=50&start=0&hostword=0&essence=1&r=0.3455533687868455&iNotice=0&inCharset=utf-8&outCharset=utf-8&format=jsonp&ref=qzone&g_tk=".getGTK($skey);
$data=curl($url,$data,$header);
$data=str_replace('_Callback(','',$data);
$data=str_replace(');','',$data);
$json=json_decode($data,true);
$code=$json["code"];
$message=$json["message"];
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
if($code=="-4001"){
print_r("您还没有登陆,请先登陆");
}
if($code=="0"){
if(empty($json["data"]["commentList"])){
die('留言列表空空!');
}else{
foreach ($json["data"]["commentList"] as $key => $value){
if($key==10){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["ubbContent"]."\n";
echo "id:".$value["id"]."\n";
}
}}
}


