<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("hs.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$fid=$_REQUEST['fid'];
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
if(empty($fid)){
print_r("fid值不能为空");
exit();
}
$url="https://web.qun.qq.com/cgi-bin/announce/del_feed?bkn=".getGTK($skey);
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Referer: https://web.qun.qq.com/mannounce/detail.html");
$data="qid=".$group."&bkn=".getGTK($skey)."&fid=".$fid."";
$return=get_result($url,$data,$header);
print_r($return);