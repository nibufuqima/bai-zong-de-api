<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$id=$_REQUEST["id"];
$qq=$_REQUEST["qq"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$Dat=$_REQUEST["data"];
if(!$uin || !$skey || !$pskey || !$qq){
print_r("参数不完整!需要参数:uin，skey，pskey，qq");
exit();
}
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey.";  p_skey=".$pskey.";","Host: ti.qq.com","Connection: keep-alive","Accept: application/json, text/plain, */*","qname-service: 1104449:131072","qname-space: Production","traceparent: 00-a71936dbc07e67d78cb31f12d214cdde-55923274f82fa991-01","User-Agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/045909 Mobile Safari/537.36 V1_AND_SQ_8.8.50_2324_YYB_D A_8085000 QQ/8.8.50.6735 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/2001182 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0","Content-Type: application/json","Origin: https://ti.qq.com","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Referer: https://ti.qq.com/interactive_logo/word?target_uin=".$qq."&auto_take=1&_wv=67108865&_nav_txtclr=FFFFFF&_wvSb=0","Accept-Encoding: gzip, deflate, br","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Q-UA2: QV=3&PL=ADR&PR=QQ&PP=com.tencent.mobileqq&PPVN=8.8.50&TBSVC=44126&CO=BK&COVC=045909&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= RedmiK30 &RL=1080*2261&OS=11&API=30","Q-GUID: 21d8b77b9a1747d1f878318113b788cb","Q-QIMEI: fa96e4eb0f6fad3937877892100019215205","QIMEI36: b53787c1c4a31f0f9d4fd4ea10001c315206","q-header-ctrl: 7","Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b");
$url="https://ti.qq.com/interactive_logo/word/proxy/domain/oidb.tim.qq.com/v3/oidbinterface/oidb_0xdd1_0?sdkappid=39998&actype=2&bkn=".GetBkn($skey);
$data='{"uin":'.$uin.',"frd_uin":'.$qq.',"card_id":"'.$id.'"}';
$json=curl($url,$data,$header);
print_r($json);


