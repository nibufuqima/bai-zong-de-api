<?php
//说说点赞
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$fid=$_REQUEST["tid"];
$qq=$_REQUEST["qq"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://user.qzone.qq.com/proxy/domain/w.qzone.qq.com/cgi-bin/likes/internal_dolike_app?g_tk=".getGTK($pskey);
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com","accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
$data="qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Finfocenter%3Fvia%3Dtoolbar&opuin=".$uin."&unikey=http%3A%2F%2Fuser.qzone.qq.com%2F".$qq."%2Fmood%2F".$fid."&curkey=http%3A%2F%2Fuser.qzone.qq.com%2F".$qq."%2Fmood%2F".$fid."&from=1&appid=311&typeid=0&abstime=".time()."&fid=".$fid."&active=0&fupdate=1";
$json=curl($url,$data,$header);
$data=getSubstr($json,'frameElement.callback(',');');
$json=json_decode($data,true);
//print_r($json);
$code=$json["code"];
if($code=="-3000"){
print_r("Cookie失效，请重新获取！");
}elseif($code=="0"){
print_r("操作成功!");
}else{
print_r("操作失败!");
}

