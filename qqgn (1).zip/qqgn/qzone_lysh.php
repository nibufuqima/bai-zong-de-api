<?php
//留言审核
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$max=$_REQUEST["max"]?:"10";
$type=$_REQUEST["type"]?:"1";
$lx=$_REQUEST["lx"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://user.qzone.qq.com/proxy/domain/w.qzone.qq.com/cgi-bin/right/set_revertright.cgi?&g_tk=".getGTK($pskey);
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$bdlb=array(
"1" => "uin=".$uin."&bit=1&fupdate=1&qzreferrer=https%253A%252F%252Fuser.qzone.qq.com%252F".$uin."%252Finfocenter%253Fvia%253Dtoolbar%2526_t_%253D0.9598141106270388",//所有人
"2" => "uin=".$uin."&bit=4&fupdate=1&qzreferrer=https%253A%252F%252Fuser.qzone.qq.com%252F".$uin."%252Finfocenter%253Fvia%253Dtoolbar%2526_t_%253D0.9598141106270388",//好友
"3" => "uin=".$uin."&bit=1&fupdate=1&qzreferrer=https%253A%252F%252Fuser.qzone.qq.com%252F".$uin."%252Finfocenter%253Fvia%253Dtoolbar%2526_t_%253D0.9598141106270388",//自己
);
$data=$bdlb[$type];
$json=curl($url,$data,$header);
$data=getSubstr($json,'frameElement.callback(',');');
print_r($data);

