<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$id=$_REQUEST["id"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$header=array("Cookie: uin=o".$uin."; p_uin=o".$uin."; skey=".$skey."; p_skey=".$pskey.";","Host: proxy.vip.qq.com","accept: application/json, text/plain, */*","User-agent: Mozilla/5.0 (Linux; Android 9; Redmi 6 Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/045814 Mobile Safari/537.36 V1_AND_SQ_8.8.33_2126_HDBM_T A_8083300 QQ/8.8.33.6240 NetType/WIFI WebP/0.3.0 Pixel/720 StatusBarHeight/49 SimpleUISwitch/1 QQTheme/2920 InMagicWin/0 StudyMode/0 CurrentMode/1 CurrentFontScale/1.0","content-type: application/x-www-form-urlencoded","origin: https://club.vip.qq.com","sec-fetch-site: same-site","sec-fetch-mode: cors","sec-fetch-dest: empty","Referer: https://club.vip.qq.com/","accept-encoding: gzip, deflate, br","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$data='{"13019":{"stReq":{"stLogin":{"iKeyType":1,"iOpplat":2,"lUin":'.$uin.',"sClientIp":"","sClientVer":"8.8.33","sSKey":"'.$skey.'"},"stNamePlate":{"viptypeid":2,"issetpendant":0,"pendantid":0},"stUniBusinessItem":{"appid":34,"itemid":'.$id.'}}}}';
$url="https://proxy.vip.qq.com/cgi-bin/srfentry.fcgi?ts=".msectime()."&daid=18&g_tk=".GetGTK($pskey)."&pt4_token=";
$data=curl($url,$data,$header);
print_r($data);


function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    
    return $msectime;
}


