<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$group=$_REQUEST["group"];
$uin=$_REQUEST["uin"];
$qq=$_REQUEST["qq"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Referer: https://qun.qq.com/member.html");
$url="https://qun.qq.com/cgi-bin/qun_mgr/add_group_member";
$data='gc='.$group.'&ul='.$qq.'&bkn='.GetBkn($skey);
$data=curl($url,$data,$header);
$json=json_decode($data,true);
print_r($data);
