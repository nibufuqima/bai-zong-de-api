<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$msg=$_REQUEST['msg'];
if(!$uin || !$skey || !$pskey || !$msg){
print_r("参数不完整!需要参数:uin，skey，pskey，msg");
exit();
}
$url="https://qun.qq.com/cgi-bin/group_search/pc_group_search";
$data="k=%E4%BA%A4%E5%8F%8B&n=8&st=1&iso=1&src=1&v=5833&bkn=1485872922&isRecommend=false&city_id=0&from=1&newSearch=true&penetrate=&keyword=php&sort=0&wantnum=24&page=0&ldw=1485872922";
$header=array("Cookie: RK=ZJbgfBX7mx; pgv_pvid=893247738; ptcz=6f33856d6cd1038b6cdd2029fc8a63754a49cf613a0078893256c870c682327f; p_skey=YSWt2*sA3dtc5qwhS6FG8-Eps7jqZ2gNJ7XWju6zSFc_; p_uin=o2985490393; uin=o2985490393; skey=ZlJ5ZPoBCr; traceid=a9cba1831b");

$data=curl($url,$data,$header);

print_r($data);
