<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$type=$_REQUEST['n'];
$n=($type -1);
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$msg=$_REQUEST['title'];
$op=$_REQUEST['op']?:"[op1=1,op2=2,op3=3]";
$op=str_replace(',',"&",$op);
$op=str_replace('[','',$op);
$op=str_replace(']','',$op);
$pskey=$_REQUEST['pskey'];
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$time=date('Y-m-d H:i:s',strtotime('+1 day'));
$time2=($time - 1800);
$url="https://client.qun.qq.com/cgi-bin/feeds/publish_vote_client?_=".msectime();
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Referer: https://client.qun.qq.com/qqweb/m/qun/vote/form.html?_wv=1031&_bid=2035&src=3&groupuin=".$group."&role=2&svrt=".msectime()."&cvrt=".msectime()."");
$data="title=".$msg."&ni=1&".$op."&mo=1&dl=".strtotime($time)."&remind=".strtotime($time2)."&vsb=0&bkn=".getGTK($skey)."&qid=".$group;
$data=curl($url,$data,$header);
$json=json_decode($data,true);
print_r($data);
function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    
    return $msectime;
}
