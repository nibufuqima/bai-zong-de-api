<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$group=$_REQUEST["group"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$fileid=$_REQUEST["fileid"];
$folderid=$_REQUEST["folderid"];
$type=$_REQUEST["type"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
if($type=="delete"){
$url="https://pan.qun.qq.com/cgi-bin/group_file/delete_file";
$data='src=qpan&gc='.$group.'&bkn='.GetBkn($skey).'&bus_id=102&file_id='.$fileid.'&app_id=4&parent_folder_id='.$folderid.'&file_list={"file_list":[{"gc":'.$group.',"app_id":4,"bus_id":102,"file_id":"'.$fileid.'","parent_folder_id":"'.$folderid.'"}]}';
$data=curl($url,$data,array("Host: pan.qun.qq.com","Connection: keep-alive","Accept: application/json","Cache-Control: no-cache,no-store","User-Agent: Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) QQ/9.5.3.28008 Chrome/43.0.2357.134 Safari/537.36 QBCore/3.43.1298.400 QQBrowser/9.0.2524.400","X-Requested-With: XMLHttpRequest","Referer: https://pan.qun.qq.com/clt_filetab/groupShareClientNew.html?groupid=".$group."","Accept-Encoding: gzip, deflate","Accept-Language: en-US,en;q=0.8","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; "));
$data=json_decode($data,true);
Back($data);
}else{
if($folderid==null){
$url="https://pan.qun.qq.com/cgi-bin/group_file/get_file_list?gc=".$group."&bkn=".GetBkn($skey)."&start_index=0&cnt=50&filter_code=0&folder_id=%2F&show_onlinedoc_folder=1";
$data=curl($url,null,array("Host: pan.qun.qq.com","Connection: keep-alive","Accept: application/json","Cache-Control: no-cache,no-store","User-Agent: Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) QQ/9.5.3.28008 Chrome/43.0.2357.134 Safari/537.36 QBCore/3.43.1298.400 QQBrowser/9.0.2524.400","X-Requested-With: XMLHttpRequest","Referer: https://pan.qun.qq.com/clt_filetab/groupShareClientNew.html?groupid=".$group."","Accept-Encoding: gzip, deflate","Accept-Language: en-US,en;q=0.8","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; "));
$data=json_decode($data,true)["file_list"];
foreach ($data as $key => $value)
{
if($value["type"]=="2"){
$array=array('name'=>$value["name"],'folder_id'=>$value["id"]);
$data1[]=$array;
}elseif($value["type"]=="1"){
$array=array('name'=>$value["name"],'file_id'=>$value["id"]);
$data2[]=$array;
}
}
Back(array('code'=>"200",'folder'=>$data1,'file'=>$data2));
}else{
$url="https://pan.qun.qq.com/cgi-bin/group_file/get_file_list?src=qpan&gc=".$group."&bkn=".GetBkn($skey)."&folder_id=".$folderid."&start_index=0&cnt=30&filter_code=0&show_onlinedoc_folder=1&_ti=";
$data=curl($url,null,array("Host: pan.qun.qq.com","Connection: keep-alive","Accept: application/json","Cache-Control: no-cache,no-store","User-Agent: Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) QQ/9.5.3.28008 Chrome/43.0.2357.134 Safari/537.36 QBCore/3.43.1298.400 QQBrowser/9.0.2524.400","X-Requested-With: XMLHttpRequest","Referer: https://pan.qun.qq.com/clt_filetab/groupShareClientNew.html?groupid=".$group."","Accept-Encoding: gzip, deflate","Accept-Language: en-US,en;q=0.8","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; "));
$data=json_decode($data,true)["file_list"];
foreach ($data as $key => $value)
{
$array=array('name'=>$value["name"],'file_id'=>$value["id"]);
$data2[]=$array;
}
Back(array('code'=>"200",'file'=>$data2));
}

}

