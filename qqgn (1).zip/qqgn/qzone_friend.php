<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$n=$_REQUEST["n"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$max=$_REQUEST["max"]?:"10";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_uin=o".$uin.";p_skey=".$pskey."","Host: user.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/r.qzone.qq.com/cgi-bin/tfriend/getfriendmsglist.cgi?uin=".$uin."&fupdate=1&rd=&version=8&g_tk=".getGTK($pskey)."&g_tk=".getGTK($pskey);
$data=curl($url,null,$header);
$data=str_replace('_Callback(','',$data);
$data=str_replace(');','',$data);
$data=str_replace('0x0','"0x0"',$data);
$json=json_decode($data,true);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
if($json["code"]!="0"){
print_r($json["message"]);
exit();
}
foreach ($json["data"]["items"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo "账号:".$value["uin"]."\n";
echo "昵称:".$value["name"]."\n";
echo "时间:".strtotime($value["time"])."\n";
echo $value["desc"]."\n-----------------\n";
}
}

