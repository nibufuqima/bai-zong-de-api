<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$text=$_REQUEST['text'];
$pskey=$_REQUEST['pskey'];
$group=$_REQUEST['group'];
$max=$_REQUEST["max"]?:"10";
$Dat=$_REQUEST["data"];
$time=time();
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qun.qq.com/essence/index?gc=".$group."&_wv=3&_wwv=128&_wvx=2&_wvxBclr=f5f6fa";
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/045814 Mobile Safari/537.36 V1_AND_SQ_8.8.28_2092_YYB_D A_8082800 QQ/8.8.28.6155 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0");
$data=null;
$return=curl($url,null,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$json=getSubstr($return,$left,$right);
$json=json_decode($json,true);
if($Dat=="json"){
print_r(jsonjx($json));
}else{
//print_r($json);

foreach ($json["msgList"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["msg_content"][0]["text"]."\n";
}
}

