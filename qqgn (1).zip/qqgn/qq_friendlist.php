<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"]?:"hsjdjdhjdj";
$uin=$_REQUEST["uin"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin."; p_uin=o".$uin."; skey=".$skey."; p_skey=".$pskey.";");
$url="https://mobile.qzone.qq.com/friend/mfriend_list?qzonetoken=&g_tk=".getGTK($pskey)."&res_uin=&res_type=normal&format=json&count_per_page=30&page_index=0&page_type=0&mayknowuin=&qqmailstat=";
$data=curl($url,null,$header);
$json=json_decode($data,true);
$ec=$json["ec"];
print_r($data);

