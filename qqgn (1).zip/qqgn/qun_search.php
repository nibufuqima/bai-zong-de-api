<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$msg=$_REQUEST['msg'];
$max=$_REQUEST["max"]?:"15";
if(!$uin || !$skey || !$pskey || !$msg){
print_r("参数不完整!需要参数:uin，skey，pskey，msg");
exit();
}
$url="https://qun.qq.com/cgi-bin/group_search/pc_group_search";
$data="k=".$msg."&n=8&st=1&iso=1&src=1&v=5833&bkn=".getGTK($skey)."&isRecommend=false&city_id=0&from=1&newSearch=true&penetrate=&keyword=".$msg."&sort=0&wantnum=24&page=0&ldw=";
$header=array("Cookie: RK=ZJbgfBX7mx; pgv_pvid=893247738; ptcz=6f33856d6cd1038b6cdd2029fc8a63754a49cf613a0078893256c870c682327f; p_skey=".$pskey."; p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; traceid=a9cba1831b");
$data=curl($url,$data,$header);
$data=json_decode($data,true);
if($data["ec"]!="0"){
print_r("Cookie失效，请重新获取！");
exit();
}
foreach ($data["group_list"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo "群名:".$value["name"]."(".$value["gid"].")\n";
echo "标签:".$value["class_text"]."\n";
echo "简介:".$value["class_text"]."\n-----------------\n";
}
echo "腾讯提供技术服务!";