<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$msg=$_REQUEST["msg"]?:"666";
$skey=$_REQUEST["skey"];
$time1=$_REQUEST["time"];
$time=($time1*60);
$time=(time()+$time);
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey  || !$time){
print_r("参数不完整!需要参数:uin，skey，pskey,time");
exit();
}
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$data="syn_tweet_verson=1&paramstr=1&pic_template=&richtype=&richval=&special_url=&subrichtype=&con=".$msg."&feedversion=1&ver=1&ugc_right=1&to_sign=0&time=".$time."&hostuin=".$uin."&code_version=1&format=fs&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Finfocenter%3Fvia%3Dtoolbar";
$url="https://user.qzone.qq.com/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_publish_timershuoshuo_v6?&g_tk=".getGTK($pskey);
$data=curl($url,$data,$header);
$data=getSubstr($data,'frameElement.callback(',');');
$json=json_decode($data,true);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
if($json["subcode"]=="0"){
echo "当前操作:发布定时说说成功!\n发布时间:".$time1."分钟后\n说说内容:".$msg;
}elseif($json["code"]=="-3000"){
echo "cookie已失效!请重新获取";
}}
