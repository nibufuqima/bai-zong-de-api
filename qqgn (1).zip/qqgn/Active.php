<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("./API.php");
$skey=$_REQUEST["skey"];
$uin=$_REQUEST["uin"];
$qh=$_REQUEST["qh"];
$p_skey=$_REQUEST["p_skey"];
$sort=$_REQUEST["sort"]?$_REQUEST["sort"]:0;
$Ensemble=$_REQUEST["Ensemble"]?"":"2592000%7C7776000";
$num=($_REQUEST["num"]?$_REQUEST["num"]:20)-1;
if($skey==null) {
	echo json(1001,"text","请输入SKEY！");
	exit();
} else if($p_skey==null) {
	echo json(1002,"text","请输入P_skey！");
	exit();
} else if($uin==null) {
	echo json(1003,"text","请输入操作者QQ！");
	exit();
} else if($qh==null) {
	echo json(1004,"text","请输入群号码！");
	exit();
}
$haeder=[
'Cookie: ptui_loginuin='.$uin.'; p_uin=o'.$uin.'; uin=o'.$uin.'; skey='.$skey.'; p_skey='.$p_skey.';',
];
$return=curl("https://qun.qq.com/cgi-bin/qun_mgr/search_group_members","gc=".$qh."&st=0&end=".$num."&sort=".$sort."&last_speak_time=".$Ensemble."&bkn=".getBkn($skey),$haeder);
$data=json_decode($return,true);
if($data["ec"]==4) {
	echo json(1007,"text","Cookie已失效！");
	exit();
} else if($data["ec"]=="7") {
	echo json(1008,"text","无权操作！");
	exit();
} else if($data["ec"]=="-100005") {
	echo json(1009,"text","群号输入错误或目标QQ不存在！");
	exit();
} else if($data["ec"]=="0") {
//print_r($data);
foreach($data["mems"] as $k=>$v){
$array["data"][$k]=$v["uin"];
}
	echo json(1000,null,null,$array);
	exit();
} else {
	echo json(1010,"text","操作失败，错误码：".$data["ec"]);
	exit();
}