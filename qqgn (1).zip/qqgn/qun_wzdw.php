<?php
include("function.php");
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$uin=$_REQUEST["uin"];
$max=$_REQUEST["max"]?:"20";
$pskey=$_REQUEST["pskey"];
$group=$_REQUEST["group"];
$url="https://trpc.gamecenter.qq.com/?g_tk=".GetGTK($pskey);
$header=array("Origin: https://speed.gamecenter.qq.com","Cookie: p_skey=".$pskey.";uin=o".$uin.";","Content-Type: application/json","User-Agent: QQ/8.8.33 Android/0.17 Android/11","Host: trpc.gamecenter.qq.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$data='{"list":[{"msg":{"clientRPCName":"\/v1\/344"},"options":{"serializationType":2},"rawData":"{\"groupCode\":'.$group.'}"}]}';
$data=curl($url,$data,$header);
if($data==null){
echo "Cookie失效，请重新获取！";
exit();
}
$data=json_decode($data,true)["list"][0]["rawData"];
$json=json_decode($data,true);
foreach ($json["users_level_rank"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["base_info"]["nick"]."-".$value["hero_name"]."\n";
echo "\n------------------\n";
}
echo "小白API提供技术支持！";
