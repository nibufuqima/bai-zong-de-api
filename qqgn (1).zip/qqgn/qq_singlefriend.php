<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"]?:"hsjdjdhjdj";
$uin=$_REQUEST["uin"];
if(!$uin || !$skey){
print_r("参数不完整!需要参数:uin，skey");
exit();
}
$header=array("Cookie: uin=o".$uin."; p_uin=o".$uin."; skey=".$skey."; p_skey=".$pskey.";");
$url="https://mobile.qzone.qq.com/friend/mfriend_list?qzonetoken=&g_tk=".getGTK($pskey)."&res_uin=&res_type=normal&format=json&count_per_page=30&page_index=0&page_type=0&mayknowuin=&qqmailstat=";
$data=curl($url,null,$header);
$json=json_decode($data,true);
$data=$json["data"]["list"];
$code=$json["code"];
foreach ($data as $key => $value){
$qq=$value["uin"];
$header=array("Referer: https://client.show.qq.com/cgi-bin/qqshow_client_showinfo?g_tk=".getGTK($skey)."&omode=4&uin=".$uin."&touin=".$qq."&cmd=10413","Cookie: uin=o".$uin."; p_uin=o".$uin."; skey=".$skey."; p_skey=".$pskey."","User-Agent: Dalvik/2.1.0 (Linux; U; Android 11; Redmi K30 Build/RKQ1.200826.002)","Host: client.show.qq.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$url="https://client.show.qq.com/cgi-bin/qqshow_client_showinfo?g_tk=".getGTK($skey)."&omode=4&uin=".$uin."&touin=".$qq."&cmd=10413";
$data=curl($url,null,$header);
$json=json_decode($data,true);
if($json["code"]=="-1"){
$list[]=$qq;
}
}
$array=array('code'=>$code,'list'=>$list);
print_r(jsonjx($array));
