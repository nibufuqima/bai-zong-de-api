<?php
include("need.php");
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);

$group=$_REQUEST['group'];
$qq=$_REQUEST['uin'];
$skey=$_REQUEST['skey'];
$pskey=$_REQUEST['pskey'];
$type=$_REQUEST['type']?:"json";
if(!$qq || !$group || !$skey || !$pskey){
if($type == 'json'){
send(array("code"=>-1,"data"=>'',"msg"=>'所需参数不全!'));
}else{
echo '所需参数不全!';
}
exit;
}
$url="https://web.qun.qq.com/cgi-bin/notice/get_data_new";
$data = teacher_curl($url,[
    //请求连接
    'refer' => "https://web.qun.qq.com/",
    //请求Referer头部
    'cookie' => 'p_uin=o'.$qq.'; uin=o'.$qq.'; skey='.$skey.'; p_skey='.$pskey,
    //携带的cookie
    'ua' => 'Mozilla/5.0 (Linux; Android 11; Mi MIX 3 Build/RQ2A.210505.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/045814 Mobile Safari/537.36 V1_AND_SQ_8.8.23_2010_HDBM_T A_8082000 QQ/8.8.20.5870 NetType/4G WebP/0.3.0 Pixel/1080 StatusBarHeight/67 SimpleUISwitch/0 QQTheme/1000 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0',
    'post' => 'endtime='.time().'&src=1&bkn='.Get_BKN($skey).'&fnum=10&qid='.$group.'&gc='.$group.'&ver=8.8.88.7830',
]);
$data=json_decode($data,true);
if($type == 'json'){
if($data['ec'] == 0){
send(array("code"=>1,"data"=>$data['feeds']));
}else{
send(array("code"=>-2,"data"=>$data['feeds']));
}
exit;
}
if($data['ec'] == 0){
$data=$data['feeds'];
for($i=0;$i < count($data);$i++){
if($data[$i]['tag'] == "文件"){
}else if($data[$i]['tag'] == "群日历"){
echo ($i+1).".群日历.".$data[$i]['pub_uin'].":".$data[$i]['content'][0]['title']."，".$data[$i]['content'][0]['body']."(".date('Y-m-d H:i:s', $data[$i]['mod_time']).")\n";
}else if($data[$i]['tag'] == "公告"){
echo ($i+1).".公告.".$data[$i]['pub_uin'].":".$data[$i]['content'][1]['value']."(".date('Y-m-d H:i:s', $data[$i]['mod_time']).")\n";
}
}
}else{
echo "请求错误!";
}

