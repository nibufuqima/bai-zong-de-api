<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);

$uin = @$_REQUEST['uin']; //接收群号
header('Location:tencent://message/?uin='.$uin.'&Site=&Menu=yes');
