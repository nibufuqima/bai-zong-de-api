<?php
$url=$_REQUEST["url"];
$data = file_get_contents($url);
file_put_contents('diy.jpg',$data);

function imgBase64Decode($base64_image_content = '',$save_img = false,$path=''){
    if(empty($base64_image_content)){
        return false;
    }
 
    //匹配出图片的信息
    $match = preg_match('/^(data:\s*image\/(\w+);base64,)/', $base64_image_content, $result);
    if(!$match){
        return false;
    }
 
    //解码图片内容(方法一)
    /*$base64_image = preg_split("/(,|;)/",$base64_image_content);
    $file_content = base64_decode($base64_image[2]);
    $file_type = substr(strrchr($base64_image[0],'/'),1);*/
 
    //解码图片内容(方法二)
    $base64_image = str_replace($result[1], '', $base64_image_content);
    $file_content = base64_decode($base64_image);
    $file_type = $result[2];
 
    //如果不保存文件,直接返回图片内容
    if(!$save_img){
        return $file_content;
    }
 
    //如果没指定目录,则保存在当前目录下
    if(empty($path)){
        $path = __DIR__;
    }
    $file_path = $path."/".date('Ymd',time())."/";
    if(!is_dir($file_path)){
        //检查是否有该文件夹，如果没有就创建
        mkdir($file_path,0777,true);
    }
    $file_name = time().".{$file_type}";
    $new_file = $file_path.$file_name;
    if(file_exists($new_file)){
        //有同名文件删除
        @unlink($new_file);
    }
    if (file_put_contents($new_file, $file_content)){
        return $new_file;
    }
    return false;
}
