<?php
include("tj.php");
include("hs.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$qq=$_REQUEST['qq'];
$pskey=$_REQUEST['pskey'];
$op=$_REQUEST['op'];
$time=time();
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qun.qq.com/cgi-bin/qun_mgr/set_group_admin?bkn=".getGTK($skey);
$header=array("Connection：keep-alive","Accept-Language：zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2","User-Agent：Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0","Referer：https://qun.qq.com/member.html","Origin：https://qun.qq.com","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data="bkn=".getGTK($skey)."&ul=".$qq."&gc=".$group."&op=".$op."";
$return=get_result($url,$data,$header);
print_r($return);
