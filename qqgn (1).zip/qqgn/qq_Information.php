<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$lx=$_REQUEST["lx"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Host: ti.qq.com","Connection: keep-alive","Accept: application/json, text/plain, */*","qname-service: trpc.qqactivity.annual_count.annual_count","qname-space: Production","User-Agent: Mozilla/5.0 (Linux; Android 9; Redmi 6 Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/045912 Mobile Safari/537.36 V1_AND_SQ_8.8.50_2324_YYB_D A_8085000 QQ/8.8.50.6735 NetType/WIFI WebP/0.3.0 Pixel/720 StatusBarHeight/49 SimpleUISwitch/1 QQTheme/2920 InMagicWin/0 StudyMode/0 CurrentMode/1 CurrentFontScale/1.0","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Referer: https://ti.qq.com/act/pandian2021?_wv=16777217&type=1&trace_detail=base64-eyJhcHBpZCI6InZhYl9wdXNoIiwicGFnZV9pZCI6IjEzNiIsIml0ZW1faWQiOiIxMTA0ODEyIiwiaXRlbV90eXBlIjoiNSJ9&h5costreport=1","Accept-Encoding: gzip, deflate, br","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Cookie: ","Q-UA2: QV=3&PL=ADR&PR=QQ&PP=com.tencent.mobileqq&PPVN=8.8.50&TBSVC=44126&CO=BK&COVC=045912&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= Redmi6 &RL=720*1344&OS=9&API=28","Q-GUID: bb7118146e1d883d18ad897513b788cb","Q-QIMEI: 0213f5ec25165b3341ee4b4f100015a15410","QIMEI36: 0213f5ec25165b3341ee4b4f100015a15410","q-header-ctrl: 7","Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b","Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."");
$json=curl("https://ti.qq.com/act/pandian2021/proxy/domain/ti.qq.com/cgi-bin/activity/get_annual_count?open_result=0&bkn=".getGTK($pskey),null,$header);
$data=json_decode($json,true)["act_info"];
$d="2019年我的好友数:".$data["frds_num"][0]."\n2020年我的好友数:".$data["frds_num"][1]."\n2021年我的好友数:".$data["frds_num"][2]."\n2021年聊过好友数:".$data["chat_frds"]."\n我的好友分布城市:".$data["frds_profile"]["city_num"]."个\n最近常常登录QQ的时间:".$data["most_login_time"]."点\n今年发表的说说数:".$data["feeds_num"]."条\n今年空间访问数:".$data["qzone_info"]["new_visitor_num"]."\n我的空间访问数:".$data["qzone_info"]["total_visitor_num"]."\n我的形象:".$data["result_txt"][0]."\n".$data["result_txt"][1]."\n".$data["result_txt"][2]."\n".$data["result_txt"][3];
print_r($d);
