<?php
include("./API.php");
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
if(!$_REQUEST['qq']) {
	echo json(1001,"text","请输入QQ号！");
	exit();
}
$header=[
"Referer: https://aqr.doumsg.cn/",
];
$data=json_decode(curl("https://aqr.doumsg.cn/rsstm/inquiry.php","type=cxqq&cxqq=".$_REQUEST["qq"],$header),true);
if($data["code"]==1){
$data_array=explode("\n",$data["msg"]);
$str_array=array(
"ID"=>"id",
"QQ"=>"qq",
"添加时间"=>"Authorization Time",
"到期时间"=>"Expiration Time",
"上次运行"=>"Last run",
);
foreach($data_array as $v){
$data_array=explode("：",$v);
$array["data"][$str_array[$data_array[0]]]=$data_array[1];
}
$array["time"]["start_time"]=strtotime($data_array[1]);
$array["time"]["start_date"]=$data_array[1];
$array["time"]["now_time"]=time();
$array["time"]["now_date"]=date("Y-m-d h:i:s");
$time=timediff(strtotime($data_array[1]),time());
if(!$time["min"]){
$array["time"]["Running_Time"]=$time["sec"]."秒";
}else if(!$time["hour"]){
$array["time"]["Running_Time"]=$time["min"]."分".$time["sec"]."秒";
}else if(!$time["day"]){
$array["time"]["Running_Time"]=$time["hour"]."小时".$time["min"]."分".$time["sec"]."秒";
}
$array["time"]["date"]["day"]=$time["day"];
$array["time"]["date"]["hour"]=$time["hour"];
$array["time"]["date"]["cent"]=$time["min"];
$array["time"]["date"]["Second"]=$time["sec"];
	echo json(1000,null,null,$array);
}else if($data["code"]==-1){
	echo json(1002,"text","仅限授权用户使用！");
	exit();
}else{
	echo json(1003,"text","其他错误，错误码：".$data["code"]);
	exit();
}

function timediff($begin_time,$end_time)
{
    if($begin_time < $end_time){
        $starttime = $begin_time;
        $endtime = $end_time;
    }else{
        $starttime = $end_time;
        $endtime = $begin_time;
    }

    //计算天数
    $timediff = $endtime-$starttime;
    $days = intval($timediff/86400);
    //计算小时数
    $remain = $timediff%86400;
    $hours = intval($remain/3600);
    //计算分钟数
    $remain = $remain%3600;
    $mins = intval($remain/60);
    //计算秒数
    $secs = $remain%60;
    $res = array("day" => $days,"hour" => $hours,"min" => $mins,"sec" => $secs);
    return $res;
}
