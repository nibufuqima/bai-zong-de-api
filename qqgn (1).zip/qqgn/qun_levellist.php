<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$group=$_REQUEST["group"];
$skey=$_REQUEST["skey"];
$max=$_REQUEST["max"]?:"10";
$Dat=$_REQUEST["lx"];
$Dat=$_REQUEST["data"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qun.qq.com/interactive/levellist?gc=".$group."&type=7&_wv=3&_wwv=128";
$header=array("User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.5_1858_YYB_D A_8080500 QQ/8.8.5.5570 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data=null;
$return=get_result($url,$data,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$url=getSubstr($return,$left,$right);
$json=json_decode($url,true);
if($Dat=="json"){
print_r(jsonjx($json));
}
else{
foreach ($json["membersList"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["name"]."-".$value["uin"]."\n";
echo "等级:".$value["tag"]."-".$value["level"]."\n";
}
}
