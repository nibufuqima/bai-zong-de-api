<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$id=$_REQUEST['id'];
if(!$uin || !$skey || !$pskey || !$id){
print_r("参数不完整!需要参数:uin，skey，pskey，id");
exit();
}
$partition=($id + 1010);
$url="https://w.gamecenter.qq.com//v1/cgi-bin/common/svr-selector/query-role?g_tk=".getGTK($skey);
$header=array("Cookie: p_uin=o".$uin."; p_skey=".$pskey."; uin=o".$uin."; skey=".$skey."; o_cookie=".$uin."; ","Content-Type: application/x-www-form-urlencoded","Host: w.gamecenter.qq.com","User-Agent: Mozilla/5.0 (Linux; Android 10; VOG-AL10 Build/HUAWEIVOG-AL10; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.126 MQQBrowser/6.2 TBS/045114 Mobile Safari/537.36 V1_AND_SQ_8.3.6_1320_YYB_D gamecenter QQ/8.8.17 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/75 SimpleUISwitch/0");
$data='area=1&partition='.$partition.'&platid=1&gamename=sgame';
$json=curl($url,$data,$header);
$jso=json_decode($json,true);
/*$url="https://w.gamecenter.qq.com/v1/cgi-bin/gift/take/all-gift?g_tk=".getGTK($skey);
$data='params={"appid":"1104466820","roleId":"416543736","areaId":1,"partition":'.$partition.',"platId":1,"exchangeType":0}';
$return=curl($url,$data,$header);
print_r($return);*/
print_r($json);
print_r($url);
print_r($data);
print_r($header);