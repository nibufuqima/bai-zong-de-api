<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$n=$_REQUEST["n"];
$type=$_REQUEST["type"];
$group=$_REQUEST["group"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://web.qun.qq.com/cgi-bin/sys_msg/getmsg?ver=5689&filter=0&ep=0";
$header=array("User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.5_1858_YYB_D A_8080500 QQ/8.8.5.5570 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data=curl($url,null,$header);
//preg_match_all('/<a class=\"nick\" uin=\"(.*?)\" href=\"javascript:;\" tabIndex=\"1\" title=\"(.*?)\">(.*?)<\/a> <span>申请加入群<\/span> <a class=\"nick\" qid=\"(.*?)\" authKey=\"(.*?)\" href=\"javascript:;\" tabIndex=\"1\" title=\"(.*?)\">(.*?)<\/a><a class=\"open_aio_btn\" qid=\"(.*?)\" authKey=\"(.*?)\" href=\"javascript:;\" title=\"发送群消息\" tabIndex=\"1\" aria-label=\"发送群消息\"><\/a>/',$data,$data);

print_r($data);

if($n==null){

}else{
$header=array("Host: web.qun.qq.com","sec-fetch-mode: cors","origin: https://web.qun.qq.com","x-alt-referer: web.qun.qq.com","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045714 Mobile Safari/537.36 V1_AND_SQ_8.8.20_1976_YYB_D A_8082000 QQ/8.8.20.5865 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1047693 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0","content-type: application/x-www-form-urlencoded","accept: */*","x-requested-with: com.tencent.mobileqq","sec-fetch-site: same-origin","Referer: https://web.qun.qq.com/cgi-bin/sys_msg/getmsg?ver=5689&filter=0&ep=0","accept-encoding: gzip, deflate, br","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$url="https://web.qun.qq.com/cgi-bin/sys_msg/set_msgstate";
$dat="seq=".$seq."&t=".$lx."&gc=".$gc1."&cmd=".$type."&uin=".$qq."&ver=5689&from=2&flag=0&bkn=".GetBkn($skey);//1同意，2，拒绝，3忽略
$data=curl($url,$dat,$header);
print_r($data);

}
