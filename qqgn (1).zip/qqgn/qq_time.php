<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$id=$_REQUEST["id"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$header=array("Host: ti.qq.com","Connection: keep-alive","Accept: application/json","User-Agent: Mozilla/5.0 (Linux; Android 11; 21091116AC Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.85 Mobile Safari/537.36 V1_AND_SQ_8.8.98_3002_YYB_D A_8089800 QQ/8.8.98.8410 NetType/4G WebP/0.4.1 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1000 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537124039","X-Requested-With: XMLHttpRequest","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Referer: https://ti.qq.com/qqmedal2/index.html?_wv=1&_bid=2450&_nav_alpha=0&_nav_txtclr=ffffff&_nav_titleclr=ffffff&_nav_anim=true&_wwv=4","Accept-Encoding: gzip, deflate","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Cookie: qq_locale_id=2052; p_uin=o2030876033; uin=o2030876033; skey=M4lCCFqL7T; p_skey=S6n08C-HXcwZkUceAV5P12AQNeRZw6kjQCG4dh4V*I0_; a2=5A97CAA54EAC82591F495D41DC50D7B947E914B0A9B791A361BCDDE499FA6A9A81AE09EF8B863E3C08E1E502C022F909C9815851C4295F87FAE82F852523C8FED067AD083A3F789E");

$url="https://ti.qq.com/mqqbase/cgi/medalwall/medaldetail?targetUin=*S1*ownioecl7wnioz&medalid=1&token=6ae58aa564c48964a6e374b9983c06bd&_=1661178317167";
$data=curl($url,null,$header);
print_r($data);