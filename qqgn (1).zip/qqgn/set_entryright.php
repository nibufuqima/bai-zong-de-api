<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$qq=$_REQUEST["qq"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$type=$_REQUEST["type"];
$bdlb=array(
"1" => "flag=0x0&fupdate=1&uin=".$uin."&ver=1&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fprofile%2Fpermit",
"2" => "flag=0x20101&fupdate=1&uin=".$uin."&ver=1&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fprofile%2Fpermit",
"2" => "flag=0x40000&fupdate=1&uin=".$uin."&ver=1&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fprofile%2Fpermit"
);
$data=$bdlb[$type];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_uin=o".$uin.";p_skey=".$pskey."","Host: user.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/w.qzone.qq.com/cgi-bin/right/set_entryright.cgi?g_tk=".getGTK($skey);
$data=curl($url,$data,$header);
$data=str_replace('callback(','',$data);
$data=str_replace(');','',$data);
$json=json_decode($data,true);
print_r($data);

//-3000失效

