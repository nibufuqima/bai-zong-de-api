<p></p><pre>
获取code和链接
".ym."/API/qqgn/mc/login.php
[获取code和url]

登录小程序
".ym."/API/qqgn/mc/login.php?type=1&code=
[获取ticket]

厘萌登录
".ym."/API/qqgn/mc/limi.php?type=1&ticket=
[获取token和id值]

".ym."/API/qqgn/mc/limi.php?type=&token=&id=&pet=
pet:宠物id

type值
2:厘萌签到
14:厘萌补签
3:厘萌奖励
4:厘萌出门[需要pet参数]
5:厘萌清洗[需要pet参数]
6:厘萌捕捉
7:偷取能量
8:收取能量
9:厘萌喂食[需要pet参数]
10:厘萌任务
11:喂食状态
13:自动喂食[需要pet参数]

以下为QR词库
&&CY©5.2.0
&&API支持:api.klizi.cn,api.klizi.cn
&&作者:1242619315
&&官方群:1021789873
##更新DIY名片，更新刷访客，说说点赞及空间操作类
##更新刷访客，说说点赞频繁限制，清数据
##更新入群付费，成长值查询，优化查看说说，
##更新定时说说系列
##优化刷访客，说说点赞线程池卡顿
##增加最新动态，秒赞和秒评
##登录葫芦，葫芦签到，图文信息
##增加打卡提醒，广告打卡，隐藏搜索，清资料
##增加成长排行，超会点赞，优化ck检测线程!
##增加萌宠菜单，厘萌菜单

厘萌菜单
◇━㊣厘萌功能㊣━◇\n
🍁 厘萌签到  厘萌补签 🍁\n
🍁 厘萌任务  厘萌能量 🍁\n
🍁 厘萌捕捉  厘萌偷取 🍁\n
🍁 厘萌出门  厘萌洗澡 🍁\n
🍁 厘萌喂食  厘萌自动 🍁\n
🍁 厘萌奖励  厘萌信息 🍁\n
◇━━━━━━━━━━◇\n
 PS:发相应功能文字查看


厘萌信息
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=11&token=%a%&id=%b%&lx=1$

厘萌签到
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=2&token=%a%&id=%b%$

厘萌补签
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=14&token=%a%&id=%b%$

厘萌任务
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=10&token=%a%&id=%b%$

厘萌能量
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=8&token=%a%&id=%b%$

厘萌捕捉
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=6&token=%a%&id=%b%$

厘萌偷取
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=7&token=%a%&id=%b%$

厘萌出门([0-9]+)
如果:%括号1%==
QQ:%QQ%\n请输入参数
返回
如果尾
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=4&token=%a%&id=%b%&pet=%括号1%$

厘萌洗澡([0-9]+)
如果:%括号1%==
QQ:%QQ%\n请输入参数
返回
如果尾
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=5&token=%a%&id=%b%&pet=%括号1%$

厘萌喂食([0-9]+)
如果:%括号1%==
QQ:%QQ%\n请输入参数
返回
如果尾
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=9&token=%a%&id=%b%&pet=%括号1%$

厘萌自动([0-9]+)
如果:%括号1%==
QQ:%QQ%\n请输入参数
返回
如果尾
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=13&token=%a%&id=%b%&pet=%括号1%$

厘萌奖励
a:$读 小白/厘萌/%QQ% token ]$
b:$读 小白/厘萌/%QQ% id ]$
$访问 ".ym."/API/qqgn/mc/limi.php?type=3&token=%a%&id=%b%$


登录(程序|萌宠|厘萌)
a:$访问 ".ym."/API/qqgn/mc/login.php$
QQ:%QQ%\n点击下方链接登录\n@a[url]
$写 小白/程序/%QQ% code @a[code]$
$写 小白/程序/%QQ% time %Time%$
$调用 0 验证登录$


验证登录
a:$读 小白/程序/%QQ% code 。$
b:$读 小白/程序/%QQ% time 。$
t:%Time%
b:[%t%-%b%]
a:$访问 ".ym."/API/qqgn/mc/login.php?type=1&code=%a%$
$写 小白/程序/%QQ% ticket @a[data][ticket]$
a:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=1&ticket=@a[data][ticket]$
如果:@a[code]==0
QQ:%QQ%\n萌宠登录成功!\n\nid:@a[id]\n等级:@a[level]\n经验:@a[expirenece]\n金币:@a[coins]\n元气值:@a[vigours]\n
$写 小白/萌宠/%QQ% token @a[token]$
$写 小白/萌宠/%QQ% id @a[id]$
$调用 0 厘萌登录aa$
返回
如果尾
如果:%b%>=120
QQ:%QQ%\n登录超时！
返回
如果尾
$调用 0 验证登录$


厘萌登录aa
a:$读 小白/程序/%QQ% ticket 。$
a:$访问 ".ym."/API/qqgn/mc/limi.php?type=1&ticket=%a%$
如果:@a[code]==0
QQ:%QQ%\n厘萌登录成功!
$写 小白/厘萌/%QQ% token @a[token]$
$写 小白/厘萌/%QQ% id @a[id]$

萌宠菜单
◇━㊣萌宠功能㊣━◇\n
🍁 登录萌宠  萌宠信息 🍁\n
🍁 萌宠签到  商城签到 🍁\n
🍁 一键互动  一键抽奖 🍁\n
🍁 一键任务  一键打工 🍁\n
🍁 一键打卡  一键补签 🍁\n
🍁 清洗喂食  视频元气 🍁\n
🍁 收取元气  收取金币 🍁\n
🍁 道具列表  食物列表 🍁\n
🍁 使用道具  使用食物 🍁\n
🍁 随机捕捉  随机摸取 🍁\n
◇━━━━━━━━━━◇\n
 PS:发相应功能文字查看

萌宠签到
a:$读 小白/萌宠/%QQ% token ]$
a:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=2&token=%a%$
QQ:%QQ%\n%a%

一键互动
a:$读 小白/萌宠/%QQ% token ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=12&token=%a%$
QQ:%QQ%\n%内%

一键打卡
a:$读 小白/萌宠/%QQ% token ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=4&token=%a%$
QQ:%QQ%\n%内%

清洗喂食
a:$读 小白/萌宠/%QQ% token ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=5&token=%a%$
QQ:%QQ%\n%内%

一键任务
a:$读 小白/萌宠/%QQ% token ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=6&token=%a%$
QQ:%QQ%\n%内%

一键抽奖
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=7&token=%a%&id=%b%$
QQ:%QQ%\n%内%

一键补签
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=21&token=%a%&id=%b%$
QQ:%QQ%\n%内%

视频元气
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=8&token=%a%&id=%b%$
QQ:%QQ%\n%内%

商城签到
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=9&token=%a%&id=%b%$
QQ:%QQ%\n%内%

收取金币
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=11&token=%a%&id=%b%$
QQ:%QQ%\n%内%

收取元气
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=17&token=%a%&id=%b%$
QQ:%QQ%\n%内%

萌宠点击
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=12&token=%a%&id=%b%$
QQ:%QQ%\n%内%

一键打工
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=13&token=%a%&id=%b%$
QQ:%QQ%\n%内%

萌宠信息
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=14&token=%a%&id=%b%$
QQ:%QQ%\n%内%

道具列表
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=15&token=%a%&id=%b%$
QQ:%QQ%\n%内%

食物列表
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
a:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=18&token=%a%&id=%b%$
QQ:%QQ%\n%a%

兑换列表
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=20&token=%a%&id=%b%$
QQ:%QQ%\n%内%

随机摸取
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=24&token=%a%&id=%b%$
QQ:%QQ%\n%内%

随机捕捉
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=23&token=%a%&id=%b%$
QQ:%QQ%\n%内%

喂食状态
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=25&token=%a%&id=%b%$
QQ:%QQ%\n%内%

使用道具([0-9]+)
如果:%括号1%==
QQ:%QQ%\n请输入参数
返回
如果尾
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=16&token=%a%&id=%b%&n=%括号1%$
QQ:%QQ%\n%内%

使用食物([0-9]+)
如果:%括号1%==
QQ:%QQ%\n请输入参数
返回
如果尾
a:$读 小白/萌宠/%QQ% token ]$
b:$读 小白/萌宠/%QQ% id ]$
内:$访问 ".ym."/API/qqgn/mc/qqpet.php?type=19&token=%a%&id=%b%&n=%括号1%$
QQ:%QQ%\n%内%

丢@.*
±img=".ym."/API/ce/diu.php?qq=%AT0%±

赞@.*
±img=".ym."/API/ce/zan.php?qq=%AT0%±

跑@.*
±img=".ym."/API/ce/pao.php?qq=%AT0%±

谢谢@.*
±img=".ym."/API/ce/xie.php?qq=%AT0%±

爬@.*
±img=".ym."/API/ce/paa.php?qq=%AT0%±


菜单
内:萌宠菜单\n厘萌菜单\n装扮菜单\n名片菜单
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

装扮菜单
内:申请二维码\n装扮列表一\n装扮列表二\n装扮列表三
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

装扮列表三
内:清理不活跃\n好友符抽取\n好友符列表\n开启好友符\n关闭好友符
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

装扮列表一
内:开秒评 开秒赞\n开提醒 关提醒\n刷访客 清数据\n查等级 查业务\n查QID 发公告\n删公告 看公告\n查信息 群信息\n发说说 删说说\n群管理 查头衔\n日签卡 收集卡\n发签名 群数据\n删留言 发留言\n发签名 清资料
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

装扮列表二
内:入群付费 成长查询\n成长排行 超会点赞\n最新动态 设置秒评\n定时说说 删除定时\n定时列表 清空定时\n说说点赞 查看说说\n留言权限 访客权限\n访空权限 评论审核\n留言列表 亲密排行\n公告列表 禁言列表\n群等级榜 精华信息\n打卡列表 勋章排行\n空白昵称 修改昵称\n今日打卡 打卡排行\n今日龙王 字符列表\n抽幸运符 使用字符\n我的访客 特别关心\n清空留言 清空说说\n资料查询 说说列表\n设置管理 取消管理\n群排行榜 群积分榜\n个性名片 打卡报名\n我的装扮 我的价值\n个性装扮 一起听歌\n群一起看 空间签到\n登录葫芦 葫芦签到\n广告打卡 隐藏搜索\n切换图文 切换文字
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

查等级
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_level.php?data=&skey=%s%&qq=%q%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

查业务
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yw.php?data=&skey=%s%&qq=%q%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


成长查询
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/vipcenter.php?data=&skey=%s%&qq=%q%$
内:账号:@a[uin]\n成长储值:@a[currentSpeed]\n最大储值:@a[maxSpeed]\n我的储值:@a[totalSpeed]\n好友排行:@a[friendrank]
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


查QID
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/qid.php?data=&uin=%q%&skey=%s%&pskey=%p%&qq=%q%$
内:@a[QID]
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

清理不活跃(.*)
如果:%括号1%==
请输入月数
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:%QQ%==%主人%
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qun_delnoactive.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&num=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

发公告(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/gg_send.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&text=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

删公告(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/gg_delete.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&fid=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

公告列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qun_gg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

看公告(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/qun_gg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&n=%括号1%$
内:fid:@a[fid]\n内容:@a[text]\n
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

群信息
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qun_text.php?data=&type=2&skey=%s%&pskey=%p%&uin=%q%&group=%群号%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

群管理
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qgl.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

群头衔
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qun_anony.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

禁言列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/grouan.php?data=&uin=%q%&skey=%s%&qh=%群号%&lx=$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

亲密排行
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/friend_ship.php?data=&skey=%s%&pskey=%p%&uin=%q%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

查信息@.*
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qun_text.php?data=&type=1&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&qq=%AT0%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

(设置|取消)管理@.*
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
如果:%括号1%==设置
内:$访问 ".ym."/API/qqgn/qun_gl.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&qq=%AT0%&op=1$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
内:$访问 ".ym."/API/qqgn/qun_gl.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&qq=%AT0%&op=0$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

群排行榜
内:(等级积分|管理员|龙王争霸|屠龙)榜
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

群积分榜
内:(龙王|快乐源泉|群聊之火|群聊炽焰|善财福禄寿)
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

群发言榜
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/SpeakRank.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

群等级榜
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qun_levellist.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

查头衔(.*)
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qun_userhonor.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&qq=%括号1%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

精华信息
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qun_Essence.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

打卡列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_kp.php?data=&skey=%s%&pskey=%p%&uin=%q%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

隐藏搜索
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie id 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_search.php?data=&skey=%s%&pskey=%p%&uin=%q%&switch=1$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

勋章排行
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_xz.php?data=&skey=%s%&pskey=%p%&uin=%q%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

打卡报名
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_dkbm.php?data=&skey=%s%&pskey=%p%&uin=%q%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

日签卡
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_dk.php?data=&skey=%s%&pskey=%p%&uin=%q%&lx=1$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

收集卡
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_dk.php?data=&skey=%s%&pskey=%p%&uin=%q%&lx=2&data=$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

开提醒
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_dktx.php?data=&skey=%s%&pskey=%p%&uin=%q%&switch=1$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

关提醒
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_dktx.php?data=&skey=%s%&pskey=%p%&uin=%q%switch=2$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

广告打卡
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_ggdk.php?data=&skey=%s%&pskey=%p%&uin=%q%&lx=2$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

(个性名片|名片菜单)
内:特效设置 头像设置\n点赞设置 提交名片\n我的模板 等待更新
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

特效设置
内:1.星星\n2.渐变\n3.花花\n4.超酷涂鸦\n5.唯美\n6.炫酷\n7.黑暗\n8.动漫\n9.可爱\n10.潮流派\n11.可爱夏日\n12.梦幻星河\n13.浪漫花语\n14.奇幻卡牌\n15.甜甜爱情\n16.宇宙流浪\n17.梦境随想\n18.暗黑史诗\n19.暮色霓虹\n20.波光之梦\n21.情牵\n22.长相思令\n23.朦胧花火\n回复设置特效+内容即可！
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

设置特效(星星|渐变|花花|超酷涂鸦|唯美|炫酷|黑暗|动漫|可爱|潮流派|可爱夏日|梦幻星河|浪漫花语|奇幻卡牌|甜甜爱情|宇宙流浪|梦境随想|暗黑史诗|暮色霓虹|波光之梦|情牵|长相思令|朦胧花火)
内:设置特效%括号1%成功！
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
$写 DIY/特效 %QQ% %括号1%$


头像设置
内:1.居中\n2.跟随\n3.隐藏\n回复:设置头像+内容即可！
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

设置头像(居中|跟随|隐藏)
内:设置头像%括号1%成功！
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
$写 DIY/头像 %QQ% %括号1%$

点赞设置
内:1.普通\n2.全屏\n3.隐藏\n回复:设置点赞+内容即可！
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

设置点赞(普通|全屏|隐藏)
内:设置点赞%括号1%成功！
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
$写 DIY/点赞 %QQ% %括号1%$

我的模板
1:$读 DIY/点赞 %QQ% 普通$
2:$读 DIY/头像 %QQ% 居中$
3:$读 DIY/特效 %QQ% 星星$
内:账号:%QQ%\n点赞:%1%点赞\n头像:%2%头像\n特效:%3%特效
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

提交名片
如果:%IMG0%==
内:请携带图片
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
r:$图片链接 %IMG0%$
1:$读 DIY/点赞 %QQ% 普通$
2:$读 DIY/头像 %QQ% 居中$
3:$读 DIY/特效 %QQ% 星星$
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
$调用 0 提示$
内:$访问 ".ym."/API/qqgn/diy.php?data=&skey=%s%&pskey=%p%&uin=%q%&url=%r%&dz=%1%&tx=%2%&lottie=%3%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


提示
内:请等待一分钟时间，谢谢！
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

空白昵称
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_kbnc.php?data=&qq=%q%&skey=%s%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

清资料
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie id 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_zlqk.php?data=&uin=%q%&skey=%s%&pskey=%p%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

修改昵称(.*)
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_nc.php?data=&qq=%q%&skey=%s%&msg=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

今日龙王
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/dragon.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

抽幸运符
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:1，$访问 ".ym."/API/qqgn/qun_lucky.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%$\n2，$访问 ".ym."/API/qqgn/qun_lucky.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%$\n3，$访问 ".ym."/API/qqgn/qun_lucky.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

字符列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qun_luckylist.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&data=text&max=20$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

使用字符(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qun_luckyuse.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&id=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


今日打卡
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/GetDaySignedList.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

打卡排行
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/GetKingSignedList.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

我的访客
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qzone_visitor.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

清空留言
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qzone_emptymsgb.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

清空说说
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/ss_empty.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


清空定时
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/sstime_empty.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


特别关心
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/specialcare.php?data=&skey=%s%&pskey=%p%&uin=%q%$
内:我关心的:@a[我关心的]人\n关心我的:@a[关心我的]人
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

资料查询(.*)
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/userinfo.php?data=&uin=%q%&skey=%s%&pskey=%p%&qq=%括号1%$
a:@a[data]
内:账号:@a[uin]\n昵称:@a[nickname]\n空间:@a[spacename]\n年龄:@a[age]\n生日:@a[birthyear]-@a[birthday]\n地址:@a[country]-@a[province]-@a[city]
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

说说列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/ss_list.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

定时列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/sstime_list.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

查看说说(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/ss_list.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%&n=%括号1%$
内:@a[conlist][0][con]
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


留言列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qzone_msgb.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

空间签到
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/publishmood.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

设置秒评(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
$写 二维码/%QQ%/动态 pl %括号1%$
内:%QQ%\n设置秒评内容[%括号1%]成功!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

开秒评
如果:$读 二维码/%QQ%/动态 pl 0$==0
%QQ%\n请先设置秒评评论!
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 动态检测$==1
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
t:$读 二维码/%QQ%/动态 tid 0$
u:$读 二维码/%QQ%/动态 qq 0$
n:$读 二维码/%QQ%/动态 pl 0$
账号:%QQ%\n$访问 ".ym."/API/qqgn/ss_comment.php?skey=%s%&pskey=%p%&uin=%q%&msg=%n%&qq=%u%&tid=%t%$
$调用 5000 开秒评$
返回
如果尾
$调用 5000 开秒评$

开秒赞
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 动态检测$==1
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
t:$读 二维码/%QQ%/动态 tid 0$
u:$读 二维码/%QQ%/动态 qq 0$
账号:%QQ%\n$访问 http://sq.klizi.cn/qzone_ssdz.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%u%&fid=%t%$
$调用 5000 开秒赞$
返回
如果尾
$调用 5000 开秒赞$


[内部]动态检测
g:$读 二维码/%QQ%/动态 tid 0$
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 http://sq.klizi.cn/qzone_ss.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
y:@a[tid]
u:@a[uin]
如果:%g%==%y%
0
返回
如果尾
$写 二维码/%QQ%/动态 tid %y%$
$写 二维码/%QQ%/动态 qq %u%$
1


最新动态
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 http://sq.klizi.cn/qzone_ss.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
内:账号：@a[uin]\n内容：@a[content]\ntid：@a[tid]
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

我的装扮
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/a/vip_list.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

我的价值
内:$访问 ".ym."/API/other/gujia.php?data=&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

删说说(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/ss_list.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%&n=%括号1%$
a:@a[tid]
内:$访问 ".ym."/API/qqgn/ss_delete.php?data=&skey=%s%&pskey=%p%&uin=%q%&tid=%a%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


删除定时(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/sstime_list.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%QQ%&n=%括号1%$
c:@a[tid]
b:@a[created_time]
内:$访问 ".ym."/API/qqgn/sstime_delete.php?data=&skey=%s%&pskey=%p%&uin=%q%&tid=%c%&time=%b%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

删留言(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qzone_delmsgb.php?data=&skey=%s%&pskey=%p%&uin=%q%&id=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

发说说(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/ss_send.php?data=&skey=%s%&pskey=%p%&uin=%q%&msg=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

发签名(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie id 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_qm.php?data=&skey=%s%&pskey=%p%&uin=%q%&msg=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

定时说说(.*) ([0-9]+)
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/sstime_send.php?data=&skey=%s%&pskey=%p%&uin=%q%&msg=%括号1%&time=%括号2%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

发留言(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入内容
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qzone_addmsgb.php?data=&skey=%s%&pskey=%p%&uin=%q%&msg=%括号1%&qq=%QQ%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

发评论(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入内容
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/ss_comment.php?data=&skey=%s%&pskey=%p%&uin=%q%&msg=。。&qq=%QQ%&tid=%括号1%
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

好友符抽取(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入好友QQ
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:1，$访问 ".ym."/API/qqgn/qq_lucky.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%括号1%$\n2，$访问 ".ym."/API/qqgn/qq_lucky.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%括号1%$\n3，$访问 ".ym."/API/qqgn/qq_lucky.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

好友符列表(.*)
如果:%括号1%==
请输入好友QQ
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_luckylist.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

开启好友符(.*)
如果:%括号1%==
请输入好友QQ
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_luckyset.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%括号1%&switch=1$

关闭好友符(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入好友QQ
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/qq_luckyset.php?data=&skey=%s%&pskey=%p%&uin=%q%&qq=%括号1%&switch=2$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


(龙王|快乐源泉|群聊之火|群聊炽焰|善财福禄寿)
A:%Json%
A:@A[pskey]
A:@A[qun.qq.com]
内:$访问 ".ym."/API/qqgn/qun_Interaction.php?data=&skey=%Skey%&pskey=%A%&uin=%Robot%&group=%群号%&type=%参数0%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

(等级积分|管理员|龙王争霸|屠龙)榜
A:%Json%
A:@A[pskey]
A:@A[qun.qq.com]
内:$访问 ".ym."/API/qqgn/qphb.php?data=&skey=%Skey%&pskey=%A%&uin=%Robot%&group=%群号%&type=%括号1%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

个性装扮
内:装扮类型 设置装扮\n搜索装扮 使用装扮
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

设置装扮(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
$写 装扮类型/%群号% %QQ% %括号1%$
内:设置装扮类型%括号1%成功!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

装扮类型
内:气泡/主题/字体/挂件/来电/名片/背景/头像/个签/个性赞/进群特效\n发送:设置装扮+内容进行设置吧！
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


搜索装扮(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
n:$读 装扮类型/%群号% %QQ% 0$
$写 装扮内容/%群号% %QQ% %括号1%$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/a/vip.php?data=&uin=%q%&skey=%s%&pskey=%p%&type=&id=%n%&msg=%括号1%&max=15$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


使用装扮(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
n:$读 装扮类型/%群号% %QQ% 0$
m:$读 装扮内容/%群号% %QQ% 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/a/vip.php?data=&uin=%q%&skey=%s%&pskey=%p%&type=1&id=%n%&msg=%m%&max=15&itemid=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


群数据
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie qun 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/qun_active.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=信息条数$
b:$访问 ".ym."/API/qqgn/qun_active.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=活跃人数$
c:$访问 ".ym."/API/qqgn/qun_active.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=申请人数$
o:$访问 ".ym."/API/qqgn/qun_active.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=退群人数$
r:$访问 ".ym."/API/qqgn/qun_active.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=入群人数$
内:昨日数据:\n信息条数:@a[total]条\n活跃人数:@b[activeData]人\n申请人数:@c[total]人\n退群人数:@o[total]人\n入群人数:@r[total]人
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
##type为信息条数/活跃人数/申请人数/退群人数/入群人数

一起听歌
内:开启听歌 关闭听歌\n开启定时 关闭定时\n定时开启 定时关闭\n搜索歌曲 添加歌曲\n歌曲列表 删除歌曲\n切换歌曲 听歌人数\n单曲循环 顺序播放\n随机播放 等待更新\n(允许|拒绝)成员开启\n(允许|拒绝)成员添加\n结束(保留|不留)列表
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

开启听歌
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=set&n=1$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

听歌主题
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=theme&n=$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

设置主题(.*)
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=theme&n=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

关闭听歌
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=set&n=2$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

开启定时
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=task&n=1$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

关闭定时
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=task&n=2$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


定时开启(.*)
如果:%括号1%==
请输入时间
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=task&start_hour=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

定时关闭(.*)
如果:%括号1%==
请输入时间
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=task&stopend_hour=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

允许成员开启
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
$写 听歌/%群号% allow 1$
a:$读 听歌/%群号% flag 0$##添加
b:$读 听歌/%群号% stop 1$##保留
c:$读 听歌/%群号% allow 0$##开启
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=task&flag=%a%&stop=%b%&allow=%c%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

拒绝成员开启
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
$写 听歌/%群号% allow 0$
a:$读 听歌/%群号% flag 0$##添加
b:$读 听歌/%群号% stop 1$##保留
c:$读 听歌/%群号% allow 0$##开启
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=task&flag=%a%&stop=%b%&allow=%c%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

允许成员添加
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
$写 听歌/%群号% flag 1$
a:$读 听歌/%群号% flag 0$##添加
b:$读 听歌/%群号% stop 1$##保留
c:$读 听歌/%群号% allow 0$##开启
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=task&flag=%a%&stop=%b%&allow=%c%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

拒绝成员添加
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
$写 听歌/%群号% flag 0$
a:$读 听歌/%群号% flag 0$##添加
b:$读 听歌/%群号% stop 1$##保留
c:$读 听歌/%群号% allow 0$##开启
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=task&flag=%a%&stop=%b%&allow=%c%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

结束保留列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
$写 听歌/%群号% stop 1$
a:$读 听歌/%群号% flag 0$##添加
b:$读 听歌/%群号% stop 1$##保留
c:$读 听歌/%群号% allow 0$##开启
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=task&flag=%a%&stop=%b%&allow=%c%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


结束不留列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
$写 听歌/%群号% stop 0$
a:$读 听歌/%群号% flag 0$##添加
b:$读 听歌/%群号% stop 1$##保留
c:$读 听歌/%群号% allow 0$##开启
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=task&flag=%a%&stop=%b%&allow=%c%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


搜索歌曲(.*)
如果:%括号1%==
请输入时间
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
$写 听歌/%群号% nr %括号1%$
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=add&msg=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


添加歌曲(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入时间
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$写 听歌/%群号% nr %括号1%$
$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=add&msg=%a%&n=%括号1%$

删除歌曲(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入时间
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=remove&n=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


切换歌曲(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入时间
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=switch&n=%括号1%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

歌曲列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=list$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

听歌人数
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=number$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

单曲循环
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=setmode&n=3$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


顺序播放
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=setmode&n=2$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


随机播放
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqtg.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=setmode&n=1$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


##未写部分
④循环播放
type=time，无循环，
type=time1，循环每天播放，
type=time2，循环每周播放
week_days:循环播放日期(若播放日期为星期一和星期二，则参数为:[1,2])
type=setmode


群一起看
内:一起看列表\n查看一起看\n开启一起看\n关闭一起看\n允许成员开一起看\n拒绝成员开一起看
$写 小白/%群号% 图文数据 %内%$$回调 MSG$


允许成员开一起看
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqk.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=open$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

拒绝成员开一起看
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqk.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=open$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

一起看列表
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/yqk.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=list$\n发送:一起看列表+内容可查看更多!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

一起看列表(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入内容
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
$写 一起看/%群号% nr %括号1%$
内:$访问 ".ym."/API/qqgn/yqk.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=list&msg=%括号1%$\n发送:查看一起看+序号可查看更多!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

查看一起看(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入内容
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$读 一起看/%群号% nr 1$
$写 一起看/%群号% xh %括号1%$
内:$访问 ".ym."/API/qqgn/yqk.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=list&msg=%a%&n=%括号1%$\n发送:开启一起看+序号一起看吧!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

关闭一起看
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$读 一起看/%群号% stop 1$
o@$访问 ".ym."/API/qqgn/yqk.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=stop&roomId=%a%$
内:$取中间 @ %o%@msg":"@"$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

开启一起看(.*)
如果:%括号1%==
请输入内容
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie ti 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$读 一起看/%群号% nr 1$
b:$读 一起看/%群号% xh 1$
o:$访问 ".ym."/API/qqgn/yqk.php?data=&skey=%s%&pskey=%p%&uin=%q%&group=%群号%&type=start&msg=%a%&n=%b%&m=%括号1%$
c:$取中间 @ %o%@roomId":"@"}$
$写 一起看/%群号% stop %c%$
内:$取中间 @ %o%@msg":"@"$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

[内部]ck判断
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/pd.php?data=&uin=%q%&skey=%s%$
%a%
如果:%a%!=0
$调用 0 ck删%QQ%$

[内部]ck1判断(.*)
d:$读 二维码/%括号1%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/pd.php?data=&uin=%q%&skey=%s%$
如果:%a%!=0
$回调 ck删%括号1%$

[内部]ck处理
A:$读 二维码/cookie yh 0$
R:$JSON 长度 A$
如果尾
L:0
:Xun1
如果:%L%<%R%
D:@A[%L%]
$回调 ck1判断%D%$
$jump :Xun1$

ck删([0-9]+)
A:$读 二维码/cookie yh []$
a:0
:跳1
如果:@A[%a%]==%括号1%
$JSON 删除 A %a%$
$写 二维码/cookie yh %A%$
$写 二维码/%括号1%/cookie dl 0$
返回
如果尾
a:[%a%+1]
$跳 :跳1$

刷访客
$调用 0 ck处理$
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
Y:$读 二维码/%QQ%/装扮 fktime 0$
如果:[%Time%-%Y%]<120
内:请勿频繁操作!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
$写 二维码/%QQ%/装扮 fktime %Time%$
A:$读 二维码/cookie yh 0$
R:$JSON 长度 A$
$调用 3000 访客提示[%R%-1]$
如果尾
L:0
:Xun1
如果:%L%<%R%
D:@A[%L%]
d:$读 二维码/%D%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
a:$访问 ".ym."/API/qqgn/qzone_lh.php?data=&uin=%q%&skey=%s%&pskey=%p%&qq=%QQ%$
L:[%L%+1]
$jump :Xun1$


说说点赞(.*)
如果:%括号1%==
请输入数字
返回
如果尾
$调用 0 ck处理$
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
Y:$读 二维码/%QQ%/装扮 time 0$
如果:[%Time%-%Y%]<120
内:请勿频繁操作!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
$写 二维码/%QQ%/装扮 time %Time%$
A:$读 二维码/cookie yh 0$
R:$JSON 长度 A$
$调用 3000 说说提示[%R%-1]$
如果尾
L:0
:Xun1
如果:%L%<%R%
D:@A[%L%]
d:$读 二维码/%D%/cookie qzone 0$
n:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
i:$访问 ".ym."/API/qqgn/ss_list.php?data=&skey=@n[skey]&pskey=@n[pskey]&uin=@n[uin]&qq=%QQ%&n=%括号1%$
i:@i[tid]
a:$访问 http://sq.klizi.cn/qzone_ssdz.php?data=&uin=%q%&skey=%s%&pskey=%p%&qq=%QQ%&fid=%i%$
L:[%L%+1]
$jump :Xun1$

访客提示(.*)
内:QQ:%QQ%\n获得访问用户%括号1%人
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

说说提示(.*)
内:QQ:%QQ%\n获得说说点赞%括号1%次
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

留言权限(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数,参数为所有人,好友,自己
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
a:$替换 %括号1% 所有人 1$
a:$替换 %括号1% 好友 2$
a:$替换 %括号1% 自己 3$
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 http://sq.klizi.cn/qzone_lysh.php?data=&uin=%q%&skey=%s%&pskey=%p%&type=%a%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

访客权限(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数,参数为所有人,好友,自己
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
a:$替换 %括号1% 所有人 1$
a:$替换 %括号1% 好友 2$
a:$替换 %括号1% 自己 3$
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 http://sq.klizi.cn/qzone_fkqx.php?data=&uin=%q%&skey=%s%&pskey=%p%&type=%a%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

访空权限(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数,参数为所有人,好友,自己
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
a:$替换 %括号1% 所有人 1$
a:$替换 %括号1% 好友 2$
a:$替换 %括号1% 自己 3$
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 http://sq.klizi.cn/qzone_kjqx.php?data=&uin=%q%&skey=%s%&pskey=%p%&type=%a%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

评论审核(.*)
如果:%括号1%==
请输入参数,参数为开，关
返回
如果尾
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
a:$替换 %括号1% 开 1$
a:$替换 %括号1% 关 2$
d:$读 二维码/%QQ%/cookie qzone 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 http://sq.klizi.cn/qzone_plsh.php?data=&uin=%q%&skey=%s%&pskey=%p%&type=%a%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

申请二维码
a:$访问 ".ym."/API/qqgn/a/login.php?type=1$
内:请在60s内扫码!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
±img=@a[picurl]±
$写 获取skey/%QQ% qrsig @a[qrsig]$
$调用 10 验证登录。。$

验证登录。。
Y:$读 获取skey/%QQ% qrsig 0$
B:$访问 ".ym."/API/qqgn/a/login.php?type=2&qrsig=%Y%$
P:$访问 ".ym."/API/qqgn/a/login.php?type=4&qrsig=%Y%$
K:$访问 ".ym."/API/qqgn/a/login.php?type=3&qrsig=%Y%$
I:$访问 ".ym."/API/qqgn/a/login.php?type=5&qrsig=%Y%$
T:$访问 ".ym."/API/qqgn/a/login.php?type=6&qrsig=%Y%$
D:@B[code]
如果:%D%==2
$调用 100 验证登录。。$
返回
如果尾
如果:%D%==68
内:QQ:%QQ%\n拒绝登录
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:%D%==1
内:QQ:%QQ%\n二维码已经失效
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:%D%==3
内:QQ：%QQ%\n扫码成功，正在验证登录……
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
$调用 100 验证登录。。$
返回
如果尾
如果:%D%==0
内:[账号]：@B[uin]\n[昵称]：@B[name]\n[提示]：二维码登录成功
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
$写 二维码/%QQ%/cookie vip %B%$
$写 二维码/%QQ%/cookie qun %P%$
$写 二维码/%QQ%/cookie qzone %K%$
$写 二维码/%QQ%/cookie ti %T%$
$写 二维码/%QQ%/cookie id %I%$
如果:$读 二维码/%QQ%/cookie dl 0$==0
$写 二维码/%QQ%/cookie dl 1$
A:$读 二维码/cookie yh []$
$JSON 添加 A %QQ%$
$写 二维码/cookie yh %A%$



清数据
$写 二维码/%QQ%/cookie vip 0$
$写 二维码/%QQ%/cookie qun 0$
$写 二维码/%QQ%/cookie qzone 0$
$写 二维码/%QQ%/cookie ti 0$
$写 二维码/%QQ%/cookie id 0$
内:清空成功!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

入群付费
内:设置入群付费\n设置入群禁言
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

设置入群付费(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:%QQ%==%主人%
$写 %群号% 入群付费 %括号1%$
内:设置入群付费%括号1%分成功!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

设置入群禁言(.*)
如果:%括号1%==
内:QQ:%QQ%\n请输入参数
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
如果:%QQ%==%主人%
$写 %群号% 入群禁言 %括号1%$
内:设置入群禁言%括号1%秒成功!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

[系统]
如果:%Status%==33
$回调 入群付费%QQ%$

[内部]入群付费(.*)
B:$读 %群号% 入群付费 60$
C:$读 %群号% 入群禁言 60$
D:[%C%*1000]
A:%Json%
A:@A[pskey]
A:@A[tenpay.com]
A:$访问 ".ym."/API/qqgn/qsk.php?data=&skey=%Skey%&pskey=%A%&uin=%Robot%&group=%群号%&qq=%括号1%&je=%B%&type=&collection_no=$
@A[retmsg]
内:@%昵称%，请在%C%秒内支付订单，不然你将会被踢出群
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
$禁 %群号% %括号1% %C%$
$调用 %D% 支付判断@A[collection_no] %B% %括号1%$

[内部]支付判断(.*) (.*) (.*)
C:$读 %群号% 入群禁言 0$
A:%Json%
A:@A[pskey]
A:@A[tenpay.com]
A:$访问 ".ym."/API/qqgn/qsk.php?data=&skey=%S%&pskey=%A%&uin=%Robot%&group=%群号%&qq=%括号3%&je=%B%&type=1&collection_no=%括号1%$
如果:@A[state]==0
支付失败，飞机票准备!
A:$访问 ".ym."/API/qqgn/qsk.php?data=&skey=%S%&pskey=%A%&uin=%Robot%&group=%群号%&qq=%括号3%&je=%B%&type=3&collection_no=%括号1%$
$踢 %群号% %括号3%$
返回
如果尾
如果:@A[state]==1
内:±at %QQ%±\n支付状态：支付成功！\n欢迎加入本群！
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
$禁 %群号% %括号3% 0$

登录葫芦([0-9]+) (.*)
a:$访问 ".ym."/API/other/hlx_dl.php?key=%括号2%&phone=%括号1%$
如果:@a[status]==1
内:@a[user][nick]登录成功!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
$写 装扮/葫芦侠/%QQ% _key @a[_key]$
返回
如果尾
内:@a[msg]
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

葫芦签到
k:$读 装扮/葫芦侠/%QQ% _key 0$
内:$访问 ".ym."/API/other/hlx_qd.php?key=%k%$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

成长排行
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/vip_czbd.php?data=&skey=%s%&pskey=%p%&uin=%q%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

超会点赞
如果:$回调 ck判断$!=0
内:QQ:%QQ%\ncookie失效，请重新申请二维码! 
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
返回
如果尾
d:$读 二维码/%QQ%/cookie vip 0$
q:@d[uin]
s:@d[skey]
p:@d[pskey]
内:$访问 ".ym."/API/qqgn/vip_czdz.php?data=&skey=%s%&pskey=%p%&uin=%q%&data=text$
$写 小白/%群号% 图文数据 %内%$$回调 MSG$

切换图文
如果:%QQ%==%主人%
内:切换图文配置成功!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
$写 小白/装扮 pz 1$

切换文字
如果:%QQ%==%主人%
内:切换文字配置成功!
$写 小白/%群号% 图文数据 %内%$$回调 MSG$
$写 小白/装扮 pz 0$

[内部]MSG
K:$读 小白/%群号% 图文数据 0$
如果:$读 小白/装扮 pz 0$==1
a:$URLEncoder %K%\n\n%时间yyyy%年%时间MM%月%时间dd%日%时间HH%时%时间mm%分%时间ss%秒$
±img=".ym."/API/tw/hc.php?text=%a%&bgcolor=ffffff&sizecolor=000000±
$写 小白/%群号% 图文数据 小白API提供技术支持\n$
返回
如果尾
@$群昵称 %群号% %QQ%$±at %QQ%±\n
%K%
</pre>
