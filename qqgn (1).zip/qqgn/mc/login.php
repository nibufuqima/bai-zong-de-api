<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$code=$_REQUEST["code"];
$type=$_REQUEST["type"];
$token=$_REQUEST["token"];
if($type==null){
$data=file_get_contents("https://q.qq.com/ide/devtoolAuth/GetLoginCode");
$json=json_decode($data,true);
$array=array('code'=>$json["data"]["code"],'url'=>"https://h5.qzone.qq.com/qqq/code/".$json["data"]["code"]."?_proxy=1&from=ide");
Back($array);
}
if($type==="1"){
$url="https://q.qq.com/ide/devtoolAuth/syncScanSateGetTicket?code=".$code;
$header=array("Referer: https://q.qq.com/ide/devtoolAuth/syncScanSateGetTicket?code=".$code,"Accept-Language: zh-cn","Accept: */*");
$data="appid=1108057289&ticket=".$code;
$data=curl($url,$data,$header);
print_r($data);
}