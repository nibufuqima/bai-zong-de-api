<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$code=$_REQUEST["code"];
$type=$_REQUEST["type"];
$lx=$_REQUEST["lx"];
$id=$_REQUEST["id"];
$pet=$_REQUEST["pet"];
$ticket=$_REQUEST["ticket"];
$n=$_REQUEST["n"];
$token=$_REQUEST["token"];
$header=array("Content-Type: application/x-www-form-urlencoded","User-Agent: Dalvik/2.1.0 (Linux; U; Android 11; Redmi K30 Build/RKQ1.200826.002)","Host: limi.jwetech.com","Connection: Keep-Alive","Accept-Encoding: gzip");
if($type==="1"){
$url="https://q.qq.com/ide/login";
$header=array("Referer: https://q.qq.com/ide/login");
$data="appid=1110761090&ticket=".$ticket;
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$code=$json["code"];
$url="https://limi.jwetech.com/api/authorizations";
$header=array("Referer: https://limi.jwetech.com/api/authorizations","User-Agent: Mozilla/5.0 (Linux; Android 7.0; MI 5 Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/044203 Mobile Safari/537.36","Content-Type: application/json;charset=UTF-8","Accept: application/json","Host: limi.jwetech.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$data='{"provider":"qqgame","data":{"platform":"android","code":"'.$code.'"},"friends":[],"src":3026}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$code=$json["code"]?:"0";
//print_r($data);
if($code=="0"){
$array=array('code'=>$code,'avatar'=>$json["avatar"],'nick'=>$json["nick"],'id'=>$json["id"],'nick'=>$json["nick"],'level'=>$json["level"],'distance'=>$json["distance"],'speed'=>$json["speed"],'token'=>$json["token"]);
print_r(jsonjx($array));
}else{
print_r($data);
}
}
$header=array("User-Agent: Mozilla/5.0 (Linux; Android 7.0; MI 5 Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/044203 Mobile Safari/537.36","Content-Type: application/json;charset=UTF-8","Accept: application/json","authorization: authorization=Bearer ".$token."","Host: limi.jwetech.com","Connection: Keep-Alive","Accept-Encoding: gzip");
if($type!=null &&$type!=1){
$data=curl("https://limi.jwetech.com/api/users/pets?src=3026",null,$header);
$json=json_decode($data,true);
if($json["code"]=="401"){
print_r($data);
exit();
}
}
if($type=="2"){//厘萌签到
mcgg("ma_sign-show",null);
$url="https://limi.jwetech.com/api/sign_in";
$data='{"day":'.(date("w")-1).',"type":2}';
$data=curl($url,$data,$header);
print_r($data);
}
if($type=="14"){//厘萌补签
$url="https://limi.jwetech.com/api/sign_in";
mcgg("ma_sign-show",null);
/*print_r('{"message":"提交任务成功!"}');
ignore_user_abort(); //客户端断开时，可以让脚本继续在后台执行
set_time_limit(0);		
fastcgi_finish_request();//先返回上面的内容*/
for($i=0;$i<7;$i++){
$data='{"day":'.$i.',"type":1}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$s="星期".$i.":".$json["message"]."\n";
$sa=$sa.$s;
usleep(500);
}
}
if($type=="3"){//星球奖励
$url="https://limi.jwetech.com/api/level_rewards";
$data='{"src":3001}';
$data=curl($url,$data,$header);
print_r($data);
}
if($type=="4"){//宠物出门
$url="https://limi.jwetech.com/api/users/pets/".$pet;
$data='{"isOut":true,"src":3001}';
$data = callInterfaceCommon($url, "PUT", $data, $header);
print_r($data);
}
if($type=="5"){//清洗宠物
$url="https://limi.jwetech.com/api/users/pets/".$pet;
$data=curl($url,null,$header);
$data='{"state":1,"src":3026}';
$data = callInterfaceCommon($url, "PUT", $data, $header);
print_r($data);
}
if($type=="6"){//捕捉宠物
$url="https://limi.jwetech.com/api/friends?src=3026";
$data=curl($url,null,$header);
$json=json_decode($data,true);
$s=count($json["list"]);
$s=mt_rand(0,$s - 1);
$id1=$json["list"][$s]["id"];
$url="https://limi.jwetech.com/api/users/".$id1."?src=3026";
$data=curl($url,null,$header);
$json=json_decode($data,true);
$s=count($json["pets"]);
$s=mt_rand(0,$s - 1);
$pet=$json["pets"][$s]["id"];
$data='{"userId":"'.$id1.'","petId":'.$pet.',"useCard":false,"src":3026}';
$url="https://limi.jwetech.com/api/captures";
$data=curl($url,$data,$header);
print_r($data);
}
if($type=="7"){//偷取能量
$url="https://limi.jwetech.com/api/friends?src=3026";
$data=curl($url,null,$header);
$json=json_decode($data,true);
$s=count($json["list"]);
$s=mt_rand(0,$s - 1);
$id1=$json["list"][$s]["id"];
$data='{"userId":"'.$id1.'","ad":false,"src":3026}';
$url="https://limi.jwetech.com/api/collector";
$data=curl($url,$data,$header);
print_r($data);
}
if($type=="8"){//收取能量
$data=curl("https://limi.jwetech.com/api/users/collector?src=3001",null,$header);
mcgg("cli_adv_collect_ad","cli_adv_collect_ad_suc");
$data='{"userId":"'.$id.'","ad":true,"src":3001}';
$url="https://limi.jwetech.com/api/collector";
$data=curl($url,$data,$header);
print_r($data);
}
if($type=="9"){//厘萌喂食
$data=curl("https://limi.jwetech.com/api/users/feeds?src=3001",null,$header);
mcgg("feed-ad-cli-2",null);
mcgg("cli_adv_feed_food_ad","cli_adv_feed_food_ad_suc");
$data='{"petId":'.$pet.',"foodId":2,"ad":true,"src":3026}';
$url="https://limi.jwetech.com/api/feeds";
$data=curl($url,$data,$header);
print_r($data);
}
if($type=="10"){//厘萌任务
$data=curl("https://limi.jwetech.com/api/missions?src=3001",null,$header);
$json=json_decode($data,true);
mcgg("task-do-1201",null);
mcgg("cli_adv_task_ad","cli_adv_task_ad_suc");
$data='{"source":"missiondailyad","src":3026}';
$url="https://limi.jwetech.com/api/ads";
$data=curl($url,$data,$header);
for($i=0;$i<3;$i++){
foreach ($json[$i]["missions"] as $key => $value){
$data='{"src":3026}';
mcgg("task-do-".$value["id"]."",null);
$url="https://limi.jwetech.com/api/missions/".$value["id"]."/receive";
$data=curl($url,$data,$header);
$data=json_decode($data,true);
print_r($value["title"].":".$data["message"]."\n");
sleep(1);
}
}
}
if($type=="11"){//喂食状态
$data=curl("https://limi.jwetech.com/api/users/pets?src=3026",null,$header);
$json=json_decode($data,true);
if($lx=="1"){
foreach ($json as $key => $value){
echo "id:".$value["id"]."\n";
echo "宠物:".$value["name"]."\n";
echo "等级:".$value["level"]."\n";
echo "经验:".$value["experience"]."\n";
echo "喂食:".$value["feed"]["countdown"]."s\n";
echo "------------\n";
}}else{
print_r($data);
}
}
if($type=="12"){//能量状态
$data=curl("https://limi.jwetech.com/api/collector",null,$header);
print_r($data);
}
if($type=="13"){//自动喂食
$data=curl("https://limi.jwetech.com/api/users/collector?src=3026",null,$header);
mcgg("cli_adv_auto_feed","cli_adv_auto_feed_suc");
$data='{"id":3,"count":1,"ad":true,"src":3026}';
$url="https://limi.jwetech.com/api/cards";
$data=curl($url,$data,$header);
$data='{"id":3,"petId":'.$pet.',"src":3026}';
$url="https://limi.jwetech.com/api/cards/3/use";
$data=curl($url,$data,$header);
print_r($data);
}

function mcgg($id,$id1){//跳过广告
$token=$_REQUEST["token"];
$header=array("User-Agent: Mozilla/5.0 (Linux; Android 5.1.1; OPPO R11 Plus Build/LMY48Z; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.100 Safari/537.36 V1_AND_SQ_8.1.8_1276_YYB_D QQ/8.1.8.4260 NetType/WIFI WebP/0.4.1 Pixel/720 StatusBarHeight/30 SimpleUISwitch/0","Referer: https://appservice.qq.com/1110761090/1.2.46/page-frame.html","authorization: authorization=Bearer ".$token."");
$url="https://limi.jwetech.com/api/e";
$data='{"name":"'.$id.'","src":3026}';
$data=curl($url,$data,$header);
$data1='{"name":"'.$id1.'","src":3026}';
$data1=curl($url,$data1,$header);
return $data.$data1.$data3;
}

function callInterfaceCommon($URL, $type, $params, $headers){ 
        $ch = curl_init(); 
        $timeout = 5;
        curl_setopt ($ch, CURLOPT_URL, $URL); //接口地址

        if($headers!=""){ 
            curl_setopt ($ch, CURLOPT_HTTPHEADER, $headers); 
        }else { 
            curl_setopt ($ch, CURLOPT_HTTPHEADER, array("Content-type:application/json;charset=utf-8")); 
        } 
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
        switch ($type){ 
            case "GET" : curl_setopt($ch, CURLOPT_HTTPGET, true);break; 
            case "POST": curl_setopt($ch, CURLOPT_POST,true);  
                         curl_setopt($ch, CURLOPT_POSTFIELDS, $params);break; 
            case "PUT" : curl_setopt ($ch, CURLOPT_CUSTOMREQUEST, "PUT");  
                         curl_setopt($ch, CURLOPT_POSTFIELDS,$params);break; 
            case "DELETE":curl_setopt ($ch, CURLOPT_CUSTOMREQUEST, "DELETE");  
                          curl_setopt($ch, CURLOPT_POSTFIELDS,$params);break; 
        } 
        $file_contents = curl_exec($ch);//获得返回值 
        curl_close($ch);
        return $file_contents;
    }
