<p></p><pre>
获取code和链接
".ym."/API/qqgn/mc/login.php
[获取code和url]

登录小程序
".ym."/API/qqgn/mc/login.php?type=1&code=
[获取ticket]

登录安全中心
".ym."/API/qqgn/mc/safety.php?type=1&ticket=
[获取id和token]

违规记录查询
".ym."/API/qqgn/mc/safety.php?type=2&id=id值&token=token值&uin=账号

</pre>
