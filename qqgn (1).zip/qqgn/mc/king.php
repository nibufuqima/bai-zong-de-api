<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$code=$_REQUEST["code"];
$type=$_REQUEST["type"];
$ticket=$_REQUEST["ticket"];
$id=$_REQUEST["id"];
$roleId=$_REQUEST["roleId"];
$userId=$_REQUEST["userId"];
$page=$_REQUEST["page"]?:"1";
$max=($page*10);
$key=($max-10);
$token=$_REQUEST["token"];
$url="https://q.qq.com/ide/login";
$header=array("Referer: https://q.qq.com/ide/login");
$data="appid=1112105310&ticket=".$ticket;
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$code=$json["code"];
if($type==="1"){
$url="https://ssl.kohsocialapp.qq.com:10001/user/miniprogramlogin";
$header=array("Referer: https://appservice.qq.com/1112105310/1.3.22/page-frame.html","User-Agent: Mozilla%2F5.0+%28Linux%3B+Android+12%3B+Redmi+K30+Build%2FSKQ1.210908.001%3B+wv%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Version%2F4.0+Chrome%2F96.0.4664.104+Mobile+Safari%2F537.36 QQ/8.8.93.8060 V1_AND_SQ_8.8.93_2862_HDBM_T QQ/MiniApp","NOENCRYPT: 1","content-type: application/x-www-form-urlencoded","Host: ssl.kohsocialapp.qq.com:10001","Connection: Keep-Alive","Accept-Encoding: gzip");
$data='cClientVersionCode=9999999999&cClientVersionName=9.99.999&gameId=20001&cGameId=20001&ssoAppId=campMiniProgram&ssoBusinessId=mini&code='.$code.'&sAppId=1112105310&game=yxzj&key1=&key2=&key3=&key4=&key5=2.75&key6=393&key7=873&key8=Redmi&key9=Redmi%20K30&key10=&key11=&key12=Android%2012&key13=wifi&key14=&key15=&key16=&key17=&key18=Redmi%20K30&key19=&key20=&key21=&key22=';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$code=$json["result"]?:"0";
if($code=="0"){
$array=array('code'=>$code,'userId'=>$json["data"]["user"]["userId"],'roleId'=>$json["data"]["user"]["roleId"],'openid'=>$json["data"]["ssoSession"]["session"]["ssoOpenId"],'token'=>$json["data"]["ssoSession"]["session"]["ssoToken"]);
print_r(jsonjx($array));
}else{
print_r($data);
}
}
if($type==="2"){//王者信息
$url="https://kohcamp.qq.com/game/profile";
$header=array("gameId: 20001","ssoBusinessId: mini","ssoOpenId: ".$id."","cClientVersionName: 9.99.999","Referer: https://appservice.qq.com/1112105310/1.3.22/page-frame.html","User-Agent: Mozilla%2F5.0+%28Linux%3B+Android+12%3B+Redmi+K30+Build%2FSKQ1.210908.001%3B+wv%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Version%2F4.0+Chrome%2F96.0.4664.104+Mobile+Safari%2F537.36 QQ/8.8.93.8060 V1_AND_SQ_8.8.93_2862_HDBM_T QQ/MiniApp","content-type: application/json","cGameId: 20001","ssoToken: ".$token."","ssoAppId: campMiniProgram","cClientVersionCode: 9999999999","Host: kohcamp.qq.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$data='{"friendUserId":'.$userId.',"friendRoleId":"'.$roleId.'"}';
$data=curl($url,$data,$header);
print_r($data);

/*foreach ($json["records"] as $key => $value){
echo "违规时间:".date('Y-m-d H:i:s', $value["time"])."\n";
echo "违规操作:因涉嫌".$reason[$value["reason"]]."被".$typ."\n------------\n";
}*/
}
