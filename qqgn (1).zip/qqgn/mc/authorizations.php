<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$code=$_REQUEST["code"];
$type=$_REQUEST["type"];
$id=$_REQUEST["id"];
$n=$_REQUEST["n"];
$token=$_REQUEST["token"];
$header=array("Content-Type: application/x-www-form-urlencoded","User-Agent: Dalvik/2.1.0 (Linux; U; Android 11; Redmi K30 Build/RKQ1.200826.002)","Host: qqstore.jwetech.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$dat='openudid='.$id.'&token='.$token;
$data=curl("https://qqstore.jwetech.com/mall/login/index",$dat,$header);
$json=json_decode($data,true);
$sessid=$json["data"]["sessid"];
if($type===null){
$data=curl("https://q.qq.com/ide/devtoolAuth/GetLoginCode");
$json=json_decode($data,true);
$array=array('code'=>$json["data"]["code"],'url'=>"https://h5.qzone.qq.com/qqq/code/".$json["data"]["code"]."?_proxy=1&from=ide");
print_r(jsonjx($array));
}
if($type==="1"){
$url="https://q.qq.com/ide/devtoolAuth/syncScanSateGetTicket?code=".$code;
$header=array("Referer: https://q.qq.com/ide/devtoolAuth/syncScanSateGetTicket?code=".$code,"Accept-Language: zh-cn","Accept: */*");
$data="appid=1108057289&ticket=".$code;
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$ticket=$json["data"]["ticket"];
$code=$json["data"]["code"];
$url="https://q.qq.com/ide/login";
$header=array("Referer: https://q.qq.com/ide/login");
$data="appid=1108057289&ticket=".$ticket;
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$code=$json["code"];
$url="https://qqpet.jwetech.com/api/authorizations";
$header=array("Referer: https://qqpet.jwetech.com/api/authorizations","User-Agent: Mozilla/5.0 (Linux; Android 7.0; MI 5 Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/044203 Mobile Safari/537.36","Content-Type: application/json;charset=UTF-8","Accept: application/json","Host: qqpet.jwetech.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$data='{"data":{"nickName":"","avatarUrl":"","gender":1,"province":"","city":"","country":"","language":"zh_CN","code":"'.$code.'"},"friends":"[]","extra":"{\"query\":{\"src\":\"499\"},\"scene\":2014,\"src\":\"499\"}","provider":"qqgame"}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
//$code=$json["code"]?:"0";
print_r($data);
//$array=array('code'=>$code,'coins'=>$json["coins"],'vigours'=>$json["vigours"],'id'=>$json["id"],'nick'=>$json["nick"],'level'=>$json["pet"]["level"],'expirenece'=>$json["pet"]["expirenece"],'token'=>$json["token"]);
//print_r(jsonjx($array));
}
if($type!=null &&$type!=1){
$header=array("User-Agent: Mozilla/5.0 (Linux; Android 7.0; MI 5 Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/6.2 TBS/044203 Mobile Safari/537.36","Content-Type: application/json;charset=UTF-8","Accept: application/json","authorization: authorization=Bearer ".$token."","Host: qqpet.jwetech.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$url="https://qqpet.jwetech.com/api/captures/free";
$data='{}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
if($json["code"]=="401"){
print_r($json["message"]);
exit();
}
}
if($type=="2"){//萌宠签到
$data=curl("https://qqpet.jwetech.com/api/v2/daily_signs?__src=3001",null,$header);
mcgg("cli_cli_advideo_signIn","cli_advideo_signIn_suc");
$data=curl("https://qqpet.jwetech.com/api/v2/daily_signs",null,$header);
$json=json_decode($data,true);
$day=$json["day"];
$url="https://qqpet.jwetech.com/api/v2/daily_signs";
$data='{"ad":true,"day":'.$day.',"__src":3001}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
if($data=="{}"){
echo "今日已签到!";
exit();
}
foreach ($json["items"] as $key => $value){
echo "获得:".$value["name"]."\n";
}
}
if($type=="3"){//每日礼物
for($i=0;$i<4;$i++){
$url="https://qqpet.jwetech.com/api/click_plays";
$data='{}';
$dat=curl($url,null,$header);
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$name=$json["name"];
if($data=="{}"){
echo "今日已领取!";
exit();
}
echo ($i+1).":".$name."\n";
}
}
if($type=="4"){//游戏打卡
$data=curl("https://qqpet.jwetech.com/api/games",null,$header);
$json=json_decode($data,true);
foreach ($json["games"] as $key => $value){
$data=curl($value["url"],null,$header);
$dat='{"gameId":'.$value["id"].'}';
$data=curl("https://qqpet.jwetech.com/api/games",$dat,$header);
$json=json_decode($data,true);
$coin="获得金币".$json["coin"]."个!";
if($data=="{}"){
$coin="今日已打卡!";
}
echo $value["title"].":".$coin."\n";
sleep(1);
}}
if($type=="5"){//清洗喂食
$url="https://qqpet.jwetech.com/api/captures/free";
$data='{}';
$data=curl($url,$data,$header);
print_r($data);
}
if($type=="6"){//每日任务
$data=curl("https://qqpet.jwetech.com/api/daily_missions?__src=3001",null,$header);
mcgg("cli_cli_advideo_task-ad-coins","cli_advideo_task-ad-coins_suc");
$dat='{"missionId":106,"__src":3001}';
$data=curl("https://qqpet.jwetech.com/api/daily_missions",$dat,$header);
$data=curl("https://qqpet.jwetech.com/api/daily_missions",null,$header);
$json=json_decode($data,true);
foreach ($json["missions"] as $key => $value){
$dat='{"missionId":'.$value["id"].'}';
$data=curl("https://qqpet.jwetech.com/api/daily_missions",$dat,$header);
$json=json_decode($data,true);
if($value["taked"]=="1"){
$nr="任务奖励已领取!";
}
if($value["taked"]==null){
$nr="该任务未完成!";
}
print_r($value["title"].":".$nr."\n");
sleep(1);
}
}
if($type=="7"){//元气抽奖
$heade=array("Content-Type: application/x-www-form-urlencoded","User-Agent: Dalvik/2.1.0 (Linux; U; Android 11; Redmi K30 Build/RKQ1.200826.002)","Host: qqstore.jwetech.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$dat='openudid='.$id.'&sessid='.$sessid;
$data1=curl("https://qqstore.jwetech.com/mall/vitality/slot",$dat,$heade);
preg_match_all('/"name":\"(.*?)\"/',$data1,$name);
preg_match_all('/"id":\"(.*?)\"/',$data1,$id);
$data=curl("https://qqstore.jwetech.com/mall/vitality/play",$dat,$heade);
$json=json_decode($data,true);
for($i=0;$i<20;$i++){
$data=curl("https://qqstore.jwetech.com/mall/vitality/play",$dat,$heade);
$json=json_decode($data,true);
if($json["iRet"]=="-1"){
print_r("今日抽奖次数已用光!");
exit();
}
$str=array_search($json["data"]["gid"],$id[1]);
$str=$name[1][$str];
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $str);
print_r(($i+1).":".$str."\n");
sleep(1);
}
}
if($type=="8"){//视频元气
$dat='ad_type=0&openudid='.$id.'&sessid='.$sessid.'&token='.$token;
for($i=0;$i<20;$i++){
$data=curl("https://qqstore.jwetech.com/guess/home/ad-play",$dat,$header);
$json=json_decode($data,true);
if($json["iRet"]=="-1"){
print_r("今日次数已用光!");
exit();
}
$data1=curl("https://qqstore.jwetech.com/guess/home/ad-close",$dat,$header);
sleep(1);
}
print_r("观看视频领取元气值成功!");
}
if($type=="9"){//商城签到
$dat='type=1&openudid='.$id.'&sessid='.$sessid;
$data=curl("https://qqstore.jwetech.com/mall/vitality/sign-in",$dat,$header);
$json=json_decode($data,true);
if($json["iRet"]=="-1"){
print_r("今日次数已用光!");
exit();
}
print_r($data);
}
if($type=="10"){//好友金币
$dat=curl("https://qqpet.jwetech.com/api/rankings",null,$header);
$json=json_decode($dat,true);
foreach ($json["friends"] as $key => $value){
$dat='{"userId":"'.$value["id"].'","ad":true}';
$data=curl("https://qqpet.jwetech.com/api/counters",$dat,$header);
print_r($data);
sleep(1);
}
print_r("收取好友金币完成!");
}
if($type=="11"){//收取金币
$data=curl("https://qqpet.jwetech.com/api/counters?userId=".$id."&__src=3001",null,$header);
mcgg("cli_cli_advideo_counter","cli_advideo_counter_suc");
$dat='{"userId":"'.$id.'","ad":true,"__src":3001}';
$data=curl("https://qqpet.jwetech.com/api/counters",$dat,$header);
print_r($data);
}
if($type=="12"){//萌宠点击
for($i=0;$i<15;$i++){
$data=curl("https://qqpet.jwetech.com/api/click_plays?__src=3001",null,$header);
mcgg("cli_cli_advideo_clickplay","cli_advideo_clickplay");
$dat='{"__src":3001}';
$data=curl("https://qqpet.jwetech.com/api/click_plays",$dat,$header);
sleep(1);
}
print_r("萌宠礼物收取完成！");
}
if($type=="13"){//萌宠游戏
$data=curl("https://qqpet.jwetech.com/api/games?__src=3001",null,$header);
$data=str_replace("false",'"false"',$data);
$data=str_replace("ture",'"ture"',$data);
$json=json_decode($data,true);
foreach ($json["games"] as $key => $value){
if($value["todayCompleted"]=="false"){
$heade=array("Host: qqpet.jwetech.com","Referer: https://appservice.qq.com/1108057289/6.9.20/page-frame.html","User-agent: Mozilla%2F5.0+%28Linux%3B+Android+10%3B+HRY-AL00Ta+Build%2FHONORHRY-AL00Ta%3B+wv%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Version%2F4.0+Chrome%2F80.0.3987.99+Mobile+Safari%2F537.36 QQ/8.8.23.6010 V1_AND_SQ_8.8.23_2034_YYB_D QQ/MiniApp","content-type: application/json","x-game-version: 6.9.80511","accept-encoding: gzip","authorization: authorization=Bearer ".$token."");
$url="https://qqpet.jwetech.com/api/e";
$data='{"name":"game-out-'.$value["id"].'","gameId":"0","__src":3001}';
$data=curl($url,$data,$heade);
$dat='{"gameId":"'.$value["id"].'","__src":3001}';
$data=curl("https://qqpet.jwetech.com/api/games",$dat,$header);
}
sleep(1);
}
print_r("萌宠游戏任务执行完成！");
}
if($type=="14"){//萌宠信息
$data=curl("https://qqpet.jwetech.com/api/users/profile",null,$header);
$json=json_decode($data,true);
print_r("id:".$json["id"]."\n昵称:".$json["nick"]."\n金币:".$json["coins"]."\n元气值:".$json["vigours"]."\n");
}
if($type=="15"){//道具列表
$data=curl("https://qqpet.jwetech.com/api/cards?__src=3001",null,$header);
$json=json_decode($data,true);
foreach ($json["cards"] as $key => $value){
echo ($key +1 ).":".$value["name"]."-数量:".$value["count"]."\n";
}}
if($type=="16"){//使用道具
$data=curl("https://qqpet.jwetech.com/api/cards?__src=3001",null,$header);
$json=json_decode($data,true);
$data='{"userId":"'.$id.'","__src":3001}';
$id=$json["cards"][$n - 1]["id"];
$url="https://qqpet.jwetech.com/api/cards/".$id;
$data = callInterfaceCommon($url, "PUT", $data, $header);
$json=json_decode($data,true);
print_r($json);
}
if($type=="17"){//收取元气
$data=curl("https://qqpet.jwetech.com/api/vigours?__src=3001",null,$header);
$json=json_decode($data,true);
$di=$json["uncollectedVigours"][0]["id"];
for($i=0;$i<4;$i++){
$data=curl("https://qqpet.jwetech.com/api/messages/news?__src=3001",null,$header);
mcgg("cli_cli_advideo_vigour","cli_advideo_vigour_suc");
sleep(2);
}
$data=curl("https://qqpet.jwetech.com/api/messages/news?__src=3001",null,$header);
mcgg("cli_cli_advideo_vigour-ad","cli_advideo_vigour-ad_suc");
$dat='{"userId":"'.$id.'","ad":true,"__src":3001}';
$url="https://qqpet.jwetech.com/api/vigours/".$di;
$data = callInterfaceCommon($url, "PUT", $dat, $header);
print_r($data);
}
if($type=="18"){//食物列表
$data=curl("https://qqpet.jwetech.com/api/user_foods?__src=3001",null,$header);
$json=json_decode($data,true);
foreach ($json["foods"] as $key => $value){
echo ($key +1 ).":".$value["name"]."-数量:".$value["count"]."\n";
}}
if($type=="19"){//萌宠喂食
$data=curl("https://qqpet.jwetech.com/api/user_foods?__src=3001",null,$header);
$json=json_decode($data,true);
$id=$json["foods"][$n - 1]["id"];
$dat='{"foodId":'.$id.',"ad":false,"__src":3001}';
$data=curl("https://qqpet.jwetech.com/api/pet_feeds",$dat,$header);
print_r($data);
}
if($type=="20"){//兑换列表
$dat='openudid='.$id.'&token='.$token.'&sessid='.$sessid;
$data=curl("https://qqstore.jwetech.com/mall/award/list",$dat,$header);
$json=json_decode($data,true);
print_r($json);
}
if($type=="21"){//萌宠补签
for($i=0;$i<6;$i++){
$data=curl("https://qqpet.jwetech.com/api/v2/daily_signs?__src=3001",null,$header);
mcgg("cli_cli_advideo_complement","cli_advideo_complement_suc");
$dat='{"ad":true,"day":'.$i.',"__src":3001}';
$data=curl("https://qqpet.jwetech.com/api/v2/daily_signs",$dat,$header);
sleep(3);
}
print_r("补签提交成功！");
}
if($type=="23"){//随机补捉
$dat=curl("https://qqpet.jwetech.com/api/rankings",null,$header);
$json=json_decode($dat,true);
$s=count($json["friends"]);
$s=mt_rand(0,$s - 1);
$id=$json["friends"][$s]["id"];
$dat='{"userId":"'.$id.'","type":1,"ad":false,"__src":3001}';
$data=curl("https://qqpet.jwetech.com/api/captures",$dat,$header);
$json=json_decode($data,true);
print_r($data);
}
if($type=="24"){//随机摸取
$dat=curl("https://qqpet.jwetech.com/api/rankings",null,$header);
$json=json_decode($dat,true);
$s=count($json["friends"]);
$s=mt_rand(0,$s - 1);
$id=$json["friends"][$s]["id"];
$dat='{"userId":"'.$id.'","ad":true}';
$data=curl("https://qqpet.jwetech.com/api/counters",$dat,$header);
$json=json_decode($data,true);
print_r($data);
}
if($type=="25"){//喂食状态
$data=curl("https://qqpet.jwetech.com/api/pet_feeds",null,$header);
print_r($data);
}
if($type=="26"){//元气状态
$data=curl("https://qqpet.jwetech.com/api/counters",null,$header);
print_r($data);
}
if($type=="27"){//金币状态
$data=curl("https://qqpet.jwetech.com/api/vigours?__src=3001",null,$header);
$json=json_decode($data,true);
$di=$json["uncollectedVigours"][0]["id"];
$url="https://qqpet.jwetech.com/api/vigours/".$di;
$data=curl($url,null,$header);
print_r($data);
}


function mcgg($id,$id1){//跳过广告
$token=$_REQUEST["token"];
$header=array("Origin: https://1108057289.urlshare.cn","User-Agent: Mozilla/5.0 (Linux; Android 5.1.1; OPPO R11 Plus Build/LMY48Z; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.100 Safari/537.36 V1_AND_SQ_8.1.8_1276_YYB_D QQ/8.1.8.4260 NetType/WIFI WebP/0.4.1 Pixel/720 StatusBarHeight/30 SimpleUISwitch/0","Referer: https://1108057289.urlshare.cn/home?_proxy=1&app_display=2&_wwv=2048&_wv=2147628839&app_display=2&src=518","authorization: authorization=Bearer ".$token."");
$url="https://qqpet.jwetech.com/api/e";
$data='{"name":"'.$id.'","gameId":"0","__src":3001}';
$data=curl($url,$data,$header);
$data1='{"name":"'.$id1.'","gameId":"0","__src":3001}';
$data1=curl($url,$data1,$header);
return $data.$data1.$data3;
}
function callInterfaceCommon($URL, $type, $params, $headers){ 
        $ch = curl_init(); 
        $timeout = 5;
        curl_setopt ($ch, CURLOPT_URL, $URL); //接口地址

        if($headers!=""){ 
            curl_setopt ($ch, CURLOPT_HTTPHEADER, $headers); 
        }else { 
            curl_setopt ($ch, CURLOPT_HTTPHEADER, array("Content-type:application/json;charset=utf-8")); 
        } 
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
        switch ($type){ 
            case "GET" : curl_setopt($ch, CURLOPT_HTTPGET, true);break; 
            case "POST": curl_setopt($ch, CURLOPT_POST,true);  
                         curl_setopt($ch, CURLOPT_POSTFIELDS, $params);break; 
            case "PUT" : curl_setopt ($ch, CURLOPT_CUSTOMREQUEST, "PUT");  
                         curl_setopt($ch, CURLOPT_POSTFIELDS,$params);break; 
            case "DELETE":curl_setopt ($ch, CURLOPT_CUSTOMREQUEST, "DELETE");  
                          curl_setopt($ch, CURLOPT_POSTFIELDS,$params);break; 
        } 
        $file_contents = curl_exec($ch);//获得返回值 
        curl_close($ch);
        return $file_contents;
    }
