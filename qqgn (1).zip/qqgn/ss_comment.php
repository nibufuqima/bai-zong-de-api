<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$msg=$_REQUEST["msg"]?:"666";
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$tid=$_REQUEST["tid"];
$qq=$_REQUEST["qq"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$data="topicId=".$qq."_".$tid."__1&feedsType=100&inCharset=utf-8&outCharset=utf-8&plat=qzone&source=ic&hostUin=".$qq."&isSignIn=&platformid=52&uin=".$uin."&format=fs&ref=feeds&content=".$msg."&richval=&richtype=&private=0&paramstr=1&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Finfocenter%3Fvia%3Dtoolbar";
$url="https://user.qzone.qq.com/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_re_feeds?&g_tk=".getGTK($pskey);
$data=curl($url,$data,$header);
$data=getSubstr($data,'frameElement.callback(','); </script>');
$json=json_decode($data,true);
$Dat=$_REQUEST["data"];
//print_r($data);
if($Dat=="json"){
print_r($data);
}else{
if($json["subcode"]=="0"){
echo "当前操作:评论说说成功!\n评论内容:".$msg;
}elseif($json["code"]=="-3000"){
echo "cookie已失效!请重新获取";
}
}
