<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://zb.vip.qq.com/trpc/personalizeHomepage/GetAppsUsingList?g_tk=".getGTK($skey);
$header=array("User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Cookie: p_uin=o".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ","Referer: https://zb.vip.qq.com/v2/pages/home?_wv=5123&_wwv=128&ADTAG=mobileqq.drawer&trace_detail=base64-eyJhcHBpZCI6Im91dHNpZGUiLCJwYWdlX2lkIjoiMyJ9","Host: zb.vip.qq.com","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: ggzi","Content-Type: application/json; charset=UTF-8");
$data='{"clientInfo":{"opPlat":2,"QQVersion":"8.6.0"}}';
$json=get_result($url,$data,$header);
$data=json_decode($json,true);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($json);
}else{
$data="字体:".$data["data"]["usingList"][0]["name"]."(".$data["data"]["usingList"][0]["itemId"].")\n主题:".$data["data"]["usingList"][1]["name"]."(".$data["data"]["usingList"][1]["itemId"].")\n气泡:".$data["data"]["usingList"][2]["name"]."(".$data["data"]["usingList"][2]["itemId"].")\n挂件:".$data["data"]["usingList"][3]["name"]."(".$data["data"]["usingList"][3]["itemId"].")\n名片:".$data["data"]["usingList"][4]["name"]."(".$data["data"]["usingList"][4]["itemId"].")\n背景:".$data["data"]["usingList"][5]["name"]."(".$data["data"]["usingList"][5]["itemId"].")\n头像:".$data["data"]["usingList"][6]["name"]."(".$data["data"]["usingList"][6]["itemId"].")\n浮屏:".$data["data"]["usingList"][7]["name"]."(".$data["data"]["usingList"][7]["itemId"].")\n铃声:".$data["data"]["usingList"][8]["name"]."(".$data["data"]["usingList"][8]["itemId"].")\n来电:".$data["data"]["usingList"][9]["name"]."(".$data["data"]["usingList"][9]["itemId"].")";
print_r($data);}

