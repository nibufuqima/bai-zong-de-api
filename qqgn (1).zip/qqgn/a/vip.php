<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$lx=$_REQUEST["id"]?:"气泡";
$msg=urlencode($_REQUEST["msg"]);
$pt4_token=$_REQUEST["pt4_token"];
$skey=$_REQUEST["skey"];
$itemid=$_REQUEST["itemid"];
$type=$_REQUEST["type"];
$pskey=$_REQUEST["pskey"];
$page=$_REQUEST["page"]?:"1";
$page=($page - 1);
$m=$_REQUEST["max"]?:"10";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$id=array(
"进群特效" => "26",
"个性赞" => "20",
"个签" => "9",
"头像" => "23",
"背景" => "8",
"来电" => "17",
"名片" => "15",
"挂件" => "4",
"字体" => "5",
"主题" => "3",
"气泡" => "2"
);
$id=$id[$lx]?:$_REQUEST["id"];
if($type==null){
$url="https://zb.vip.qq.com/srf/QC_CommSearchServer_CommSearchObj/gxhCommSearch?srfId=13550&g_tk=".getGTK($skey);
$header=array("User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Cookie: p_uin=o".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ","Referer: https://zb.vip.qq.com/v2/pages/searchPage?_wv=2","Host: zb.vip.qq.com","Connection: Keep-Alive"
,"Charset: UTF-8","Accept-Encoding: ggzi","Content-Type: application/json; charset=UTF-8");
$data='{"itemClass":'.$id.',"platform":2,"searchKey":"'.$msg.'","writeHistoryFlag":0,"pageIndex":'.$page.',"pageItemNUm":40,"stLogin":{"iKeyType":1,"iOpplat":2,"lUin":'.$uin.',"sClientIp":"","sClientVer":"8.8.5","sSKey":"string"}}';
$json=get_result($url,$data,$header);
$data=json_decode($json,true);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($json);
}else{
$dat=$data["data"]["rsp"]["results"][0];
foreach($data["data"]["rsp"]["results"] as $k=>$v){
if($k==$m){
        break; 
    }
echo ($k+1).":".$v["name"]."-".$v["itemId"];
echo "[".lx($v["feeType"])."]\n";
}}
}elseif($type=="1"){
$url="https://zb.vip.qq.com/srf/QC_UniBusinessLogicServer_UniBusinessLogicObj/uniSet?g_tk=".getGTK($pskey);
$header=array("Cookie: p_uin=o".$uin."; qqNumber=".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ","User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; Redmi K30 Build/SKQ1.210908.001) V1_AND_SQ_8.8.88_2770_YYB_D A_8088800 QQ/8.8.88.7830 NetType/WIFI WebP/0.4.1 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1000 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537117930","Content-Type: application/json","Host: zb.vip.qq.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$data='{"stLogin":{"iOpplat":3,"sClientVer":"8.8.88","sSKey":"'.getGTK($skey).'","sClientIp":"","iKeyType":1,"lUin":'.$uin.'},"stUniBusinessItem":{"itemid":"'.$itemid.'","appid":'.$id.',"hashid":""}}';
$json=curl($url,$data,$header);
$data=json_decode($json,true);
$data=$data["data"]["rsp"]["ret"];
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($json);
}else{
if($data=="0"){
echo "设置成功!";
}else{
echo "设置失败!";
}
}}
function lx($msg){
if($msg=="5"){
return "SVIP";
}elseif($msg=="2"){
return "付费";
}elseif($msg=="14"){
return "续费SVIP";
}elseif($msg=="6"){
return "活动";
}elseif($msg=="41"){
return "限免";
}elseif($msg=="4"){
return "VIP";
}elseif($msg=="42"){
return "广告";
}elseif($msg=="7"){
return "星影";
}}