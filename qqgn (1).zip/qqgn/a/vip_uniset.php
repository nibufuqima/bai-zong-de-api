<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$lx=$_REQUEST["id"]?:"气泡";
$msg=urlencode($_REQUEST["msg"]);
$pt4_token=$_REQUEST["pt4_token"];
$skey=$_REQUEST["skey"];
$itemid=$_REQUEST["itemid"];
$pskey=$_REQUEST["pskey"];
$m=$_REQUEST["max"]?:"10";
$id=array(
"进群特效" => "26",
"个性赞" => "20",
"个性签名" => "9",
"头像" => "23",
"背景" => "8",
"来电" => "17",
"名片" => "15",
"挂件" => "4",
"字体" => "5",
"主题" => "3",
"浮屏" => "22",
"气泡" => "2"
);
$id=$id[$lx];
$url="https://zb.vip.qq.com/srf/QC_UniBusinessLogicServer_UniBusinessLogicObj/uniSet?g_tk=".getGTK($skey);
$header=array("User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Cookie: p_uin=o".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ","Referer: https://zb.vip.qq.com/v2/pages/bubbleMall","Host: zb.vip.qq.com","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: ggzi","Content-Type: application/json; charset=UTF-8");
$data='{"stLogin":{"iKeyType":1,"iOpplat":2,"lUin":'.$uin.',"sClientIp":"","sClientVer":"8.8.3","sSKey":"1838297681"},"stUniBusinessItem":{"appid":'.$id.',"itemid":0,"hashid":""},"stFont":{"isWithTheme":0,"forbidThemeFont":0},"stBubble":{"deltype":0}}';
$json=get_result($url,$data,$header);
$data=json_decode($json,true);
$data=$data["data"]["rsp"]["ret"];
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($json);
}else{
if($data=="0"){
echo "取消成功!";
}else{
echo "取消失败!";
}}