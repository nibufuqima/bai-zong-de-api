<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$lx=$_REQUEST["id"]?:"气泡";
$msg=urlencode($_REQUEST["msg"]);
$pt4_token=$_REQUEST["pt4_token"];
$skey=$_REQUEST["skey"];
$itemid=$_REQUEST["itemid"];
$type=$_REQUEST["type"];
$pskey=$_REQUEST["pskey"];
$page=$_REQUEST["page"]?:"1";
$page=($page - 1);
$m=$_REQUEST["max"]?:"10";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$id=array(
"进群特效" => "26",
"个性赞" => "20",
"个签" => "9",
"头像" => "23",
"背景" => "8",
"来电" => "17",
"名片" => "15",
"挂件" => "4",
"字体" => "5",
"主题" => "3",
"气泡" => "2"
);
$id=$id[$lx];
$url="https://club.vip.qq.com/api/aggregation?g_tk=".getGTK($pskey);
$header=array("User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; Redmi K30 Build/SKQ1.210908.001) V1_AND_SQ_8.8.85_2712_YYB_D A_8088500 QQ/8.8.85.7685 NetType/WIFI WebP/0.4.1 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537116199","Content-Type: application/json","Host: club.vip.qq.com","Connection: Keep-Alive","Accept-Encoding: gzip","Cookie: p_uin=o".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ");
$data='{"commonInfo.getQQInfo":{"args":["'.$uin.'"]},"commonInfo.getQQLevelInfo":{"args":["'.$uin.'"],"needCtx":false}}';
$data=curl($url,$data,$header);
$data=json_decode($data,true);
$msg=vip($data["data"]["commonInfo.getQQLevelInfo"]["iSVip"],$data["data"]["commonInfo.getQQLevelInfo"]["iVip"]);
$url="https://zb.vip.qq.com/trpc-proxy/qqva/qc_search_server/personalize_search/gxhCommSearch";
$header=array("Host: zb.vip.qq.com","Connection: keep-alive","Accept: application/json, text/plain, */*","User-Agent: Mozilla/5.0 (Linux; Android 12; Redmi K30 Build/SKQ1.210908.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/95.0.4638.74 Mobile Safari/537.36 V1_AND_SQ_8.8.85_2712_YYB_D A_8088500 QQ/8.8.85.7685 NetType/WIFI WebP/0.4.1 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537116199","Content-Type: application/json","Origin: https://zb.vip.qq.com","X-Requested-With: com.tencent.mobileqq","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Referer: https://zb.vip.qq.com/v2/pages/searchPage?_wv=2&appid=2","Accept-Encoding: gzip, deflate","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Cookie: p_uin=o".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ");
$data='{"req":{"itemClass":'.$id.',"searchKey":"'.$msg.'","writeHistoryFlag":1,"pageIndex":'.mt_rand(0,y($msg)).',"pageItemNUm":40},"options":{"naming":{"namespace":"Production","env":"formal"}}}';
$data=curl($url,$data,$header);
$data=json_decode($data,true)["response"]["results"];
$s=mt_rand(0,count($data)-1);
$itemid=$data[$s]["itemId"];
$url="https://zb.vip.qq.com/srf/QC_UniBusinessLogicServer_UniBusinessLogicObj/uniSet?g_tk=".getGTK($skey);
$header=array("User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Cookie: p_uin=o".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ","Referer: https://zb.vip.qq.com/v2/pages/bubbleMall","Host: zb.vip.qq.com","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: ggzi","Content-Type: application/json; charset=UTF-8");
$data='{"stLogin":{"iKeyType":1,"iOpplat":2,"lUin":'.$uin.',"sClientIp":"","sClientVer":"8.8.88","sSKey":"'.getGTK($skey).'"},"stUniBusinessItem":{"appid":'.$id.',"itemid":'.$itemid.',"hashid":""},"stFont":{"isWithTheme":0,"forbidThemeFont":0},"stBubble":{"deltype":0}}';
$json=get_result($url,$data,$header);
print_r($json);
function vip($svip,$vip){
if($svip=="1"){
return "SVIP";
}elseif($vip=="1"){
return "VIP";
}else{
return "限免";
}
}
function y($svip){
if($svip=="SVIP"){
return "13";
}elseif($svip=="VIP"){
return "8";
}else{
return "限免";
}
}

