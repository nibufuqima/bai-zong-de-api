<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$time=time();
if($_GET["type"]=="1"){
$port="101483052";
$url='https://ssl.ptlogin2.qq.com/ptqrshow?appid=716027609&e=2&l=M&s=3&d=72&v=4&t=0.'.$time.'&daid=383&pt_3rd_aid='.$port;
$header=array("User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36","Referer: https://xui.ptlogin2.qq.com/cgi-bin/xlogin?appid=716027609&daid=383&style=33&theme=2&login_text=%E6%8E%88%E6%9D%83%E5%B9%B6%E7%99%BB%E5%BD%95&hide_title_bar=1&hide_border=1&target=self&s_url=https%3A%2F%2Fgraph.qq.com%2Foauth2.0%2Flogin_jump&pt_3rd_aid=".$port."&pt_feedback_link=https%3A%2F%2Fsupport.qq.com%2Fproducts%2F77942%3FcustomInfo%3Dwww.qq.com.appid101483052");
$data=datacurl($url,null,$header);
preg_match('/qrsig=(.*?);/',$data['header'],$match);
file_put_contents("img/".$time.".jpg",$data["exec"]);
$data=json_encode(array("code"=>200,"picurl"=>"".ym."/API/qqgn/a/img/".$time.".jpg","qrsig"=>$match[1]));
$data=str_replace("\/",'/',$data);
echo $data;
ignore_user_abort(); //客户端断开时，可以让脚本继续在后台执行
set_time_limit(0);		
fastcgi_finish_request();//先返回上面的内容
time_sleep_until(time()+120);//延迟m秒后执行下面的命令
unlink("img/".$time.".jpg");

}else{
$url='https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fgraph.qq.com%2Foauth2.0%2Flogin_jump&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=383&pt_3rd_aid=101483052';//腾讯互联
$header=array("Connection: keep-alive","Accept-Language: zh-CN,zh;q=0.8","Accept-Encoding: gzip,deflate,sdch","Accept: */*");
$referer="https://xui.ptlogin2.qq.com/";
$cookie="qrsig=".$_GET["qrsig"]."";
$ua="Mozilla/5.0 (Linux; Android 9; V1901A Build/P00610; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/68.0.3440.91 Mobile Safari/537.36";
$ret = get_curl($url, null, $referer, $cookie, $header, $ua);
preg_match("/ptuiCB\\('(.*?)'\\)/", $ret, $arr);
$r = explode("','", str_replace("', '", "','", $arr[1]));
$code=$r[0];
$url=$r[2];
if ($code == "0") {
$ua="User-Agent: Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36";
$referer="Referer: https://xui.ptlogin2.qq.com/cgi-bin/xlogin?appid=716027609&daid=383&style=33&theme=2&login_text=%E6%8E%88%E6%9D%83%E5%B9%B6%E7%99%BB%E5%BD%95&hide_title_bar=1&hide_border=1&target=self&s_url=https%3A%2F%2Fgraph.qq.com%2Foauth2.0%2Flogin_jump&pt_3rd_aid=100497308&pt_feedback_link=https%3A%2F%2Fsupport.qq.com%2Fproducts%2F77942%3FcustomInfo%3D.appid100497308";
$cookie="Cookie: pgv_pvid=4533308488; fqm_pvqid=01815810-0a52-4fb0-af96-1d074bc545d1; fqm_sessionid=f4c9bdd0-1abb-4975-9721-2fd77205a0a5; pgv_info=ssid=s539468770; ui=76BDDE3E-A43E-4839-A4F0-B30EC5CE18A2; _qpsvr_localtk=0.5853174152413638; RK=Z6BEsQEbOw; ptcz=7ef36eff7b9a7f1d04354474a997f0b576a6dcd91b5cc59725afadf5b950f16b";
$header=array("Host: ssl.ptlogin2.graph.qq.com","Connection: keep-alive","Upgrade-Insecure-Requests: 1","Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","Sec-Fetch-Site: same-site","Sec-Fetch-Mode: navigate","Sec-Fetch-Dest: iframe","Accept-Encoding: gzip, deflate, br","Accept-Language: zh-CN,zh;q=0.9",$referer,$cookie);
$ret=datacurl($url,null,$header);
preg_match_all('/p_skey=(.*?);/',$ret['header'],$pskey);
preg_match_all('/pt_oauth_token=(.*?);/',$ret['header'],$pt_oauth_token);
preg_match_all('/pt4_token=(.*?);/',$ret['header'],$pt4_token);
preg_match_all('/p_uin=(.*?);/',$ret['header'],$p_uin);
$uin=$p_uin[1][0];
$pskey=$pskey[1][0];
$token=$pt4_token[1][0];
$ptoken=$pt_oauth_token[1][0];
$url="https://graph.qq.com/oauth2.0/authorize";
$post="response_type=code&client_id=101483052&redirect_uri=https%3A%2F%2Faccess.video.qq.com%2Fuser%2Fauth_login%3Fvappid%3D11059694%26vsecret%3Dfdf61a6be0aad57132bc5cdf78ac30145b6cd2c1470b0cfe%26raw%3D1%26type%3Dqq%26appid%3D101483052&scope=&state=&switch=&from_ptlogin=1&src=1&update_auth=1&openapi=80901010&g_tk=".getGTK($pskey)."&auth_time=".msectime()."&ui=036AC339-182A-44E6-B788-469846BC35E9";
$header=array("Host: graph.qq.com","Connection: keep-alive","Cache-Control: max-age=0","Upgrade-Insecure-Requests: 1","Origin: https://graph.qq.com","Content-Type: application/x-www-form-urlencoded","Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","X-Requested-With: mark.via","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: navigate","Sec-Fetch-Dest: iframe","Accept-Encoding: gzip, deflate","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$ua="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36";
$referer="Referer: https://graph.qq.com/oauth2.0/show?redirect_uri=https%3A%2F%2Faccess.video.qq.com%2Fuser%2Fauth_login%3Fvappid%3D11059694%26vsecret%3Dfdf61a6be0aad57132bc5cdf78ac30145b6cd2c1470b0cfe%26raw%3D1%26type%3Dqq%26appid%3D101483052&which=Login&display=pc&response_type=code&client_id=101483052";
$cookie="Cookie: tvfe_boss_uuid=a924037418398439; vversion_name=8.2.95; video_omgid=; _tc_unionid=eab202c4-b9e8-4fae-a0ca-ea279b9e93d8; pac_uid=0_16b4981848f15; iip=0; _tucao_custom_info=UkdnMjFPUlhqUDZFbnN4a2dvWEpHL3dKcVc4bUhSQW5UbndTYTk5MWttNnhyR09kRmx4T3hjam5CUW9NL1ZBUA%3D%3D--MZvPcbtLW0YtdzPTsSXDaQ%3D%3D; ui=5583F0D1-2B40-425E-8A5F-54A98566877A; _qpsvr_localtk=0.6152303459535391; RK=qyFE4QEgZw; ptcz=728f5ecb83a1b61e38e5d08c4fc80de80703fb46b03c91a69dc144eec3a4eb42; p_uin=".$uin."; pt4_token=".$token."; p_skey=".$pskey."; pt_oauth_token=".$ptoken."; pt_login_type=3";
$data=get_curl($url,$post,$referer,$cookie,$header,$ua);
preg_match('/location:\s+(.*?)\s+/is',$data,$m);
$url=$m[1];
$header=array("Host: access.video.qq.com","cache-control: max-age=0","upgrade-insecure-requests: 1","user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with: mark.via","sec-fetch-site: same-site","sec-fetch-mode: navigate");
$data=datacurl($url,null,$header);
$data=$data["header"];
preg_match_all('/vqq_access_token=(.*?);/',$data,$vqq_access_token);
preg_match_all('/vqq_refresh_token=(.*?);/',$data,$vqq_refresh_token);
preg_match_all('/vqq_appid=(.*?);/',$data,$vqq_appid);
preg_match_all('/vqq_openid=(.*?);/',$data,$vqq_openid);
preg_match_all('/vqq_vuserid=(.*?);/',$data,$vqq_vuserid);
$array=array('code'=>"0",'uin'=>$uin,'vqq_access_token'=>$vqq_access_token[1][0],'vqq_refresh_token'=>$vqq_refresh_token[1][0],'vqq_appid'=>$vqq_appid[1][0],'vqq_openid'=>$vqq_openid[1][0],'vqq_vuserid'=>$vqq_vuserid[1][0]);
print_r(jsonjx($array));


}elseif ($code == 65) {
echo '{"code":1,"uin":"' . $uin . '","state":"二维码已失效，请刷新。"}';
}elseif ($code == 66) {
echo '{"code":2,"uin":"' . $uin . '","state":"二维码未失效。"}';
}elseif ($code == 67) {
echo '{"code":3,"uin":"' . $uin . '","state":"正在验证二维码。"}';
} else {
echo '{"code":6,"uin":"' . $uin . '","state":"' . str_replace('"', '\'', $r[4]) . '"}';
}
}
function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    
    return $msectime;
}
function getqrtoken($qrsig)
{
$len = strlen($qrsig);
$hash = 0;
for ($i = 0; $i < $len; $i++) {
$hash += ($hash << 5 & 2147483647) + ord($qrsig[$i]) & 2147483647;
$hash &= 2147483647;
}
return $hash & 2147483647;
}
function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$httpheader[] = "Accept: application/json";
$httpheader[] = "Accept-Encoding: gzip";
$httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
$httpheader[] = "Connection: keep-alive";
curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
if ($post) {
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
}
if ($header) {
curl_setopt($ch, CURLOPT_HEADER, true);
}
if ($cookie) {
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
}
if ($referer) {
curl_setopt($ch, CURLOPT_REFERER, $referer);
}
if ($ua) {
curl_setopt($ch, CURLOPT_USERAGENT, $ua);
} else {
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Safari/537.36 OppoBrowser/4.9.3");
}
if ($nobaody) {
curl_setopt($ch, CURLOPT_NOBODY, 1);
}
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$ret = curl_exec($ch);
curl_close($ch);
return $ret;
}
function datacurl($url,$data=0,$header_array=0,$referer=0,$time=30,$code=0) {
if($header_array==0) {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
} else {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user());
$header=array_merge($header_array,$header);
}
//print_r($header);
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,$url);
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
if($data) {
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
}
if($referer) {
curl_setopt($curl,CURLOPT_REFERER,$referer);
}
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 3);
//设置等待时间
curl_setopt($curl,CURLOPT_TIMEOUT,$time);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
curl_setopt($curl, CURLOPT_HEADER, 1);
$return=curl_exec($curl);
$code_code=curl_getinfo($curl);
curl_close($curl);
$code_int['exec']=substr($return,$code_code["header_size"]);
$code_int['code']=$code_code["http_code"];
$code_int['content_type']=$code_code["content_type"];
$code_int['header']=substr($return,0,$code_code["header_size"]);
return $code_int;
}

