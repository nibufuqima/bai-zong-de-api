<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$msg=$_GET["type"];
$qrsig=$_GET["qrsig"];
$time=time();
if($_GET["type"]=="1"){
$port="101487368";//腾讯网
//$url='https://ssl.ptlogin2.qq.com/ptqrshow?appid=716027609&e=2&l=M&s=3&d=72&v=4&t=0.'.$time.'&daid=383&pt_3rd_aid='.$port;
$url='https://ssl.ptlogin2.qq.com/ptqrshow?appid=716027609&e=2&l=M&s=3&d=72&v=4&t=0.'.$time.'&daid=383&pt_3rd_aid=100384226';
$header=array("User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36","Referer: https://xui.ptlogin2.qq.com/cgi-bin/xlogin?appid=716027609&daid=383&style=33&theme=2&login_text=%E6%8E%88%E6%9D%83%E5%B9%B6%E7%99%BB%E5%BD%95&hide_title_bar=1&hide_border=1&target=self&s_url=https%3A%2F%2Fgraph.qq.com%2Foauth2.0%2Flogin_jump&pt_3rd_aid=".$port."&pt_feedback_link=https%3A%2F%2Fsupport.qq.com%2Fproducts%2F77942%3FcustomInfo%3Dwww.qq.com.appid".$port);
$data=curl($url,null,$header);
preg_match('/qrsig=(.*?);/',$data['header'],$match);
file_put_contents("img/".$time.".jpg",$data["exec"]);
$data=json_encode(array("code"=>200,"picurl"=>"".ym."/API/qqgn/a/img/".$time.".jpg","qrsig"=>$match[1]));
$data=str_replace("\/",'/',$data);
echo $data;
ignore_user_abort(); //客户端断开时，可以让脚本继续在后台执行
set_time_limit(0);		
fastcgi_finish_request();//先返回上面的内容
time_sleep_until(time()+120);//延迟m秒后执行下面的命令
unlink("img/".$time.".jpg");
}else{
$bdlb=array(
"id.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fid.qq.com%2Findex.html&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=1&',//QQ安全中心
"ti.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fti.qq.com&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=338&',//ti
"qun.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fqun.qq.com%2F&ptqrtoken='.getqrtoken($qrsig).'&ptredirect=1&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-'.time().'0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=73&',//QQ群官网
"qzone.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=10194&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=5&',//QQ空间
"vip.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fvip.qq.com%2Floginsuccess.html&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=18&',//会员官网
"huifu.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fhuifu.qq.com%2Findex.html&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=768&',//群恢复官网
"docs.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fdocs.qq.com%2Ftim%2Fdocs%2Fcomponents%2FBindQQ.html%3Ftype%3Dlogin&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=536&',//腾讯文档
"connect.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fconnect.qq.com%2Flogin_success.html&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=377&',//腾讯互联
"graph.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fgraph.qq.com%2Foauth2.0%2Flogin_jump&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=383&',//腾讯互联
"tenpay.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A%2F%2Fwww.tenpay.com%2Fv2%2Fproxy.html&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=120&',//财付通
"game.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https%3A//minigame.qq.com/other/loginproxy.html%3Frefresh%3D1&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=181&',//腾讯手游
"gamecenter.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=http%3A%2F%2Fgamecenter.qq.com&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=381&',//腾讯游戏中心
"qqshow.qq.com" => 'https://ssl.ptlogin2.qq.com/ptqrlogin?u1=http%3A%2F%2Fimgcache.qq.com%2Fqqshow%2Fv5%2Fpublic%2Fhtml%2Fsystem%2Flogin_transition.html%3Fmyurl%3Dhttps%253A%252F%252Fshow.qq.com%252F%2523u%25253Dpage%2525253Dhome%2525253Frcount%2525253D0&ptqrtoken=' . getqrtoken($_GET["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=20010217&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid=209&'//QQ秀
);
$lx='["id.qq.com","ti.qq.com","qun.qq.com","qzone.qq.com","vip.qq.com","huifu.qq.com","docs.qq.com","connect.qq.com","graph.qq.com","tenpay.com","game.qq.com","gamecenter.qq.com"]';
$json=json_decode($lx,true);
$url1=$bdlb["id.qq.com"];
$data1=qrlogin($url1);
$json1=json_decode($data1,true);
$ldw=ldw($json1["uin"],$json1["skey"],$json1["pskey"]);
if($json1["code"]=="0"){
foreach ($json as $key => $value){
$url=$bdlb[$value];
$data=qrlogin($url);
$json=json_decode($data,true);
$dat[$value]=$json["pskey"];
}
$array=array('code'=>"0",'uin'=>$json1["uin"],'ldw'=>$ldw,'skey'=>$json1["skey"],'gtk'=>GetGTK($json1["skey"]),'bkn'=>GetBkn($json1["skey"]),'pskey'=>$dat);
print_r(jsonjx($array));
}else{
print_r($data1);
}
}

function qrlogin($url)
{
$header=array("Connection: keep-alive","Accept-Language: zh-CN,zh;q=0.8","Accept-Encoding: gzip,deflate,sdch","Accept: */*");
$referer="https://xui.ptlogin2.qq.com/";
$cookie="qrsig=".$_GET["qrsig"]."";
$ua="Mozilla/5.0 (Linux; Android 9; V1901A Build/P00610; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/68.0.3440.91 Mobile Safari/537.36";
$ret = get_curl($url, null, $referer, $cookie, $header, $ua);
if (preg_match("/ptuiCB\\('(.*?)'\\)/", $ret, $arr) && $_GET["qrsig"]) {
$r = explode("','", str_replace("', '", "','", $arr[1]));
if ($r[0] == 0) {
preg_match('/uin=(\\d+)&/', $ret, $uin);
preg_match('/skey=@(.{9});/', $ret, $skey);
preg_match('/superkey=(.*?);/', $ret, $superkey);
$data = get_curl($r[2], 0, 0, 0, 1);
if ($data) {
preg_match("/p_skey=(.*?);/", $data, $pskey);
preg_match("/pt4_token=(.*?);/", $data, $pt4token);
}
if ($pskey) {
$data='{"code":0,"uin":"' . $uin[1] . '","skey":"@' . $skey[1] . '","gtk":"' . getGtk("@" . $skey[1]) . '","pt4token":"' . $pt4token[1] . '","pskey":"' . $pskey[1] . '","superkey":"' . $superkey[1] . '","state":"' . $r[4] . '","name":"' . $r[5] . '"}';
file_put_contents("cookie/".$_GET["type"]."/".$uin[1].".txt",$data);
return $data;
} else {
return '{"code":6,"uin":"' . $uin . '","state":"登录成功，获取相关信息失败！' . $r[2] . '"}';
}
} else {
if ($r[0] == 65) {
return '{"code":1,"uin":"' . $uin . '","state":"二维码已失效，请刷新。"}';
} else {
if ($r[0] == 66) {
return '{"code":2,"uin":"' . $uin . '","state":"二维码未失效。"}';
} else {
if ($r[0] == 67) {
return '{"code":3,"uin":"' . $uin . '","state":"正在验证二维码。"}';
} else {
return '{"code":6,"uin":"' . $uin . '","state":"' . str_replace('"', '\'', $r[4]) . '"}';
}
}
}
}
} else {
return '{"code":6,"state":"初始化中……"}';
}
}
function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}


function jsonjx($data){
$data=json_encode($data);
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $data);
$str=str_replace("\/",'/',$str);
return $str;
}
function getqrtoken($qrsig)
{
$len = strlen($qrsig);
$hash = 0;
for ($i = 0; $i < $len; $i++) {
$hash += ($hash << 5 & 2147483647) + ord($qrsig[$i]) & 2147483647;
$hash &= 2147483647;
}
return $hash & 2147483647;
}
function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$httpheader[] = "Accept: application/json";
$httpheader[] = "Accept-Encoding: gzip";
$httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
$httpheader[] = "Connection: keep-alive";
curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
if ($post) {
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
}
if ($header) {
curl_setopt($ch, CURLOPT_HEADER, true);
}
if ($cookie) {
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
}
if ($referer) {
curl_setopt($ch, CURLOPT_REFERER, $referer);
}
if ($ua) {
curl_setopt($ch, CURLOPT_USERAGENT, $ua);
} else {
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Safari/537.36 OppoBrowser/4.9.3");
}
if ($nobaody) {
curl_setopt($ch, CURLOPT_NOBODY, 1);
}
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$ret = curl_exec($ch);
curl_close($ch);
return $ret;
}
function getip_user() {
if(empty($_SERVER["HTTP_CLIENT_IP"]) == false) {
$cip = $_SERVER["HTTP_CLIENT_IP"];
} else if(empty($_SERVER["HTTP_X_FORWARDED_FOR"]) == false) {
$cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} else if(empty($_SERVER["REMOTE_ADDR"]) == false) {
$cip = $_SERVER["REMOTE_ADDR"];
} else {
$cip = "";
}
preg_match("/[\d\.]{7,15}/", $cip, $cips);
$cip = isset($cips[0]) ? $cips[0] : "";
unset($cips);
return $cip;
}

function curl($url,$data=0,$header_array=0,$referer=0,$time=30,$code=0) {
if($header_array==0) {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
} else {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user());
$header=array_merge($header_array,$header);
}
//print_r($header);
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,$url);
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
if($data) {
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
}
if($referer) {
curl_setopt($curl,CURLOPT_REFERER,$referer);
}
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 3);
//设置等待时间
curl_setopt($curl,CURLOPT_TIMEOUT,$time);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
curl_setopt($curl, CURLOPT_HEADER, 1);
$return=curl_exec($curl);
$code_code=curl_getinfo($curl);
curl_close($curl);
$code_int['exec']=substr($return,$code_code["header_size"]);
$code_int['code']=$code_code["http_code"];
$code_int['content_type']=$code_code["content_type"];
$code_int['header']=substr($return,0,$code_code["header_size"]);
return $code_int;
}
function GetBkn($skey) {
	$hash = 5381;
	for ($i = 0, $len = strlen($skey); $i < $len; ++$i) {
		$hash +=($hash << 5) + charCodeAt($skey, $i);
	}
	return $hash & 2147483647;
}
function GetGTK($skey) {
	$len = strlen($skey);
	$hash = 5381;
	for ($i = 0; $i < $len; $i++) {
		$hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
		$hash &= 2147483647;
	}
	return $hash & 2147483647;
}
function charCodeAt($str, $index) {
	$char = mb_substr($str, $index, 1, 'UTF-8');
	$value = null;
	if (mb_check_encoding($char, 'UTF-8')) {
		$ret = mb_convert_encoding($char, 'UTF-32BE', 'UTF-8');
		$value = hexdec(bin2hex($ret));
	}
	return $value;
}

function ldw($uin,$skey,$pskey){
$url='https://id.qq.com/cgi-bin/get_base_key?r=0.5208226027853338';
$header=array("User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","Host: id.qq.com","Referer: https://id.qq.com/level/mylevel.html?ver=10043&","Cookie: uin=o".$uin.";skey=".$skey.";p_skey=".$pskey.";p_uin=o".$uin.";");
$data=getcurl($url,null,$header);
preg_match('/ldw=(.*?);/',$data['header'],$data);
return ($data[1]);
}
function getcurl($url,$data=0,$header_array=0,$referer=0,$time=30,$code=0) {
if($header_array==0) {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
} else {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user());
$header=array_merge($header_array,$header);
}
//print_r($header);
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,$url);
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
if($data) {
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
}
if($referer) {
curl_setopt($curl,CURLOPT_REFERER,$referer);
}
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 3);
//设置等待时间
curl_setopt($curl,CURLOPT_TIMEOUT,$time);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
curl_setopt($curl, CURLOPT_HEADER, 1);
$return=curl_exec($curl);
$code_code=curl_getinfo($curl);
curl_close($curl);
$code_int['exec']=substr($return,$code_code["header_size"]);
$code_int['code']=$code_code["http_code"];
$code_int['content_type']=$code_code["content_type"];
$code_int['header']=substr($return,0,$code_code["header_size"]);
return $code_int;
}