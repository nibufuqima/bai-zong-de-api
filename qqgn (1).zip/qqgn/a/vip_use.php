<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$lx=$_REQUEST["lx"]?:"气泡";
$m=$_REQUEST["max"]?:"15";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$id=array(
"进群特效" => "26",
"个性赞" => "20",
"个签" => "9",
"头像" => "23",
"背景" => "8",
"来电" => "17",
"名片" => "15",
"挂件" => "4",
"字体" => "5",
"主题" => "3",
"气泡" => "2"
);
$id=$id[$lx];
$url="https://zb.vip.qq.com/srf/QC_UniBusinessUserInfoServer_UniBusinessUserInfoObj/UniBusiGetHistoryUserInfo?srfId=13237&g_tk=".getGTK($skey);
$header=array("User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Cookie: p_uin=o".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ","Referer: https://zb.vip.qq.com/v2/pages/home?_wv=5123&_wwv=128&ADTAG=mobileqq.drawer&trace_detail=base64-eyJhcHBpZCI6Im91dHNpZGUiLCJwYWdlX2lkIjoiMyJ9","Host: zb.vip.qq.com","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: ggzi","Content-Type: application/json; charset=UTF-8");
$data='{"appid":'.$id.',"stLogin":{"iKeyType":1,"iOpplat":2,"lUin":'.$uin.',"sClientIp":"","sClientVer":"8.8.80","sSKey":"string"},"pageSize":15,"startIndex":0,"relateUIDInfo":{}}';
$json=get_result($url,$data,$header);
$data=json_decode($json,true);
foreach($data["data"]["stRsp"]["uniBusiHistoryItemList"] as $k=>$v){
if($k==$m){
        break; 
    }
echo ($k+1).":".$v["itemname"]."(".$v["itemid"].")\n";
}
