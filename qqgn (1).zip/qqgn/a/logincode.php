<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$type=$_REQUEST["type"];
$qrsig=$_REQUEST["qrsig"];
if(!$type){
print_r('{"data":接口文档:".ym."/API/qqgn/a/logincode.txt""}');
exit();
}
$time=time();
$lx='["id.qq.com","ti.qq.com","qun.qq.com","qzone.qq.com","vip.qq.com","huifu.qq.com","docs.qq.com","connect.qq.com","graph.qq.com","tenpay.com","game.qq.com","yundong.qq.com","gamecenter.qq.com"]';
$lx=json_decode($lx,true)[$type-1];
$data=array(
'id.qq.com'=>array('a'=>"https%3A%2F%2Fid.qq.com%2Findex.html",'b'=>"1"),
'ti.qq.com'=>array('a'=>"https%3A%2F%2Fti.qq.com",'b'=>"338"),
'qun.qq.com'=>array('a'=>"https%3A%2F%2Fqun.qq.com%2F",'b'=>"73"),
'qzone.qq.com'=>array('a'=>"https%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone",'b'=>"5"),
'vip.qq.com'=>array('a'=>"https%3A%2F%2Fvip.qq.com%2Floginsuccess.html",'b'=>"18"),
'huifu.qq.com'=>array('a'=>"https%3A%2F%2Fhuifu.qq.com%2Findex.html",'b'=>"768"),
'docs.qq.com'=>array('a'=>"https%3A%2F%2Fdocs.qq.com%2Ftim%2Fdocs%2Fcomponents%2FBindQQ.html%3Ftype%3Dlogin",'b'=>"536"),
'connect.qq.com'=>array('a'=>"https%3A%2F%2Fconnect.qq.com%2Flogin_success.html",'b'=>"377"),
'graph.qq.com'=>array('a'=>"https%3A%2F%2Fgraph.qq.com%2Foauth2.0%2Flogin_jump",'b'=>"383"),
'tenpay.com'=>array('a'=>"https%3A%2F%2Fwww.tenpay.com%2Fv2%2Fproxy.html",'b'=>"120"),
'game.qq.com'=>array('a'=>"https%3A//minigame.qq.com/other/loginproxy.html%3Frefresh%3D1",'b'=>"181"),
'gamecenter.qq.com'=>array('a'=>"https%3A%2F%2Fyouxi.gamecenter.qq.com%2Fm%2Fact%2Fd8dc1c4aedf43b84_10064418.html%3Fifr%3D1%26ifr%3D1&",'b'=>"323"),
'yundong.qq.com'=>array('a'=>"https%3A%2F%2Fyundong.qq.com%2F%2Fv2%2Fhomepage%2Findex",'b'=>"539"),
'accounts.qq.com'=>array('a'=>"https%3A%2F%2Faccounts.qq.com%2Fhomepage%23%2F",'b'=>"761"),
);
$data=$data[$lx];
if($qrsig==null){
qrsig($data["b"]);
}else{
qrlogin($data["a"],$data["b"]);
}
function qrlogin($url,$daid)
{
$url='https://ssl.ptlogin2.qq.com/ptqrlogin?u1='.$url.'&ptqrtoken=' . getqrtoken($_REQUEST["qrsig"]) . '&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=0-0-' . time() . '0000&js_ver=21073010&js_type=1&login_,sig=&pt_uistyle=40&aid=716027609&daid='.$daid.'&pt_3rd_aid=100384226';
$header=array("Connection: keep-alive","Accept-Language: zh-CN,zh;q=0.8","Accept-Encoding: gzip,deflate,sdch","Accept: */*");
$referer="https://xui.ptlogin2.qq.com/";
$cookie="qrsig=".$_REQUEST["qrsig"]."";
$ua="Mozilla/5.0 (Linux; Android 9; V1901A Build/P00610; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/68.0.3440.91 Mobile Safari/537.36";
$ret = get_curl($url, null, $referer, $cookie, $header, $ua);
//die($ret);
if (preg_match("/ptuiCB\\('(.*?)'\\)/", $ret, $arr) && $_REQUEST["qrsig"]) {
$r = explode("','", str_replace("', '", "','", $arr[1]));
if ($r[0] == 0) {
preg_match('/uin=(\\d+)&/', $ret, $uin);
preg_match('/skey=@(.{9});/', $ret, $skey);
preg_match('/superkey=(.*?);/', $ret, $superkey);
$data = get_curl($r[2], 0, 0, 0, 1);
if ($data) {
preg_match("/p_skey=(.*?);/", $data, $pskey);
preg_match("/pt4_token=(.*?);/", $data, $pt4token);
}
if ($pskey) {
$data='{"code":0,"uin":"' . $uin[1] . '","skey":"@' . $skey[1] . '","gtk":"' . getGtk("@" . $skey[1]) . '","pt4token":"' . $pt4token[1] . '","pskey":"' . $pskey[1] . '","superkey":"' . $superkey[1] . '","state":"' . $r[4] . '","name":"' . $r[5] . '"}';
//file_put_contents("cookie/".$_GET["type"]."/".$uin[1].".txt",$data);
die($data);
} else {
die('{"code":6,"uin":"' . $uin . '","state":"登录成功，获取相关信息失败！' . $r[2] . '"}');
}
} else {
if ($r[0] == 65) {
die('{"code":1,"uin":"' . $uin . '","state":"二维码已失效，请刷新。"}');
} else {
if ($r[0] == 66) {
die('{"code":2,"uin":"' . $uin . '","state":"二维码未失效。"}');
} else {
if ($r[0] == 67) {
die('{"code":3,"uin":"' . $uin . '","state":"正在验证二维码。"}');
} else {
die('{"code":6,"uin":"' . $uin . '","state":"' . str_replace('"', '\'', $r[4]) . '"}');
}
}
}
}
} else {
die('{"code":6,"state":"初始化中……"}');
}
}
function qrsig($daid){
$time=time();
$url='https://ssl.ptlogin2.qq.com/ptqrshow?appid=716027609&e=2&l=M&s=4&d=72&v=4&t=0.5409099.'.$time.'&daid='.$daid.'&pt_3rd_aid=100384226';
$header=array("User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36","Referer: https://xui.ptlogin2.qq.com/cgi-bin/xlogin?proxy_url=https%3A//qzs.qq.com/qzone/v6/portal/proxy.html&daid=&&hide_title_bar=1&low_login=0&qlogin_auto_login=1&no_verifyimg=1&link_target=blank&appid=549000912&style=22&target=self&s_url=https%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&pt_no_auth=0");
$data=curl($url,null,$header);
preg_match('/qrsig=(.*?);/',$data['header'],$match);
file_put_contents("img/".$time.".jpg",$data["exec"]);
$data=json_encode(array("code"=>200,"picurl"=>"".ym."/API/qqgn/a/img/".$time.".jpg","qrsig"=>$match[1]));
$data=str_replace("\/",'/',$data);
die($data);
fastcgi_finish_request();//先返回上面的内容
time_sleep_until(time()+120);//延迟m秒后执行下面的命令
unlink("img/".$time.".jpg");

}
function getqrtoken($qrsig)
{
$len = strlen($qrsig);
$hash = 0;
for ($i = 0; $i < $len; $i++) {
$hash += ($hash << 5 & 2147483647) + ord($qrsig[$i]) & 2147483647;
$hash &= 2147483647;
}
return $hash & 2147483647;
}

function get_curl($url, $post = 0, $referer = 0, $cookie = 0, $header = 0, $ua = 0, $nobaody = 0)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
$httpheader[] = "Accept: application/json";
$httpheader[] = "Accept-Encoding: gzip";
$httpheader[] = "Accept-Language: zh-CN,zh;q=0.8";
$httpheader[] = "Connection: keep-alive";
curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
if ($post) {
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
}
if ($header) {
curl_setopt($ch, CURLOPT_HEADER, true);
}
if ($cookie) {
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
}
if ($referer) {
curl_setopt($ch, CURLOPT_REFERER, $referer);
}
if ($ua) {
curl_setopt($ch, CURLOPT_USERAGENT, $ua);
} else {
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Safari/537.36 OppoBrowser/4.9.3");
}
if ($nobaody) {
curl_setopt($ch, CURLOPT_NOBODY, 1);
}
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$ret = curl_exec($ch);
curl_close($ch);
return $ret;
}
function getip_user() {
if(empty($_SERVER["HTTP_CLIENT_IP"]) == false) {
$cip = $_SERVER["HTTP_CLIENT_IP"];
} else if(empty($_SERVER["HTTP_X_FORWARDED_FOR"]) == false) {
$cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} else if(empty($_SERVER["REMOTE_ADDR"]) == false) {
$cip = $_SERVER["REMOTE_ADDR"];
} else {
$cip = "";
}
preg_match("/[\d\.]{7,15}/", $cip, $cips);
$cip = isset($cips[0]) ? $cips[0] : "";
unset($cips);
return $cip;
}

function curl($url,$data=0,$header_array=0,$referer=0,$time=30,$code=0) {
if($header_array==0) {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
} else {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user());
$header=array_merge($header_array,$header);
}
//print_r($header);
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,$url);
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
if($data) {
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
}
if($referer) {
curl_setopt($curl,CURLOPT_REFERER,$referer);
}
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 3);
//设置等待时间
curl_setopt($curl,CURLOPT_TIMEOUT,$time);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
curl_setopt($curl, CURLOPT_HEADER, 1);
$return=curl_exec($curl);
$code_code=curl_getinfo($curl);
curl_close($curl);
$code_int['exec']=substr($return,$code_code["header_size"]);
$code_int['code']=$code_code["http_code"];
$code_int['content_type']=$code_code["content_type"];
$code_int['header']=substr($return,0,$code_code["header_size"]);
return $code_int;
}
function GetBkn($skey) {
	$hash = 5381;
	for ($i = 0, $len = strlen($skey); $i < $len; ++$i) {
		$hash +=($hash << 5) + charCodeAt($skey, $i);
	}
	return $hash & 2147483647;
}
function GetGTK($skey) {
	$len = strlen($skey);
	$hash = 5381;
	for ($i = 0; $i < $len; $i++) {
		$hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
		$hash &= 2147483647;
	}
	return $hash & 2147483647;
}