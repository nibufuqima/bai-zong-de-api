<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$qq=$_REQUEST["qq"]?:$uin;
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$qq){
print_r("参数不完整!需要参数:uin，skey，pskey，qq");
exit();
}
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: h5.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/taotao.qq.com/cgi-bin/emotion_cgi_timershuoshuolist_v6?uin=".$qq."&ftype=0&sort=0&pos=0&num=20&replynum=100&g_tk=".getGTK($pskey)."&callback=_preloadCallback&code_version=1&format=jsonp&need_private_comment=1&g_tk=".getGTK($pskey);
$data=curl($url,null,$header);
$data=str_replace('_preloadCallback(','',$data);
$data=str_replace(');','',$data);
$json=json_decode($data,true);
$code=$json["code"];
if($code=="-3000"){
print_r("您还没有登陆,请先登陆");
}
if($code=="0"){
if(empty($json["posts"])){
die('定时说说列表空空!');
}else{
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_del_timershuoshuo_v6?&g_tk=".getGTK($pskey);
foreach ($json["posts"] as $key => $value){
$data="hostuin=".$uin."&tid=".$value["tid"]."&time=".$value["created_time"]."t1_source=1&code_version=1&format=fs&qzreferrer=https://user.qzone.qq.com/".$uin."/infocenter?via=toolbar";
$data=curl($url,$data,$header);
}
print_r("清空定时说说成功！");
}}