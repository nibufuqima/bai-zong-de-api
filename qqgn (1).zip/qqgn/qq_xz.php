<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$qq=$_REQUEST["qq"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$max=$_REQUEST["max"]?:"10";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$lx=$_REQUEST["lx"];
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.5_1858_YYB_D A_8080500 QQ/8.8.5.5570 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1046369 InMagicWin/0 StudyMode/0","Referer: https://ti.qq.com/qqmedal2/rank.html?_wv=1&_bid=2450&_wwv=4&_nav_alpha=0&_nav_txtclr=ffffff&_nav_titleclr=ffffff&_nav_anim=true&suid=&from_web=2");
$url="https://ti.qq.com/mqqbase/cgi/medalwall/ranking?";
$data=get_result($url,null,$header);
$json=json_decode($data,true);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
if($json["errCode"]=="100000"){
print_r("请求错误！");
exit();

}
foreach ($json["data"]["rankings"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["nickname"]."-".$value["uin"]."\n";
echo "原力值:".$value["totalPoint"]."\n";
}
}

