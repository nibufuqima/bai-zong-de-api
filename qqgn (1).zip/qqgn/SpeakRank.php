<?php
header("Content-Type:text/html;charset=utf-8");//输出头
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$Dat=$_REQUEST["data"];
$max=$_REQUEST["max"]?:"10";
$group=$_REQUEST["group"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$type=$_REQUEST["type"]?:"0";
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qun.qq.com/m/qun/activedata/speaking.html?gc=".$group."&time=".$type."&_wv=3&&_wwv=128";
$header=array("Host: qun.qq.com","upgrade-insecure-requests: 1","user-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/045909 Mobile Safari/537.36 V1_AND_SQ_8.8.50_2324_YYB_D A_8085000 QQ/8.8.50.6735 NetType/4G WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0","accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,image/sharpp,image/apng,image/tpg,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","sec-fetch-site: none","sec-fetch-mode: navigate","sec-fetch-user: ?1","sec-fetch-dest: document","accept-encoding: gzip, deflate, br","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","q-ua2: QV=3&PL=ADR&PR=QQ&PP=com.tencent.mobileqq&PPVN=8.8.50&TBSVC=44126&CO=BK&COVC=045909&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO= RedmiK30 &RL=1080*2261&OS=11&API=30","q-guid: 21d8b77b9a1747d1f878318113b788cb","q-qimei: fa96e4eb0f6fad3937877892100019215205","qimei36: b53787c1c4a31f0f9d4fd4ea10001c315206","q-header-ctrl: 7","q-auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data=null;
$return=get_result($url,$data,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$url=getSubstr($return,$left,$right);
$json=json_decode($url,true);
if($Dat=="json"){
print_r($url);
}else{
$data=$json["speakingList"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["nickname"]."-".$value["uin"]."\n";
print_r(urldecode($value["active"]."%E5%A4%A9%E5%8F%91%E8%A8%80:".$value["msgCount"]."%E6%AC%A1\n"));
}}
