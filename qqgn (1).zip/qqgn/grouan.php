<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_GET['uin'];
$skey=$_GET['skey'];
$pskey=$_GET['pskey'];
$data=$_GET['lx'];
$Dat=$_REQUEST["data"];
$group=$_GET['qh'];
if(!$uin || !$skey || !$group){
print_r("参数不完整!需要参数:uin，skey，qh");
exit();
}
$bkn=getGTK($skey);
$header=array("Cookie: p_uin=o".$uin."; p_skey=".$pskey."; uin=o".$uin."; skey=".$skey."; ");
$data=curl("http://qinfo.clt.qq.com/cgi-bin/qun_info/get_group_shutup","bkn=".$bkn."&gc=".$group."&src=qinfo_v3",$header);
$data=str_replace("&nbsp;",'',$data);
$json=json_decode($data,true);
$ec=$json["ec"];
if($Dat=="json"){
print_r($data);
}else{
if($ec=='7')
{
echo "你不是群管理员!";
}
else
if($ec=='4')
{
echo "COOKIE已失效!";
}
else
if($ec=='0'){
if($json["shutup_list"]==null){
echo "无人被禁言ε(*･ω･)_/ﾟ:･☆";
exit();
}
foreach ($json["shutup_list"] as $key => $value){
echo ($key+1).":".$value["nick"]."-(".Sec2Time($value["t"]).")\n";
}
}
}
function Sec2Time($time){
    if(is_numeric($time)){
    $value = array(
      "years" => 0, "days" => 0, "hours" => 0,
      "minutes" => 0, "seconds" => 0,
    );
    if($time >= 31556926){
      $value["years"] = floor($time/31556926);
      $time = ($time%31556926);
    }
    if($time >= 86400){
      $value["days"] = floor($time/86400);
      $time = ($time%86400);
    }
    if($time >= 3600){
      $value["hours"] = floor($time/3600);
      $time = ($time%3600);
    }
    if($time >= 60){
      $value["minutes"] = floor($time/60);
      $time = ($time%60);
    }
    $value["seconds"] = floor($time);
    //return (array) $value;
    if($value["years"]!="0"){
    $t=$value["years"] ."年". $value["days"] ."天"." ". $value["hours"] ."小时". $value["minutes"] ."分".$value["seconds"]."秒";
    }elseif($value["days"]!="0"&&$value["years"]=="0"){
        $t=$value["days"] ."天"." ". $value["hours"] ."小时". $value["minutes"] ."分".$value["seconds"]."秒";
    }elseif($value["hours"]!="0"&&$value["days"]=="0"&&$value["years"]=="0"){
        $t=$value["hours"] ."小时". $value["minutes"] ."分".$value["seconds"]."秒";
    }elseif($value["minutes"]!="0"&&$value["hours"]=="0"&&$value["days"]=="0"&&$value["years"]=="0"){
        $t=$value["minutes"] ."分".$value["seconds"]."秒";
    }elseif($value["seconds"]!="0"&&$value["minutes"]=="0"&&$value["hours"]=="0"&&$value["days"]=="0"&&$value["years"]=="0"){
        $t=$value["seconds"]."秒";
    }
    Return $t;
    
     }else{
    return (bool) FALSE;
    }
 }