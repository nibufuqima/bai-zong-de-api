<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$switch=$_REQUEST['switch'];
$type=$_REQUEST['type'];
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://web.qun.qq.com/qunrobot/proxy/domain/app.qun.qq.com/cgi-bin/guanjia_robot/chat_manage/set_switch?bkn=".getGTK($skey);
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Host: web.qun.qq.com","accept: application/json, text/plain, */*","qname-service: 976321:131072","qname-space: Production","user-agent: Mozilla/5.0 (Linux; Android 12; Redmi K30 Build/SKQ1.210908.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/046029 Mobile Safari/537.36 V1_AND_SQ_8.8.95_2944_YYB_D A_8089500 QQ/8.8.95.8265 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537122615","content-type: application/x-www-form-urlencoded","origin: https://web.qun.qq.com","sec-fetch-site: same-origin","sec-fetch-mode: cors","sec-fetch-dest: empty","accept-encoding: gzip, deflate, br","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$data="word_type=".$type."&switch_status=".$switch."&group_code=".$group."&bkn=".getGTK($skey);
$return=curl($url,$data,$header);
print_r($return);

//1链接，2二维码，3红包
