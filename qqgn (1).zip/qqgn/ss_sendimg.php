<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$msg=$_REQUEST["msg"]?:"666";
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$url=$_REQUEST["url"];
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Host: up.qzone.qq.com","Connection: keep-alive","User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","Content-Type: application/x-www-form-urlencoded;charset=UTF-8","Accept: */*","Origin: https://user.qzone.qq.com","X-Requested-With: mark.via","Sec-Fetch-Site: same-site","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Referer: https://user.qzone.qq.com/","Accept-Encoding: gzip, deflate","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$mz="1.png";
saveImage($url, $mz);
$base64=urlencode(base64_encode(file_get_contents($mz)));
$data="filename=filename&uin=".$uin."&skey=".$skey."&zzpaneluin=".$uin."&zzpanelkey=&p_uin=".$uin."&p_skey=".$pskey."&qzonetoken=&uploadtype=1&albumtype=7&exttype=0&refer=shuoshuo&output_type=jsonhtml&charset=utf-8&output_charset=utf-8&upload_hd=1&hd_width=2048&hd_height=10000&hd_quality=96&backUrls=http%3A%2F%2Fupbak.photo.qzone.qq.com%2Fcgi-bin%2Fupload%2Fcgi_upload_image%2Chttp%3A%2F%2F119.147.64.75%2Fcgi-bin%2Fupload%2Fcgi_upload_image&url=https%3A%2F%2Fup.qzone.qq.com%2Fcgi-bin%2Fupload%2Fcgi_upload_image%3Fg_tk%3D".getGTK($pskey)."&base64=1&jsonhtml_callback=callback&picfile=".$base64."&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fmain";
$url="https://up.qzone.qq.com/cgi-bin/upload/cgi_upload_image?g_tk=".getGTK($pskey)."&&g_tk=".getGTK($pskey);
$data=curl($url,$data,$header);
$data=getSubstr($data,'frameElement.callback(',');');
$json=json_decode($data,true);
preg_match_all('/&bo=(.*?)!/',$json["data"]["pre"],$bo);
$data="syn_tweet_verson=1&paramstr=1&pic_template=&richtype=1&richval=%2C".$json["data"]["albumid"]."%2C".$json["data"]["lloc"]."%2C".$json["data"]["sloc"]."%2C17%2C".$json["data"]["height"]."%2C".$json["data"]["width"]."%2C%2C".$json["data"]["height"]."%2C".$json["data"]["width"]."&special_url=&subrichtype=1&pic_bo=".$bo[1][0]."!%09".$bo[1][0]."!&con=".$msg."&feedversion=1&ver=1&ugc_right=1&to_sign=0&hostuin=".$uin."&code_version=1&format=fs&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fmain";
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_publish_v6?&g_tk=".getGTK($pskey);
$data=curl($url,$data,$header);
$data=getSubstr($data,'frameElement.callback(',');');
//$json=json_decode($data,true);
print_r($data);
function saveImage($path, $image_name) {
    $ch = curl_init ($path);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);
    $img = curl_exec ($ch);
    curl_close ($ch);
//$image_name就是要保存到什么路径,默认只写文件名的话保存到根目录
    $fp = fopen($image_name,'w');//保存的文件名称用的是链接里面的名称
    fwrite($fp, $img);
    fclose($fp);
}