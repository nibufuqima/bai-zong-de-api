<?php
header("Content-type: text/html; charset=utf-8");
//error_reporting(0);
function json($code="1000",$name,$msg,$array=array()) {
	if($_REQUEST['json']=="text") {
	} else {
		header('Content-type: application/json');
		if($name) {
			$json_one=array(
													'code'=>$code,
													$name=>$msg,
													);
		} else {
			$json_one=array(
													'code'=>$code,
													);
		}
		$json_Two=array_merge($json_one,$array);
		return stripslashes(json_encode($json_Two,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
	}
}
function curl($url,$data=0,$header_array=0,$referer=0,$time=30,$code=0) {
	if($header_array==0) {
		$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
	} else {
		$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
		$header=array_merge($header_array,$header);
	}
//print_r($header);
	$curl=curl_init();
	curl_setopt($curl,CURLOPT_URL,$url);
	curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
	if($data) {
		curl_setopt($curl,CURLOPT_POST,1);
		curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
	}
	if($referer) {
		curl_setopt($curl,CURLOPT_REFERER,$referer);
	}
	curl_setopt($curl,CURLOPT_TIMEOUT,$time);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
if($code) {
		curl_setopt($curl, CURLOPT_HEADER, 1);
		$return=curl_exec($curl);
		$code_code=curl_getinfo($curl);
		curl_close($curl);
		$code_int['exec']=substr($return,$code_code["header_size"]);
		$code_int['code']=$code_code["http_code"];
		$code_int['content_type']=$code_code["content_type"];
		$code_int['header']=substr($return,0,$code_code["header_size"]);
		return $code_int;
	} else {
		$return=curl_exec($curl);
		curl_close($curl);
		return $return;
	}
}
function ip() {
	$ip_long = array(
					array('607649792', '608174079'),
					array('1038614528', '1039007743'),
					array('1783627776', '1784676351'),
					array('2035023872', '2035154943'),
					array('2078801920', '2079064063'),
					array('-1950089216', '-1948778497'),
					array('-1425539072', '-1425014785'),
					array('-1236271104', '-1235419137'),
					array('-770113536', '-768606209'),
					array('-569376768', '-564133889'),
					);
	$rand_key=mt_rand(0,9);
	return $ip=long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
}
function Get_BKN($skey) {
	$len=strlen($skey);
	$hash=5381;
	for ($i=0;$i<$len;$i++) {
		$hash+=((($hash<<5) & 0x7fffffff)+ord($skey[$i])) & 0x7fffffff;
		$hash&=0x7fffffff;
	}
	return $hash & 0x7fffffff;
}
function getBkn($skey) {
	$hash = 5381;
	for ($i = 0, $len = strlen($skey); $i < $len; ++$i) {
		$hash +=($hash << 5) + charCodeAt($skey, $i);
	}
	return $hash & 2147483647;
}
	function getGTK($skey){
        $len = strlen($skey);
        $hash = 5381;
        for ($i = 0; $i < $len; $i++) {
            $hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
            $hash &= 2147483647;
        }
        return $hash & 2147483647;
    }
function charCodeAt($str, $index) {
	$char = mb_substr($str, $index, 1, 'UTF-8');
	$value = null;
	if (mb_check_encoding($char, 'UTF-8')) {
		$ret = mb_convert_encoding($char, 'UTF-32BE', 'UTF-8');
		$value = hexdec(bin2hex($ret));
	}
	return $value;
}
function scanning_port($ip,$port,$timeout=0.1) {
	$result=@fsockopen($ip,$port,$errno,$errstr,$timeout);
	if($result) {
		fclose($result);
		return true;
	}
}
function appid($key) {
	$md5_url=md5($key);
	$md5_data1=substr($md5_url,10,-21);
	$md5_data2=substr($md5_url,30,-1);
	$md5_data3=substr($md5_url,20,-11);
	$md5_data4=substr($md5_url,7,-24);
	$md5_data5=substr($md5_url,24,-7);
	$md5_data0=strtoupper($md5_data1.$md5_data2.$md5_data3.$md5_data4.$md5_data5);
	return $md5_data0;
}
function host($url) {
	$url = strtolower($url);
	$hosts = parse_url($url);
	$host = $hosts['host'];
	$data = explode('.', $host);
	$n = count($data);
	$preg = '/[\w].+\.(com|net|org|gov|edu)\.cn$/';
	if(($n > 2) && preg_match($preg,$host)) {
		$host = $data[$n-3].'.'.$data[$n-2].'.'.$data[$n-1];
	} else {
		$host = $data[$n-2].'.'.$data[$n-1];
	}
	return $host;
}
function url($url) {
	$url=parse_url($url);
	if($url["port"]) {
		if($url["host"]) {
			$url=$url["host"].":".$url["port"];
		} else {
			$url=$url["path"].":".$url["port"];
		}
	} else {
		if($url["host"]) {
			$url=$url["host"];
		} else {
			$url=$url["path"];
		}
	}
	return $url;
}
function getip() {
	$unknown = 'unknown';
	if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])&&$_SERVER['HTTP_X_FORWARDED_FOR']&&strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'],$unknown)) {
		$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
	} else if(isset($_SERVER['REMOTE_ADDR'])&&$_SERVER['REMOTE_ADDR']&&strcasecmp($_SERVER['REMOTE_ADDR'],$unknown)) {
		$ip=$_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}
function GTK($skey) {
	$len = strlen($skey);
	$hash = 5381;
	for ($i = 0; $i < $len; $i++) {
		$hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
		$hash &= 2147483647;
	}
	return $hash & 2147483647;
}
function shorturl($input) {
	$base32 = array (
				'a','A','b','B', 'c','C', 'd','D', 'e','E', 'f','F', 'g','G', 'h','H',
				'i','I', 'j','J', 'k','K', 'l','L', 'm','M', 'n','N', 'o','O', 'p','P',
				'q','Q', 'r','R', 's','S', 't','T', 'u','U', 'v','V', 'w','W', 'x','X',
				'y','Y', 'z','Z', '0', '1', '2', '3', '4', '5','6','7','8','9',
				);
	$hex = md5($input);
	$hexLen = strlen($hex);
	$subHexLen = $hexLen / 8;
	$output = array();
	for ($i = 0; $i < $subHexLen; $i++) {
		$subHex = substr ($hex, $i * 8, 8);
		$int = 0x3FFFFFFF & (1 * ('0x'.$subHex));
		$out = '';
		for ($j = 0; $j < 6; $j++) {
			$val = 0x0000001F & $int;
			$out .= $base32[$val];
			$int = $int >> 5;
		}
		$output[] = $out;
	}
	return $output;
}
function replace_unicode_escape_sequence($match) {
	return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}
function tongji() {
curl("http://47.101.183.91/tongji.php?type=all&ip=".getip_user());
	$route="./data/file/rubbish/tongji_".date("Y-m-d").".txt";
	if(!file_exists($route)) {
		file_put_contents($route,1);
	} else {
		$tongji=file_get_contents($route);
		if($tongji) {
			file_put_contents($route,$tongji+1);
		}
	}
}
function getip_user() {
	if(empty($_SERVER["HTTP_CLIENT_IP"]) == false) {
		$cip = $_SERVER["HTTP_CLIENT_IP"];
	} else if(empty($_SERVER["HTTP_X_FORWARDED_FOR"]) == false) {
		$cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
	} else if(empty($_SERVER["REMOTE_ADDR"]) == false) {
		$cip = $_SERVER["REMOTE_ADDR"];
	} else {
		$cip = "";
	}
	preg_match("/[\d\.]{7,15}/", $cip, $cips);
	$cip = isset($cips[0]) ? $cips[0] : "";
	unset($cips);
	return $cip;
}
function isMobile() {
	// 如果bai有HTTP_X_WAP_PROFILE则一定du是移动设备
	if (isset ($_SERVER['HTTP_X_WAP_PROFILE'])) {
		return true;
	}
	// 如果via信息含有wap则一定是移动设备,部分服务商会屏蔽该信息
	if (isset ($_SERVER['HTTP_VIA'])) {
		// 找不到为flase,否则为true
		return stristr($_SERVER['HTTP_VIA'], "wap") ? true : false;
	}
	// 脑残法，判断手机发送的客户端标志,兼容性有待提高
	if (isset ($_SERVER['HTTP_USER_AGENT'])) {
		$clientkeywords = array ('nokia',
				'sony',
				'ericsson',
				'mot',
				'samsung',
				'htc',
				'sgh',
				'lg',
				'sharp',
				'sie-',
				'philips',
				'panasonic',
				'alcatel',
				'lenovo',
				'iphone',
				'ipod',
				'blackberry',
				'meizu',
				'android',
				'netfront',
				'symbian',
				'ucweb',
				'windowsce',
				'palm',
				'operamini',
				'operamobi',
				'openwave',
				'nexusone',
				'cldc',
				'midp',
				'wap',
				'mobile'
				);
		// 从HTTP_USER_AGENT中查找手机浏览器的关键字
		if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))) {
			return true;
		}
	}
	// 协议法，因为有可能不准确，放到最后判断
	if (isset ($_SERVER['HTTP_ACCEPT'])) {
		// 如果只支持wml并且不支持html那一定是移动设备
		// 如果支持wml和html但是wml在html之前则是移动设备
		if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'textml') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'textml')))) {
			return true;
		}
	}
	return false;
}

function DiffDate($date1, $date2) { 
    $str = "";
    $datetime1 = new \DateTime($date1);
    $datetime2 = new \DateTime($date2);
    $interval = $datetime1->diff($datetime2);
    $y = $interval->format('%y');
    $m = $interval->format('%m');
    $d = $interval->format('%d');

    if ($y > 0) {
        $str .= $y . '年';
    }
    if ($m > 0) {
        $str .= $m . '个月';
    }
    if ($d >= 0) {
        $str .= $d . '天';
    }
    return $str;
}

function strToHex($str) {
	$hex="";
	for ($i=0;$i<strlen($str);$i++)
	$hex.=dechex(ord($str[$i]));
	$hex=strtoupper($hex);
	return $hex;
}
function hexToStr($hex) {
	$str="";
	for ($i=0;$i<strlen($hex)-1;$i+=2)
	$str.=chr(hexdec($hex[$i].$hex[$i+1]));
	return $str;
}

function hex2rgb($hexColor){
 $color=str_replace('#','',$hexColor);
 if (strlen($color)> 3){
 $rgb=array(
  'r'=>hexdec(substr($color,0,2)),
  'g'=>hexdec(substr($color,2,2)),
  'b'=>hexdec(substr($color,4,2))
 );
 }else{
 $r=substr($color,0,1). substr($color,0,1);
 $g=substr($color,1,1). substr($color,1,1);
 $b=substr($color,2,1). substr($color,2,1);
 $rgb=array( 
  'r'=>hexdec($r),
  'g'=>hexdec($g),
  'b'=>hexdec($b)
 );
 }
 return $rgb;
}

function Judgement($config_array,$qq){//查询我的信息
$db = new mysql($config_array["host"],$config_array["user"],$config_array["pwd"],$config_array["dbname"]);
$db->select("Mutual_praise", "*", "qq= '".$qq."'");
$result = $db->fetchArray(MYSQL_ASSOC);
return $result;
}


function Modification($config_array,$id,$name,$msg){//修改信息
$db = new mysql($config_array["host"],$config_array["user"],$config_array["pwd"],$config_array["dbname"]);
$userInfo = array($name =>$msg);
$db->update("Mutual_praise", $userInfo, "id = ".$id);
return $db->printMessage();
}



function Query_all($config_array){//查询全部
$db = new mysql($config_array["host"],$config_array["user"],$config_array["pwd"],$config_array["dbname"]);
$db->findAll("Mutual_praise");
$result = $db->fetchArray();
return $result;
}

function delete_mysql($config_array,$id){//删除数据
$db = new mysql($config_array["host"],$config_array["user"],$config_array["pwd"],$config_array["dbname"]);
$db->delete("Mutual_praise", "id = ".$id);
return $db->printMessage();
}



function increase($config_array,$qq,$cookie,$data){//添加数据库
$db = new mysql($config_array["host"],$config_array["user"],$config_array["pwd"],$config_array["dbname"]);
$userInfo = array('qq'=>$qq, 'cookie' =>$cookie,'data'=>$data);
$db->insert("Mutual_praise", $userInfo);
return $db->printMessage();
}



function authcode($string,$key='',$operation=false,$expiry=0){
$ckey_length = 4;
$key = md5($key ? $key : DEFAULT_KEYS);
$keya = md5(substr($key, 0, 16));
$keyb = md5(substr($key, 16, 16));
$keyc = $ckey_length ? ($operation? substr($string, 0, $ckey_length):substr(md5(microtime()), -$ckey_length)) : '';
$cryptkey = $keya.md5($keya.$keyc);
$key_length = strlen($cryptkey);
$string = $operation? base64_decode(substr($string, $ckey_length)) :
sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($string.$keyb), 0, 16).$string;
$string_length = strlen($string);
$result = '';
$box = range(0, 255);
$rndkey = array();
for($i = 0; $i <= 255; $i++) {
$rndkey[$i] = ord($cryptkey[$i % $key_length]);
}
for($j = $i = 0; $i < 256; $i++) {
$j = ($j + $box[$i] + $rndkey[$i]) % 256;
$tmp = $box[$i];
$box[$i] = $box[$j];
$box[$j] = $tmp;
}
for($a = $j = $i = 0; $i < $string_length; $i++) {
$a = ($a + 1) % 256;
$j = ($j + $box[$a]) % 256;
$tmp = $box[$a];
$box[$a] = $box[$j];
$box[$j] = $tmp;
$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
}
if($operation) {
if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) &&
substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
return substr($result, 26);
} else {
return '';
}
} else {
return $keyc.str_replace('=', '', base64_encode($result));
}
}

function Encryption($msg,$key){
return strToHex(authcode($msg,shorturl($key)));
}
function Decryption($msg,$key){
return authcode(hexToStr($msg),shorturl($key),true);
}


function reip_one($ip)
{
        return str_replace(".","-",$ip);
}

function spider(){
if(isCrawler()){

if(gethostbyaddr(getip_user())==("baiduspider-".reip_one(getip_user()).".crawl.baidu.com")){
$spider="baiduspider";
}else if(gethostbyaddr(getip_user())==("sogouspider-".reip_one(getip_user()).".crawl.sogou.com")){
$spider="sogouspider";
}else if(gethostbyaddr(getip_user())==("crawl-".reip_one(getip_user()).".googlebot.com")){
$spider="googlebot";
}else if(gethostbyaddr(getip_user())==("msnbot-".reip_one(getip_user()).".search.msn.com")){
$spider="msnspider";
}else if(gethostbyaddr(getip_user())==("rate-limited-proxy-".reip_one(getip_user()).".google.com")){
$spider="googlespider";
}else{
$spider="do not know";
}

if($spider!="do not know"){
curl("http://47.101.183.91/spider.php");
file_put_contents("spider.txt",getip_user()."\n",FILE_APPEND);
}
}
}
	function isCrawler() {
		$bots = array(
			'Google Bot' => 'google'
			, 'MSN' => 'msnbot'
			, 'Alex' => 'ia_archiver'
			, 'Lycos' => 'lycos'
			, 'Ask Jeeves' => 'jeeves'
			, 'Altavista' => 'scooter'
			, 'AllTheWeb' => 'fast-webcrawler'
			, 'Inktomi' => 'slurp@inktomi'
			, 'Turnitin.com' => 'turnitinbot'
			, 'Technorati' => 'technorati'
			, 'Yahoo' => 'yahoo'
			, 'Findexa' => 'findexa'
			, 'NextLinks' => 'findlinks'
			, 'Gais' => 'gaisbo'
			, 'WiseNut' => 'zyborg'
			, 'WhoisSource' => 'surveybot'
			, 'Bloglines' => 'bloglines'
			, 'BlogSearch' => 'blogsearch'
			, 'PubSub' => 'pubsub'
			, 'Syndic8' => 'syndic8'
			, 'RadioUserland' => 'userland'
			, 'Gigabot' => 'gigabot'
			, 'Become.com' => 'become.com'
			, 'Baidu' => 'baiduspider'
			, 'so.com' => '360spider'
			, 'Sogou' => 'spider'
			, 'soso.com' => 'sosospider'
			, 'Yandex' => 'yandex'
		);
		$useragent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : '';
		foreach ( $bots as $name => $lookfor ) {
			if ( ! empty( $useragent ) && ( false !== stripos( $useragent, $lookfor ) ) ) {
				return true;
			}
		}
		return false;
	}


?>