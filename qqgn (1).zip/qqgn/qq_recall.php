<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$id=$_REQUEST["id"];
$Dat=$_REQUEST["data"];
$type=$_REQUEST["type"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
if($type=="1"){
/*$url="https://zb.vip.qq.com/srf/QC_UniBusinessLogicServer_UniBusinessLogicObj/uniSet?g_tk=".getGTK($pskey);
$header=array("Cookie: p_uin=o".$uin."; qqNumber=".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ","User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; Redmi K30 Build/SKQ1.210908.001) V1_AND_SQ_8.8.93_2862_HDBM_T A_8089300 QQ/8.8.93.8060 NetType/WIFI WebP/0.4.1 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1000 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537121117","Content-Type: application/json","Host: zb.vip.qq.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$data='{"stLogin":{"iOpplat":3,"sClientVer":"8.8.88","sSKey":"'.getGTK($skey).'","sClientIp":"","iKeyType":1,"lUin":'.$uin.'},"stUniBusinessItem":{"itemid":"'.$id.'","appid":45,"hashid":""}}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
print_r($data);*/
print_r(curl("http://1.15.64.7/vip.php?uin=".$uin."&skey=".$skey."&pskey=".$pskey."&id=小白&msg=&itemid=".$id."&type=1&id=45"));
}else{
$url="https://zb.vip.qq.com/trpc-proxy/qqva/qc_submall_server/qc_submall_server/GetWithDrawMsg?g_tk=".getGTK($skey);
$header=array("Cookie: p_uin=o".$uin."; qqNumber=".$uin."; uin=o".$uin."; pt4_token=".$pt4_token."; skey=".$skey."; p_skey=".$pskey."; ","User-Agent: Dalvik/2.1.0 (Linux; U; Android 12; Redmi K30 Build/SKQ1.210908.001) V1_AND_SQ_8.8.88_2770_YYB_D A_8088800 QQ/8.8.88.7830 NetType/WIFI WebP/0.4.1 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1000 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537117930","Content-Type: application/json","Host: zb.vip.qq.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$data='{"options":{},"req":{"listindex":0,"lUid":'.$uin.',"appid":45,"pagesize":18,"stLogin":{"iOpplat":2,"sClientVer":"8.8.93","sSKey":"string","sClientIp":"","iKeyType":1,"lUin":'.$uin.'},"locationtype":3}}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
foreach ($json["response"]["modData"][0]["vitem"] as $key => $value)
{
echo ($key+1).":".$value["name"]."id:".$value["itemId"]."\n";
}

}
