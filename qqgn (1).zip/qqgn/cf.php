<?php
/**
 * 作者:苏晓晴
 * 作者QQ:3074193836
 * 点亮手机端QQ CF图标
 * 免费源码 无限制
 * 个人博客 www.toubiec.cn
 */
 
//使用方法 qq=qq号&skey=skey值&pskey=pskey值&type=1/0 (1=开启 0等于关闭)


$qq = $_GET['qq']; //请输入你获取cookie相对应的QQ号
$skey = $_GET['skey'];  //请输入你获取到的skey
$pskey = $_GET['pskey'];  //请输入你获取到的pskey
$header = [
    'Content-Type: application/json',
    'Referer: https://club.vip.qq.com/guestprivilege?_wv=16777218&_wwv=68&_nav_bgclr=ffffff&_nav_titleclr=ffffff&_nav_txtclr=ffffff&_nav_alpha=0&_wvx=10&_proxy=1&_proxyByURL=1&friend=774740085&trace_detail=base64-eyJhcHBpZCI6Im91dHNpZGUiLCJwYWdlX2lkIjoiMTAifQ%3D%3D'
];
$cookie = 'uin=o'.$qq.'; p_uin=o0'.$qq.'; skey='.$skey.'; p_skey='.$pskey.';';
$data   = '{"switch_type":'.$_GET['type']?:"1".'}';
$jsonp = curl('https://club.vip.qq.com/api/trpc/cf/SetSwitchStatus?g_tk='.getbkn($pskey),$data,$cookie,$header);
if($_GET['type']==1){
 $type = '点亮';   
}elseif($_GET['type']==0){
 $type = '熄灭';      
}
if (empty($jsonp)) {
    $json = ['code'=>-1,'msg'=>'好像失败了，重试一下！'];
} elseif (isset($jsonp['message'])||isset($type)) {
    $json = ['code'=>1,'msg'=>'操作成功！'.($type)];
} else{
    $json = ['code'=>-1,'msg'=>$jsonp];
}

echo json_encode($json,320);

//计算skey或者pskey值来获得bkn/gtk值
function getbkn($skey) {
    $len = strlen($skey);
    $hash = 5381;
    for ($i = 0; $i < $len; $i++) {
        $hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
        $hash &= 2147483647;
    }
    return $hash & 2147483647;
}

//解析需要的参数 请勿乱动！
function curl($url,$data = null,$cookie = null,$headers = []){
    $con = curl_init((string)$url);
    curl_setopt($con, CURLOPT_HEADER, false);
    curl_setopt($con, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($con, CURLOPT_RETURNTRANSFER, true);
    if (!empty($headers)) {
        curl_setopt($con, CURLOPT_HTTPHEADER, $headers);
    }
    if (!empty($cookie)) {
        curl_setopt($con, CURLOPT_COOKIE, $cookie);
    }
    if (!empty($data)) {
        curl_setopt($con, CURLOPT_POST, true);
        curl_setopt($con, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($con, CURLOPT_TIMEOUT, 5000);
    $result = curl_exec($con);
    return $result;
}