<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$qq=$_REQUEST["qq"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://user.qzone.qq.com/proxy/domain/g.qzone.qq.com/fcg-bin/cgi_emotion_list.fcg?uin=".$qq."&loginUin=".$uin."&rd=0.11092632644496292&num=3&noflower=1&g_tk=".getGTK($pskey)."&qzonetoken=&g_tk=".getGTK($pskey);
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36");
$data=curl($url,null,$header);
$url=file_get_contents("http://api.unipay.qq.com/v1/r/1450000172/wechat_query?cmd=7&session_id=uin&session_type=skey&openid=".$uin."&openkey=".$skey);
$json=json_decode($url,true);
$Dat=$_REQUEST["data"];
$url1="https://user.qzone.qq.com/proxy/domain/g.qzone.qq.com/fcg-bin/cgi_emotion_list.fcg?uin=1242619315&loginUin=".$uin."&rd=0.11092632644496292&num=3&noflower=1&g_tk=".getGTK($pskey)."&qzonetoken=&g_tk=".getGTK($pskey);
$data1=curl($url1,null,$header);
if($Dat=="json"){
print_r($data);
}else{
if($json["ret"]!="0"){
print_r("Cookie Invalid!");
exit();
}
if($data!=null){
print_r("success!");
}else{
print_r("No!");
}}
