<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$uin=$_REQUEST["uin"];
$qq=$_REQUEST["qq"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://cgi.vip.qq.com/card/getExpertInfo?ps_tk=".getGTK($pskey)."&fuin=".$qq."&callback=jsonp2";
$header=array("Host: cgi.vip.qq.com","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.131 Mobile Safari/537.36 V1_AND_SQ_8.8.50_2324_YYB_D A_8085000 QQ/8.8.50.6735 NetType/WIFI WebP/0.4.1 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1037420 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0","accept: */*","x-requested-with: com.tencent.mobileqq","sec-fetch-site: same-site","sec-fetch-mode: no-cors","sec-fetch-dest: script","referer: https://club.vip.qq.com/","accept-encoding: gzip, deflate","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Cookie: uin=o".$uin.";skey=".$skey.";p_skey=".$pskey.";p_uin=o".$uin.";");
$data=curl($url,null,$header);
$data=getSubstr($data, "jsonp2(", ");");
$data=json_decode($data,true);
$array=array('ret'=>$data["ret"],'me'=>$data["data"]["m"][1],'Opponent'=>$data["data"]["g"][1]);
Back($array);
