<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$group=$_REQUEST["group"];
$id=$_REQUEST["id"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array('Cookie: ptui_loginuin='.$uin.'; p_uin=o'.$uin.'; uin=o'.$uin.'; skey='.$skey.'; p_skey='.$pskey.';');
$url="https://qun.qq.com/cgi-bin/qun_mgr/get_group_list?bkn=".GetBkn($skey);
$data=curl($url,$data,$header);
$json=json_decode($data,true);
Back($json);