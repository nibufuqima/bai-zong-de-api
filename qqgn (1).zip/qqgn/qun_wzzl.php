<?php
include("function.php");
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$uin=$_REQUEST["uin"];
$type=$_REQUEST["type"]?:"对抗路";
$max=$_REQUEST["max"]?:"10";
$pskey=$_REQUEST["pskey"];
$group=$_REQUEST["group"];
$ty=$_REQUEST["data"];
$bdlb=array(
"对抗路" => "1",
"中路" => "2",
"发育路" => "3",
"打野" => "4",
"游走" => "5",
);
$lx=$bdlb[$type];
$url="https://trpc.gamecenter.qq.com/?g_tk=".GetGTK($pskey);
$header=array("Origin: https://speed.gamecenter.qq.com","Cookie: p_skey=".$pskey.";uin=o".$uin.";","Content-Type: application/json","User-Agent: QQ/8.8.33 Android/0.17 Android/11","Host: trpc.gamecenter.qq.com","Connection: Keep-Alive","Accept-Encoding: gzip");
$data='{"list":[{"msg":{"clientRPCName":"\/v1\/345"},"options":{"serializationType":2},"rawData":"{\"groupCode\":'.$group.',\"branchId\":'.$lx.'}"}]}';
$data=curl($url,$data,$header);
if($data==null){
echo "Cookie失效，请重新获取！";
exit();
}
$data=json_decode($data,true)["list"][0]["rawData"];
$json=json_decode($data,true);
if($ty=="json"){
Back($json);
}else{
foreach ($json["users_branch_rank"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["base_info"]["nick"]."-".$value["hero_name"]."\n";
echo "英雄战力:".$value["hero_fight"]."\n";
echo "累计场数:".$value["total_num"]."\n------------------\n";
}
echo "当前榜单:".$type;
}