<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$qq=$_REQUEST["qq"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$group=$_REQUEST["group"];
$time=time();
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qun.qq.com/cgi-bin/qun_mgr/search_group_members?gc=".$group."&key=".$qq."st=0&end=30&sort=15&bkn=".getGTK($skey);
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data="bkn=".getGTK($skey)."&uin=".$uin."";
$return=get_result($url,$data,$header);
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $return);
//echo $str;
$data=json_decode($return,true);
date_default_timezone_set("PRC");
$time=date("Y-m-d H:i:s", time());
$join_time = date("Y-m-d H:i:s", $data["mems"][0]["join_time"]);
$last_speak_time = date("Y-m-d H:i:s", $data["mems"][0]["last_speak_time"]);
$finish_time=times($join_time,$time);
$array=array(
'code'=>$data["ec"],
'uin'=>$data["mems"][0]["uin"],
'g'=>$data["mems"][0]["g"],
'card'=>$data["mems"][0]["card"],
'nick'=>$data["mems"][0]["nick"],
'point'=>$data["mems"][0]["lv"]["point"],
'level'=>$data["mems"][0]["lv"]["level"],
'join_time'=>$join_time,
'finish_time'=>$finish_time,
'last_speak_time'=>$last_speak_time,
);
Back($array);

function times($startdate,$enddate){
$date=floor((strtotime($enddate)-strtotime($startdate))/86400);
$hour=floor((strtotime($enddate)-strtotime($startdate))%86400/3600);
$minute=floor((strtotime($enddate)-strtotime($startdate))%86400/60%60);
$second=floor((strtotime($enddate)-strtotime($startdate))%86400%60);
if($date=='0'){
return $hour."小时".$minute."分钟".$second."秒";
}else
if($date=='0'&$hour=='0'){
return $minute."分钟".$second."秒";
}else
if($date!='0'){
return $date."天".$hour."小时".$minute."分钟".$second."秒";
}

}