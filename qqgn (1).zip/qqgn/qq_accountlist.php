<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$Dat=$_REQUEST["data"];
$type=$_REQUEST["type"];
$time=date("Y-m-d H：i：s");
$time1=date("Y-m-d");
if(!$uin || !$skey){
print_r("参数不完整!需要参数:uin，skey");
exit();
}
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey.";  p_skey=".$pskey.";","Host: myun.tenpay.com","accept: application/json","cache-control: no-cache, no-store","x-requested-with: XMLHttpRequest","sec-fetch-mode: cors","sec-fetch-site: same-origin","accept-encoding: gzip, deflate, br","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$url="https://myun.tenpay.com/cgi-bin/clientv1.0/qwallet_account_list.cgi?limit=15&offset=0&s_time=".$time1."&ref_param=&source_type=7&time_type=0&bill_type=0&uin=".$uin;
$json=curl($url,null,$header);
preg_match_all('/{"action_type":\"(.*?)\","amount":\"(.*?)\","balance":\"(.*?)\","bank_name":\"(.*?)\","bank_type":\"(.*?)\","desc":\"(.*?)\","from_amount":\"(.*?)\","from_name":\"(.*?)\","modify_time":\"(.*?)\","row_id":\"(.*?)\","sp_billno":\"(.*?)\","subject_name":\"(.*?)\","trade_state":\"(.*?)\","trans_id":\"(.*?)\","type":\"(.*?)\"}/',$json,$data);
//$json=json_decode($json,true);
//print_r($data);
if($type=="1"){
$types="10";
}else{
$types="13";
}
foreach ($data[15] as $key => $value){
if($key=="10"){
        break; // 当 $k为$m时，终止循环
    }
if($value==$types){
echo ($s+1).":".$data[12][$key]."\n";
echo "时间:".$data[9][$key]."\n";
echo "金额:".($data[2][$key]/100)."元\n";
echo "订单号:".$data[10][$key]."\n-----------------------\n";
++$s;
}
}

