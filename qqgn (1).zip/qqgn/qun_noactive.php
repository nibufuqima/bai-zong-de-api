<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$uin=$_REQUEST["uin"];
$group=$_REQUEST["group"];
$num=$_REQUEST["num"]?:"1";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$time=(2592000*$num);
$num=($num+1);
$time2=(2592000*$num);
$data="gc=".$group."&st=0&end=40&sort=0&last_speak_time=".$time."%7C".$time1."&bkn=".GetBkn($skey);
$header=array("Cookie: uin=o".$uin."; p_uin=o".$uin."; skey=".$skey."; p_skey=".$pskey.";");
$data=curl("https://qun.qq.com/cgi-bin/qun_mgr/search_group_members",$data,$header);
$json=json_decode($data,true);
$ec=$json["ec"];
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
if($ec==4)
{
print_r(jsonjx(array("code"=>-1,"error"=>"Logon information is invalid")));
}else if($ec==0)
{
print_r(jsonjx($json));
}}