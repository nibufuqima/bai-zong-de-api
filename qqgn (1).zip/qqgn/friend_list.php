<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$uin=$_REQUEST["uin"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin."; p_uin=o".$uin."; skey=".$skey."; p_skey=".$pskey.";");
$data=curl("https://qun.qq.com/cgi-bin/qun_mgr/get_friend_list?bkn=".GetBkn($skey),null,$header);
$json=json_decode($data,true);
$ec=$json["ec"];
if($ec==4)
{
print_r(jsonjx(array("code"=>-1,"error"=>"Logon information is invalid")));
}else if($ec==0)
{
$arr=array();
$arr["code"]=200;
$result=preg_match_all('/{\"name\":\"(.*?)\",\"uin\":([0-9]+)}/i',$data,$array);
//print_r($array[1][1]);
for($i=0;$i<$result;$i++)
{
//$arr["list"][]=array("name"=>unicodeDecode($array[1][$i]),"uin"=>$array[2][$i]);
$arr["list"][]=$array[2][$i];
}
print_r(jsonjx($arr));
}else{
print_r(jsonjx(array("code"=>-1,"error"=>"ERROR, Status Code: ".$ec)));
}
