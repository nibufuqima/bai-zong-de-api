<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$max=$_REQUEST["max"]?:"20";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Referer: https://mq.vip.qq.com/m/growth/rank?_wv=1025&_wwv=4","User-Agent: Mozilla/5.0 (Linux; Android 10; SEA-AL10 Build/HUAWEISEA-AL10; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.126 MQQBrowser/6.2 TBS/045008 Mobile Safari/537.36 V1_AND_SQ_8.2.6_1320_YYB_D QQ/8.2.6.4370 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/81 SimpleUISwitch/0");
$url="https://mq.vip.qq.com/m/growth/loadfrank?pn=1&g_tk=".getPTK($skey)."&ps_tk=".getGTK($pskey);
$data=curl($url,null,$header);
$json=json_decode($data,true);
$json=json_decode($data,true);
$ec=$json["ret"];
if($ec!="0"){
print_r("Cookie失效，请重新获取！");
exit();
}
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
foreach ($json["data"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
$url="https://mq.vip.qq.com/m/growth/doPraise?method=0&toUin=".$value["uin"]."&g_tk=".getPTK($skey)."&ps_tk=".getGTK($pskey);
$data=curl($url,null,$header);
}
print_r("点赞成功!");
}