<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$qq=$_REQUEST["qq"];
$uin=$_REQUEST["uin"];
$group=$_REQUEST["group"];
$max=$_REQUEST["max"]?:"10";
$Dat=$_REQUEST["lx"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$Dat=$_REQUEST["data"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_skey=".$pskey.";p_uin=o".$uin."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Referer: https://qun.qq.com/v2/signin/records?gc=".$group."","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Content-Type: application/json; charset=UTF-8","Host: qun.qq.com");
$url="https://qun.qq.com/v2/signin/trpc/GetKingSignedList?g_tk=".getGTK($pskey);
$data='{"dayYmd":"","offset":0,"limit":0,"uid":"'.$uin.'","groupId":"'.$group.'"}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
if($Dat=="json"){
print_r(jsonjx($json));
}
else{
foreach ($json["response"]["topSignedTotal"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["groupNick"]."-".$value["uid"]."\n";
echo "累计打卡:".$value["signedCount"]."\n";
}
}
