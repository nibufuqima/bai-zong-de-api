<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qinfo.clt.qq.com/cgi-bin/qun_info/get_group_members_lite";
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data="gc=".$group."&bkn=".GetBkn($skey)."&src=qinfo_v3&_ti=".msectime();
$data=get_result($url,$data,$header);
$json=json_decode($data,true);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
print_r(jsonjx($json["mems"]));}
function get_result($url,$data,$header)
{
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,$url);
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
curl_setopt($curl,CURLOPT_TIMEOUT,30);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,FALSE);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,FALSE);
curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
$return=curl_exec($curl);
curl_close($curl);
return $return;
}
function GetBkn($skey) {
	$hash = 5381;
	for ($i = 0, $len = strlen($skey); $i < $len; ++$i) {
		$hash +=($hash << 5) + charCodeAt($skey, $i);
	}
	return $hash & 2147483647;
}
function GetGTK($skey) {
	$len = strlen($skey);
	$hash = 5381;
	for ($i = 0; $i < $len; $i++) {
		$hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
		$hash &= 2147483647;
	}
	return $hash & 2147483647;
}
function charCodeAt($str, $index) {
	$char = mb_substr($str, $index, 1, 'UTF-8');
	$value = null;
	if (mb_check_encoding($char, 'UTF-8')) {
		$ret = mb_convert_encoding($char, 'UTF-32BE', 'UTF-8');
		$value = hexdec(bin2hex($ret));
	}
	return $value;
}
function jsonjx($data){
$data=json_encode($data);
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $data);
$str=str_replace("\/",'/',$str);


return $str;
}
function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}
function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    
    return $msectime;
}
