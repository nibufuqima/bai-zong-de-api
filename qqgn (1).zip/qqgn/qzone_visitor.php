<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$qq=$_REQUEST["qq"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$qq){
print_r("参数不完整!需要参数:uin，skey，pskey，qq");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_uin=o".$uin.";p_skey=".$pskey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Referer: https://user.qzone.qq.com/".$uin."/main","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/g.qzone.qq.com/cgi-bin/friendshow/cgi_get_visitor_simple?uin=".$qq."&mask=1&g_tk=".getGTK($skey)."&g_tk=".getGTK($skey);
$data=curl($url,$data,$header);
$data=str_replace('_Callback(','',$data);
$data=str_replace(');','',$data);
$json=json_decode($data,true);
$Dat=$_REQUEST["data"];
//print_r($json);
if($Dat=="json"){
print_r($data);
}else{
echo "今日访客:".$json["data"]["modvisitcount"][0]["todaycount"]."\n";
echo "访客总数:".$json["data"]["modvisitcount"][0]["totalcount"];
}