<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$ldw=ldw($uin,$skey,$pskey);
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_skey=".$pskey.";p_uin=o".$uin.";ldw=".$ldw."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Referer: https://id.qq.com/myself/myself.html?ver=10045&","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Content-Type: application/x-www-form-urlencoded; charset=UTF-8","Host: id.qq.com");
$url="https://id.qq.com/cgi-bin/userinfo_mod";
$data1="&ldw=".$ldw."&g=&bir_new_lunar=0&bir_new_second=0&work=&ln=&realname=&commt=&g=&sx=&xz=&mail=&n=%E3%80%80&pos_u=&pos_p=0&pos_c=&pos_d=&gx_u=&gx_p=&gx_c=&gx_d=&xx=";
$data1=curl($url,$data1,$header);
$json=json_decode($data1,true);
if($json["ec"]!="0"){
print_r("操作失败!");
exit();
}else{
print_r("清空成功!");
}

function ldw($uin,$skey,$pskey){
$url='https://id.qq.com/cgi-bin/get_base_key?r=0.5208226027853338';
$header=array("User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","Host: id.qq.com","Referer: https://id.qq.com/level/mylevel.html?ver=10043&","Cookie: uin=o".$uin.";skey=".$skey.";p_skey=".$pskey.";p_uin=o".$uin.";");
$data=getcurl($url,null,$header);
preg_match('/ldw=(.*?);/',$data['header'],$data);
return ($data[1]);
}
function getcurl($url,$data=0,$header_array=0,$referer=0,$time=30,$code=0) {
if($header_array==0) {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
} else {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user());
$header=array_merge($header_array,$header);
}
//print_r($header);
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,$url);
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
if($data) {
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
}
if($referer) {
curl_setopt($curl,CURLOPT_REFERER,$referer);
}
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 3);
//设置等待时间
curl_setopt($curl,CURLOPT_TIMEOUT,$time);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
curl_setopt($curl, CURLOPT_HEADER, 1);
$return=curl_exec($curl);
$code_code=curl_getinfo($curl);
curl_close($curl);
$code_int['exec']=substr($return,$code_code["header_size"]);
$code_int['code']=$code_code["http_code"];
$code_int['content_type']=$code_code["content_type"];
$code_int['header']=substr($return,0,$code_code["header_size"]);
return $code_int;
}