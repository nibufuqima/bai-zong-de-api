<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("hs.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$Dat=$_REQUEST['lx'];
$Dat=$_REQUEST["data"];
$time=time();
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qinfo.clt.qq.com/cgi-bin/qun_info/get_group_info_all?gc=".$group;
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Referer: https://qinfo.clt.qq.com/qinfo_v3/member.html?groupuin=");
$data="bkn=".getGTK($skey)."&src=qinfo_v3&_ti=".$time."";
$return=get_result($url,$data,$header);
$data=json_decode($return,true);
if($Dat=="json"){
print_r(jsonjx($data));
}else{
print_r(lbh($data));
}
function lbh($data){
$gAdmins=$data["gAdmins"];
$ns=$data["ns"];
foreach ($gAdmins as $key => $gAdmins)
{
echo ($key+1).":".$gAdmins."-".$ns[$gAdmins]."\n";
}
}

