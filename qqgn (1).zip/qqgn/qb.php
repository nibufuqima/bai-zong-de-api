<?php
include("function.php");
$uin=$_GET['qq'];
$skey=$_GET['skey'];
$pskey=$_GET['pskey'];
$get=getGTK($pskey);
$url=file_get_contents("http://api.unipay.qq.com/v1/r/1450000186/wechat_query?cmd=4&pf=vip_m-pay_html5-html5&pfkey=pfkey&from_h5=1&from_https=1&format=jsonp__getQBBalance&openid=".$qq."&openkey=".$skey."&session_id=uin&session_type=skey");
$url="https://myun.tenpay.com/cgi-bin/clientv1.0/cancel_query.cgi?uin=".$uin."&skey=".$skey."&skey_type=2&_=1589172571426";
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data=null;
$return=get_result($url,$data,$header);
print_r($return);
?>