<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$group=$_REQUEST["group"];
$img=$_REQUEST["img"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$data=curl($img);
$size=strlen(curl($img));
$url="http://htdata3.qq.com/cgi-bin/httpconn?htcmd=0x6ff0072&ver=5520&ukey=".$skey."&range=0&uin=".$uin."&seq=1&groupuin=".$group."&filetype=3&imagetype=5&userdata=0&subcmd=1&subver=101&clip=0_0_0_0&filesize=".$size;
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36");
$json=curl($url,$data,$header);
print_r("yes");

