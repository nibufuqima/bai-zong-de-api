<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$type=$_REQUEST["type"];
$Dat=$_REQUEST["data"];
$time=date("Y-m-d");
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey.";  p_skey=".$pskey.";","Host: myun.tenpay.com","accept: application/json","cache-control: no-cache, no-store","x-requested-with: XMLHttpRequest","sec-fetch-mode: cors","sec-fetch-site: same-origin","accept-encoding: gzip, deflate, br","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$url="https://myun.tenpay.com/cgi-bin/clientv1.0/qwallet_record_list.cgi?limit=15&offset=0&s_time=".$time."&ref_param=&source_type=7&time_type=0&bill_type=0&uin=".$uin;
$json=curl($url,null,$header);
$json=json_decode($json,true);
$time=$json["records"][0]["create_time"];
$source_type=$json["records"][0]["source_type"];
$time=str_replace(" ",'%20',$time);
$time=str_replace(":",'%3A',$time);
$id=$json["records"][0]["trans_id"];
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey.";  p_skey=".$pskey.";","Host: myun.tenpay.com","accept: application/json","cache-control: no-cache, no-store","x-requested-with: XMLHttpRequest","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/045814 Mobile Safari/537.36 V1_AND_SQ_8.8.28_2092_YYB_D A_8082800 QQ/8.8.28.6155 NetType/4G WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1051024 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0","sec-fetch-site: same-origin","sec-fetch-mode: cors","sec-fetch-dest: empty","Referer: https://myun.tenpay.com/mqq/myun/trade/record.shtml?_wv=1027&_wvx=10","accept-encoding: gzip, deflate, br","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$url="https://myun.tenpay.com/cgi-bin/clientv1.0/qwallet_record_delete.cgi?create_time=".$time."&trans_id=".$id."&source_type=".$source_type."&uin=".$uin;
$jso=curl($url,null,$header);
print_r($jso);
if($type=="1"){
foreach ($json["records"] as $key => $value)
{
$time=$value["create_time"];
$time=str_replace(" ",'%20',$time);
$time=str_replace(":",'%3A',$time);
$id=$value["trans_id"];
$json=curl("https://myun.tenpay.com/cgi-bin/clientv1.0/qwallet_record_delete.cgi?create_time=".$time."&trans_id=".$id."&source_type=".$source_type."&uin=".$uin,null,$header);
}
}
