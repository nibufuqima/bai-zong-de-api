<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$text=$_REQUEST['text'];
$pskey=$_REQUEST['pskey'];
$group=$_REQUEST['group'];
$img=$_REQUEST['img'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
if(empty($text)){
print_r("内容(text)不能为空");
exit();
}
/*$url="https://web.qun.qq.com/cgi-bin/announce/list_announce?bkn=".getGTK($skey);
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data="qid=".$group."&bkn=".getGTK($skey)."&ft=23&s=-1&n=50&i=1&ni=1";
$data=get_result($url,$data,$header);
$json=json_decode($data,true);
$fid=$json["inst"][0]["fid"];
$url="https://web.qun.qq.com/cgi-bin/announce/del_feed?bkn=".getGTK($skey);
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Referer: https://web.qun.qq.com/mannounce/detail.html");
$data="qid=".$group."&bkn=".getGTK($skey)."&fid=".$fid."";
$return=get_result($url,$data,$header);*/
$url="https://web.qun.qq.com/cgi-bin/announce/upload_img";
getImg($img,"1.png");
$file = realpath('1.png'); //要上传的文件
$fields['pic_up'] = new CURLFile(realpath($file)); 
$fields['m'] = '0'; 
$fields['source'] = 'troopNotice'; 
$fields['qid'] = $group; 
$fields['bkn'] =GetBkn($skey); 
$header_array=array("Cookie: uin=o".$uin."; p_uin=o".$uin."; skey=".$skey."; p_skey=".$pskey.";");
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
$header=array_merge($header_array,$header);
$ch =curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
curl_setopt($ch,CURLOPT_POST,true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$content = curl_exec($ch);
$data=json_decode($content,true);
$dat=str_replace('&quot;','',$data['id']);
preg_match_all('/id:(.*?),/',$dat,$data);
$id=$data[1][0];
preg_match_all('/h:(.*?),id/',$dat,$data);
$h=$data[1][0];
preg_match_all('/w:(.*?)}/',$dat,$data);
$w=$data[1][0];
$url="https://web.qun.qq.com/cgi-bin/announce/add_qun_notice?bkn=".getGTK($skey);
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data='qid='.$group.'&bkn='.getGTK($skey).'&text='.$text.'&pinned=1&type=20&settings={"s_show_edit_card":0,"tip_window_type":0,"confirm_required":1}&pic='.$id.'&imgWidth='.$w.'&imgHeight='.$h.'';
$return=curl($url,$data,$header);
print_r($return);
function getImg($url, $filename){
    //去除URL连接上面可能的引号
    $hander = curl_init();
    $fp = fopen($filename, 'wb');
    curl_setopt($hander, CURLOPT_URL, $url);
    curl_setopt($hander, CURLOPT_FILE, $fp);
    curl_setopt($hander, CURLOPT_HEADER, 0);
    curl_setopt($hander, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($hander, CURLOPT_TIMEOUT, 60);
    curl_exec($hander);
    curl_close($hander);
    fclose($fp);
    return true;
}