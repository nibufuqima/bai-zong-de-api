<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$Dat=$_REQUEST["data"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_skey=".$pskey.";p_uin=o".$uin.";ldw=573dd061af733bb538c2e268af054a68aeb7a194e7355567","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Referer: https://id.qq.com/home/home.html?ver=10049&","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: id.qq.com");
$url="https://id.qq.com/cgi-bin/summary?ldw=573dd061af733bb538c2e268af054a68aeb7a194e7355567&r=0.41045531247590783";
$data=curl($url,$data,$header);
$json=json_decode($data,true);
if($Dat=="json"){
print_r($data);
}else{
if($json["ec"]=="1"){
print_r("Cookie失效，请重新获取！");
}else{
$array=array('好友数量'=>$json["friend_count"],'单项好友'=>$json["odd_count"]);
print_r(jsonjx($array));}
}


