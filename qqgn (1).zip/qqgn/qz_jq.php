<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$guin = @$_REQUEST['guin']; //接收群号
$type = @$_REQUEST['type']; //接收类型
$key=curl("https://shang.qq.com/wpa/g_wpa_get?guin=".$guin."",null,array("User-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","Referer: https://shang.qq.com/wpa/g_wpa_get?guin=".$guin.""));
$key=json_decode($key,true)["result"]["data"][0]["key"];
$data=curl("http://shang.qq.com/wpa/qunwpa?idkey=".$key."",null,array("User-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","Referer: http://shang.qq.com/wpa/qunwpa?idkey=".$key.""));
//print_r($data);
preg_match_all('/var k = \"(.*?)\";/',$data,$data);
//print_r(urldecode($data[1][0]));
header('Location:'.urldecode($data[1][0]).'');
function GetBetween($content,$start,$end){

$r = explode($start, $content);

if (isset($r[1])){

$r = explode($end, $r[1]);

return $r[0];

}

return '';

}

function get($url)

{

$header = array (

"Content-Type: application/x-www-form-urlencoded",

'Accept: */*',

"Referer: ".$url,

'User-Agent: Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1)',);

$ch = curl_init();

curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

curl_setopt($ch, CURLOPT_URL, $url);

$output = curl_exec($ch);

curl_close($ch);

return $output;

}

?>