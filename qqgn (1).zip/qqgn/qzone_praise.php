<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$msg=urlencode($_REQUEST["msg"]);
$n=$_REQUEST["n"];
$max=$_REQUEST["max"]?:"10";
$header=array("User-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","referer: https://user.qzone.qq.com/1242619315/infocenter?via=toolbar","Cookie: uin=o1242619315;skey=@i1MxivCL6;p_uin=o1242619315;p_skey=52ucuFhRMDrwy1aGNDi5D0DXo6jb3dys3qhEa63eOHg_","Host: user.qzone.qq.com");
$data="qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F1242619315%2Finfocenter%3Fvia%3Dtoolbar&opuin=1242619315&unikey=http%3A%2F%2Fuser.qzone.qq.com%2F30802061%2Fmood%2F8d00d6018833066183160d00&curkey=http%3A%2F%2Fuser.qzone.qq.com%2F2315554567%2Fmood%2F078f048a5a61066184910300&from=1&appid=311&typeid=5&abstime=1627808090&fid=078f048a5a61066184910300&active=0&fupdate=1";
$data=curl("https://user.qzone.qq.com/proxy/domain/w.qzone.qq.com/cgi-bin/likes/internal_dolike_app?g_tk=1160742902",$data,$header);
print_r($data);




