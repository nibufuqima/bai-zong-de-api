<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$type=$_REQUEST['n'];
$n=($type -1);
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$time=date('Y-m-d H:i:s',strtotime('+1 day'));
$time2=($time - 1800);
$url="https://client.qun.qq.com/cgi-bin/feeds/get_t_list?s=-1&n=100&ft=21&i=1&bkn=".getGTK($skey)."&qid=".$group;
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
if($json["ec"]=="1"){
print_r("Cookie失效，请重新获取！");
}else{
if(empty($json["feeds"])){
die('投票列表空空!');
}else{
foreach ($json["feeds"] as $key => $value)
{
echo ($key+1).":".$value["msg"]["t"]["text"]."\n";
echo "fid:".$value["fid"]."\n";

}}
}}

