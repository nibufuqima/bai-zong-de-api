<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$group=$_REQUEST["group"];
$uin=$_REQUEST["uin"];
$lx=$_REQUEST["lx"];
$qq=$_REQUEST["qq"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$Dat=$_REQUEST["data"];
if(!$uin || !$skey || !$pskey || !$qq){
print_r("参数不完整!需要参数:uin，skey，pskey，qq");
exit();
}
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey.";  p_skey=".$pskey.";","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Referer: https://ti.qq.com/interactive_logo/word?target_uin=".$qq."&auto_take=1&_wv=67108865&_nav_txtclr=FFFFFF&_wvSb=0","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Content-Type: application/json; charset=UTF-8","Host: ti.qq.com");
$url="https://ti.qq.com/interactive_logo/word/proxy/domain/oidb.tim.qq.com/v3/oidbinterface/oidb_0xdd3_0?sdkappid=39998&actype=2&bkn=".GetBkn($skey);
$data='{"rpt_uint64_frd_uin":['.$qq.'],"uint32_check_recentchat_timespan":7,"uint32_req_pic_type":1,"uint32_start_idx":0,"uint32_req_count":149}';
$json=curl($url,$data,$header);
//$data=base64_decode($data);
$data=json_decode($json,true);
$ErrorCode=$data["ErrorCode"];
if($Dat=="json"){
print_r($json);
}else{
if($ErrorCode=="307"){
print_r("Cookie失效，请重新获取！");
exit();
}
else{
if(empty($data["rpt_msg_get_specialwordlist_rsp"][0]["msg_specialword_frdInfo"]["rpt_msg_specialword_cardInfo"])){
die('空空如也');
}
foreach ($data["rpt_msg_get_specialwordlist_rsp"][0]["msg_specialword_frdInfo"]["rpt_msg_specialword_cardInfo"] as $key => $value)
{
echo ($key+1).":".base64_decode($value["msg_specialword_res"]["bytes_word"])."(".$value["msg_specialword_attr"]["bytes_card_id"].")\n";
//echo "寓意:".base64_decode($value["msg_specialword_res"]["bytes_gray_url"])."\n";
}
}
}

