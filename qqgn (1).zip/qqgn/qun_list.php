<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$type=$_REQUEST["type"];
$msg=$_REQUEST["msg"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://qun.qq.com/cgi-bin/qun_mgr/get_group_list";
$header=array("Host: qun.qq.com","accept: application/json, text/javascript, */*; q=0.01","x-requested-with: XMLHttpRequest","user-agent: Mozilla/5.0 (Linux; Android 12; Redmi K30 Build/SKQ1.210908.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36","content-type: application/x-www-form-urlencoded; charset=UTF-8","origin: https://qun.qq.com","sec-fetch-site: same-origin","sec-fetch-mode: cors","sec-fetch-dest: empty","referer: https://qun.qq.com/member.html","accept-encoding: gzip, deflate","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; traceid=6055258e30; pgv_info=ssid=s9222110930; pgv_pvid=3638706782");
$data="bkn=".GetBkn($skey);
$data=curl($url,$data,$header);
$data=json_decode($data,true);
if($type=="1"){
$dat["code"]=$data["ec"];
$dat["list"]=$data["manage"];
Back($dat);
}


if($type=="2"){
$dat["code"]=$data["ec"];
$dat["list"]=$data["create"];
Back($dat);
}

