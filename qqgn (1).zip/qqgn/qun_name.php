<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$group=$_REQUEST["group"];
$msg=$_REQUEST["msg"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://qinfo.clt.qq.com/cgi-bin/qun_info/get_group_info_all?gc=".$group;
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Referer: https://qinfo.clt.qq.com/qinfo_v3/member.html?groupuin=");
$data="bkn=".getGTK($skey)."&src=qinfo_v3&_ti=".$time."";
$return=get_result($url,$data,$header);
$data=json_decode($return,true);
$data="src=qinfo_v3&gc=".$group."&bkn=".GetBkn($skey)."&fOthers=1&gName=".$msg."&gIntro=".$data["gIntro"]."&gRIntro=&gRemark=0&nWeb=1";
$url="https://qinfo.clt.qq.com/cgi-bin/qun_info/set_group_info_new";
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Host: qinfo.clt.qq.com","Connection: keep-alive","Accept: application/json","Content-Type: application/x-www-form-urlencoded","Origin: https://qinfo.clt.qq.com","User-Agent: Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) QQ/9.5.0.27852 Chrome/43.0.2357.134 Safari/537.36 QBCore/3.43.1298.400 QQBrowser/9.0.2524.400","X-Requested-With: XMLHttpRequest","Referer: https://qinfo.clt.qq.com/qinfo_v3/profile.html?groupuin=".$group."","Accept-Encoding: gzip, deflate","Accept-Language: en-US,en;q=0.8");
$json=curl($url,$data,$header);
print_r($json);

