<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$group=$_REQUEST["group"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$qq=$_REQUEST["qq"];
$Dat=$_REQUEST["lx"];
$Dat=$_REQUEST["data"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://yundong.qq.com/v2/rank/friend?_wv=18950113&_wwv=8192";
$header=array("User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.5_1858_YYB_D A_8080500 QQ/8.8.5.5570 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data=null;
$return=get_result($url,$data,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$url=getSubstr($return,$left,$right);
$json=json_decode($url,true);
if($Dat=="json"){
print_r($url);

}else{
$data=$json["ranknodes"];
foreach ($data as $key => $value)
{
echo ($key+1).":".$value["uin"]."-".$value["nickname"]."\n";
echo "步数:".$value["steps"]."步\n";

}
}
