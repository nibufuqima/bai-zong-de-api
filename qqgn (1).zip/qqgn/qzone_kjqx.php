<?php
//空间权限
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$max=$_REQUEST["max"]?:"10";
$type=$_REQUEST["type"]?:"1";
$lx=$_REQUEST["lx"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://user.qzone.qq.com/proxy/domain/w.qzone.qq.com/cgi-bin/right/set_entryright.cgi?=&g_tk=".getGTK($pskey);
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$bdlb=array(
"1" => "flag=0x0&fupdate=1&uin=".$uin."&ver=1&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fprofile%2Fpermit",//所有人
"2" => "flag=0x20101&fupdate=1&uin=".$uin."&ver=1&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fprofile%2Fpermit",//好友
"3" => "flag=0x40000&fupdate=1&uin=".$uin."&ver=1&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fprofile%2Fpermit",//自己
);
$data=$bdlb[$type];
$json=curl($url,$data,$header);
$data=getSubstr($json,'frameElement.callback(',');');
print_r($data);

