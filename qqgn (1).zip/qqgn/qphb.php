<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$uin=$_REQUEST["uin"];
$group=$_REQUEST["group"];
$Dat=$_REQUEST["data"];
$max=$_REQUEST["max"]?:"10";
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$type=$_REQUEST['type']?:"管理员";
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$bdlb=array(
"等级积分" => "scoreincr",
"管理员" => "manager",
"龙王争霸" => "dragon",
"屠龙" => "dragonkiller"
);
$type=$bdlb[$type];
$url="https://qun.qq.com/active/rank/list?gc=".$group."&type=".$type."&_wwv=128&_wv=16777218";
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","user-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/045814 Mobile Safari/537.36 V1_AND_SQ_8.8.28_2092_YYB_D A_8082800 QQ/8.8.28.6155 NetType/4G WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1000 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0");
$data=null;
$data=curl($url,$data,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
if($Dat=="json"){
print_r($data);
}else{
$data=$json["rankDetail"]["userInfo"]["users"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }

echo ($key+1).":".$value["name"]."-".$value["uin"]."\n";
echo "积分:".$value["score"]."\n";

}
}
