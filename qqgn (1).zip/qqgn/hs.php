<?php
function get_result($url,$data,$header)
{
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,$url);
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
curl_setopt($curl,CURLOPT_TIMEOUT,30);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,FALSE);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,FALSE);
curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
$return=curl_exec($curl);
curl_close($curl);
return $return;
}
function getSubstr($str, $leftStr, $rightStr)
{
    $left = strpos($str, $leftStr);
    //echo '左边:'.$left;
    $right = strpos($str, $rightStr,$left);
    //echo '<br>右边:'.$right;
    if($left < 0 or $right < $left) return '';
    return substr($str, $left + strlen($leftStr), $right-$left-strlen($leftStr));
}

function  get_msg($str, $start_str, $stop_str, $count, $n) {
    $n1=round($n- 1);
    $start=$n1;  //从第n个位置开始查找
    $data=array();
    for($i=0;$i<$count;$i++){
		 $start=strpos($str,$start_str,$start);
		 $stop=strpos($str,$stop_str,$start);
		 $start=strlen($start_str)+$start;
		 $data[$i]= substr($str,$start,$stop-$start);
		 $start=$stop;
	}
    $name = json_encode($data);
    $str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $name);
    return $str;
}

function replace_unicode_escape_sequence($match) {
  return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
}


function myCurl($url){
    $ch = curl_init();     // Curl 初始化
    $timeout = 30;     // 超时时间：30s
    
    $ua='picasso,222,androidesk';    // 伪造抓取 UA
    // $header = array('X-FORWARDED-FOR:'.$ip, 'CLIENT-IP:'.$ip);
    curl_setopt($ch, CURLOPT_URL, $url);              // 设置 Curl 目标
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);      // Curl 请求有返回的值
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);     // 设置抓取超时时间
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);        // 跟踪重定向
    curl_setopt($ch, CURLOPT_ENCODING, "");    // 设置编码
    curl_setopt($ch, CURLOPT_REFERER, $url);   // 伪造来源网址
    // curl_setopt($ch, CURLOPT_HTTPHEADER, $header);  //伪造IP
    curl_setopt($ch, CURLOPT_USERAGENT, $ua);   // 伪造ua
    curl_setopt($ch, CURLOPT_ENCODING, 'gzip'); // 取消gzip压缩
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // https请求 不验证证书和hosts
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    $content = curl_exec($ch);
    curl_close($ch);    // 结束 Curl
    return $content;    // 函数返回内容
}

function jsonjx($data){
$data=json_encode($data);
$str = preg_replace_callback('/\\\\u([0-9a-f]{4})/i', 'replace_unicode_escape_sequence', $data);
$str=str_replace("\/",'/',$str);


return $str;
}

function GetBkn($skey) {
	$hash = 5381;
	for ($i = 0, $len = strlen($skey); $i < $len; ++$i) {
		$hash +=($hash << 5) + charCodeAt($skey, $i);
	}
	return $hash & 2147483647;
}
function GetGTK($skey) {
	$len = strlen($skey);
	$hash = 5381;
	for ($i = 0; $i < $len; $i++) {
		$hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
		$hash &= 2147483647;
	}
	return $hash & 2147483647;
}
function Get_BKN($skey) {
	$len=strlen($skey);
	$hash=5381;
	for ($i=0;$i<$len;$i++) {
		$hash+=((($hash<<5) & 0x7fffffff)+ord($skey[$i])) & 0x7fffffff;
		$hash&=0x7fffffff;
	}
	return $hash & 0x7fffffff;
}

function RanText($pat)
{
$path=dirname(__FILE__);
$file=file($path.$pat);
$arr=mt_rand(0,count($file)-1);
$content=trim($file[$arr]);
return $content;
}

function getip_user() {
if(empty($_SERVER["HTTP_CLIENT_IP"]) == false) {
$cip = $_SERVER["HTTP_CLIENT_IP"];
} else if(empty($_SERVER["HTTP_X_FORWARDED_FOR"]) == false) {
$cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} else if(empty($_SERVER["REMOTE_ADDR"]) == false) {
$cip = $_SERVER["REMOTE_ADDR"];
} else {
$cip = "";
}
preg_match("/[\d\.]{7,15}/", $cip, $cips);
$cip = isset($cips[0]) ? $cips[0] : "";
unset($cips);
return $cip;
}

function text($array,$two=false) {
if(!is_array($array)) {
return $array;
}
if($two) {
$array_data="[\n";
} else {
$array_data="/\n";
}
foreach($array as $k=>$v) {
if(is_array($v)) {
$array_data.="[".$k."]:".text($v,true)."\n";
} else {
if($two) {
$array_data.="[".$k."]:".$v."\n";
} else {
$array_data.="[".$k."]:".$v."\n";
}
}
}
if($two) {
$array_data.="]";
} else {
$array_data.="/";
}
return $array_data;
}


function xml($data, $root = true){
$str="";
if($root)$str .= "<xml>";
foreach($data as $key => $val){
if(is_array($val)){
$child = xml($val, false);
$str .= "<$key>$child</$key>";
}else{
$str.= "<$key>$val</$key>";
}
}
if($root)$str .= "</xml>";
return $str;
}

function Back($array=array())
{
$type=$_REQUEST["format"]?:"json";
switch($type)
{
case "json":
header('Content-type: application/json');
echo stripslashes(json_encode($array,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
break;
case "text":
header('Content-Type: text/html; charset=utf-8');
echo text($array);
break;
case "xml":
header("Content-type: text/xml");
echo xml($array);
break;
}
}

function curl($url,$data=0,$header_array=0,$referer=0,$time=30,$code=0) {
if($header_array==0) {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user(),'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.106 Safari/537.36');
} else {
$header=array("CLIENT-IP: ".getip_user(),"X-FORWARDED-FOR: ".getip_user());
$header=array_merge($header_array,$header);
}
//print_r($header);
$curl=curl_init();
curl_setopt($curl,CURLOPT_URL,$url);
curl_setopt($curl,CURLOPT_HTTPHEADER,$header);
if($data) {
curl_setopt($curl,CURLOPT_POST,1);
curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
}
if($referer) {
curl_setopt($curl,CURLOPT_REFERER,$referer);
}
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 3); //设置等待时间
curl_setopt($curl,CURLOPT_TIMEOUT,$time);
curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
curl_setopt($curl,CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl,CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($curl,CURLOPT_ENCODING,'gzip,deflate');
if($code) {
curl_setopt($curl, CURLOPT_HEADER, 1);
$return=curl_exec($curl);
$code_code=curl_getinfo($curl);
curl_close($curl);
$code_int['exec']=substr($return,$code_code["header_size"]);
$code_int['code']=$code_code["http_code"];
$code_int['content_type']=$code_code["content_type"];
$code_int['header']=substr($return,0,$code_code["header_size"]);
return $code_int;
} else {
$return=curl_exec($curl);
curl_close($curl);
return $return;
}
}
