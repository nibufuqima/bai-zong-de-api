<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
// header
header("Content-Type:application/json");
error_reporting(E_ALL^E_NOTICE^E_WARNING);

// 获取扣扣号
$qq = $_GET["qq"];

// 过滤
if (trim(empty($qq))) {
        echo json_encode(array('status' => 'error','msg' => '未传入扣扣号'),JSON_UNESCAPED_UNICODE);
}else{
        // 获取QQ用户信息
        $urlPre='http://r.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg?g_tk=1518561325&uins=';
        $data=file_get_contents($urlPre.$qq);
        $data=iconv("GB2312","UTF-8",$data);
        $pattern = '/portraitCallBack\((.*)\)/is';
        preg_match($pattern,$data,$result);
        $result=$result[1];
        $qqnickname = json_decode($result, true)["$qq"][6];
        $qqheadimg = "http://q1.qlogo.cn/g?b=qq&nk=".$qq."&s=100&t=1547904810";

        // 开始判断这个扣扣号是不是有真实用户信息返回
        echo $qqnickname;


}
?>