<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$url=$_REQUEST["url"];
header('content-type:image/jpg;');
$content=file_get_contents("https://qun.qq.com/qrcode/index?data=".$url);
echo $content;
