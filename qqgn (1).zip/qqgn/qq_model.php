<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_GET['uin'];
$skey=$_GET['skey'];
$pskey=$_GET['pskey'];
$msg=$_GET['msg'];
$imei=$_GET['imei'];
$identifier=$_GET['identifier']?:"f389b4c384052cb7";
$get=getGTK($pskey);
$url="https://club.vip.qq.com/srf-cgi-node?srfname=VIP.CustomOnlineStatusServer.CustomOnlineStatusObj.SetCustomOnlineStatus&ts=1666406197770&daid=18&g_tk=".$get."";
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey.";  p_skey=".$pskey.";","Host: club.vip.qq.com","Connection: keep-alive","Accept: application/json, text/plain, */*","User-Agent: Mozilla/5.0 (Linux; Android 12; Redmi K30 Build/SKQ1.210908.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/046209 Mobile Safari/537.36 V1_AND_SQ_8.9.10_3296_YYB_D A_8091000 QQ/8.9.10.9145 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1000 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537135921","Content-Type: application/json","Origin: https://club.vip.qq.com","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Accept-Encoding: gzip, deflate, br","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$data='{"servicesName":"VIP.CustomOnlineStatusServer.CustomOnlineStatusObj","cmd":"SetCustomOnlineStatus","args":[{"iAppType":3,"sIMei":"'.$identifier.'","sModel":"'.$msg.'","sDeviceInfo":"i='.$imei.'&imsi='.$imei.'&mac=02:00:00:00:00:00&m='.$msg.'&o=12&a=31&sd=0&c64=1&sc=1&p=1080*2261&aid='.$imei.'&f=Xiaomi&mm=5569&cf=1762&cc=8&qimei='.$imei.'&qimei36='.$imei.'&sharpP=0&n=wifi&support_xsj_live=true&client_mod=default","sVer":"8.9.10","sManu":"Xiaomi","lUin":'.$uin.',"bShowInfo":true,"sDesc":"","sModelShow":"'.$msg.'"}]}';
$data=curl($url,$data,$header);
$data=json_decode($data,true);
$data["tip"]="帮助文本\n修改机型#IMEI#在线文字#手机机型\n1.首先点右边→→→https://1105583577.urlshare.cn/\n 跳转QQ后点击设备信息后在根据自己机型来看下方教程\n1.IOS的IMEI怎么查看\n苹果的IMEI是从【msf_identifier】(取中间数据太长的话可以截图识别图中文字来复制粘贴哦！)\n2.安卓的IMEI怎么查看\n安卓的imei来自【qimei36】，imei1来自【identifier】(取中间数据太长的话可以截图识别图中文字来复制粘贴哦！\n".ym."/API/qqgn/imei.jpg)";
Back($data);