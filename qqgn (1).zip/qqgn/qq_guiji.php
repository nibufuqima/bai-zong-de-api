<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$qq=$_REQUEST['qq'];
$pskey=$_REQUEST['pskey'];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://ti.qq.com/qq20th?_wv=16777216&_wwv=132&ADTAG=act";
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36");
$json=curl($url,null,$header);
$json=curl($url,null,$header);
$json=curl($url,null,$header);
$url=getSubstr($json,"window.syncData = ","</script>");
$data=json_decode($url,true);
$time=date("Y年m月d日 H时i分s秒",$data["register_time"]);
$friend_count=$data["friend_count"];
$packet_count=$data["packet_count"];
$group_count=$data["group_count"];
$avatar_count=$data["avatar_count"];
$qq_lvl=$data["qq_lvl"];
$qq_days=$data["qq_days"];
$visit_count=$data["visit_count"];
$data="账号等级:".$qq_lvl."\n注册时间:".$time."\n注册天数:".$qq_days."天\n群组数量:".$group_count."个\n分组数量:".$packet_count."个\n好友数量:".$friend_count."个\n空间访问量:".$visit_count."\n这些年更换头像数:".$avatar_count."次";
print_r($data);
