<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$n=$_REQUEST["n"];
$type=$_REQUEST["type"];
$group=$_REQUEST["group"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://web.qun.qq.com/cgi-bin/sys_msg/getmsg?ver=5689&filter=0&ep=0";
$header=array("User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.5_1858_YYB_D A_8080500 QQ/8.8.5.5570 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data=curl($url,null,$header);
preg_match_all('/<dd seq=\"(.*?)\" type=\"(.*?)\" uin=\"(.*?)\" uin_enc=\"(.*?)\" qid_enc=\"(.*?)\" qid=\"(.*?)\" authKey=\"(.*?)\" qaid=\"(.*?)\"/',$data,$data1);
preg_match_all('/<li aria-label=\"(.*?)\" tabindex=\"1\">/',$data,$data2);
preg_match_all('/<span>(.*?)<\/span> <a class=/',$data,$data3);
preg_match_all('/<a class=\"(.*?)\" uin=\"(.*?)\" href=/',$data,$data4);
$data3=jsonjx($data3);
$data3=str_replace("已被","移出群",$data3);
$data3=json_decode($data3,true);
if($data3[1][$n - 1]=="申请加入群"){
$lx=1;}
if($data3[1][$n - 1]=="同意加入群"){
$lx=3;}
if($data3[1][$n - 1]=="邀请你加入群"){
$lx=2;}
if($data3[1][$n - 1]=="退出群"){
$lx=4;}
$seq=$_REQUEST["seq"]?:$data1[1][$n - 1];
$gc1=$data1[6][$n - 1];
$qq=$data1[3][$n - 1];
$Invite=$data4[2];
$status=$data3[1];
$key=array_search("群",$status);
array_splice($Invite,$key,0,$data1[3][$key]);
$Inviteuin=$Invite[$n - 1];
$s=count($data1[1]);
$se=$data1[1];
$gc=$data1[6];
$Information=$data2[1];
for($i=0;$i<$s;$i++)
{
$array=array('seq'=>$data1[1][$i],'uin'=>$data1[3][$i],'Inviteuin'=>$Invite[$i],'gc'=>$data1[6][$i],'Information'=>$data2[1][$i],'status'=>$status[$i]);
$ar[$i]=$array;
}
$Dat=$_REQUEST["data"];
if($n==null){
if($Dat=="json"){
print_r(jsonjx($ar));
}else{
foreach ($ar as $key => $value)
{
echo "账号:".$value["uin"]."\n";
echo "群号:".$value["gc"]."\n";
echo $value["Information"]."\n-----------------\n";
}}}else{
$header=array("Host: web.qun.qq.com","sec-fetch-mode: cors","origin: https://web.qun.qq.com","x-alt-referer: web.qun.qq.com","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045714 Mobile Safari/537.36 V1_AND_SQ_8.8.20_1976_YYB_D A_8082000 QQ/8.8.20.5865 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1047693 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0","content-type: application/x-www-form-urlencoded","accept: */*","x-requested-with: com.tencent.mobileqq","sec-fetch-site: same-origin","Referer: https://web.qun.qq.com/cgi-bin/sys_msg/getmsg?ver=5689&filter=0&ep=0","accept-encoding: gzip, deflate, br","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$url="https://web.qun.qq.com/cgi-bin/sys_msg/set_msgstate";
$dat="seq=".$seq."&t=".$lx."&gc=".$gc1."&cmd=".$type."&uin=".$qq."&ver=5689&from=2&flag=0&bkn=".GetBkn($skey);//1同意，2，拒绝，3忽略
$data=curl($url,$dat,$header);
print_r($data);

}
