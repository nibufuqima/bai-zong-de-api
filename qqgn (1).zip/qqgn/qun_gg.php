<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$type=$_REQUEST['n'];
$n=($type -1);
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://web.qun.qq.com/cgi-bin/announce/list_announce?bkn=".getGTK($skey);
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data="qid=".$group."&bkn=".getGTK($skey)."&ft=23&s=-1&n=50&i=1&ni=1";
$data=get_result($url,$data,$header);
$json=json_decode($data,true);
$data=$json["inst"];
$data1=$json["feeds"];
$s=count($data);
$s1=($s+1);
if($type==null){
foreach ($data as $key => $value){
echo ($key+1).":".substr($value["msg"]["text"],0,60)."…\n";
}
foreach ($data1 as $key => $value){
echo ($s1+$key).":".substr($value["msg"]["text"],0,60)."…\n";
}
}elseif($type!=null){
if($type<=$s1&&$data!=null){
$array=array('text'=>$data[$n]["msg"]["text"],'fid'=>$data[$n]["fid"]);
Back($array);
}else{
$array=array('text'=>$data1[$n - $s]["msg"]["text"],'fid'=>$data1[$n - $s]["fid"],'uin'=>$data1[$n - $s]["u"]);
Back($array);
}}


