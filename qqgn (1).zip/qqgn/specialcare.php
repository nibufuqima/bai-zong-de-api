<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$qq=$_REQUEST["qq"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_uin=o".$uin.";p_skey=".$pskey."","Accept: */*","User-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.120 Safari/537.36","Referer: https://user.qzone.qq.com/".$uin."/infocenter?via=toolbar","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/r.qzone.qq.com/cgi-bin/tfriend/specialcare_get.cgi?uin=".$uin."&do=3&fupdate=1&rd=0.3731543055937272&g_tk=".getGTK($skey)."&g_tk=".getGTK($skey);
$data=curl($url,$data,$header);
$data=str_replace('_Callback(','',$data);
$data=str_replace(');','',$data);
$json=json_decode($data,true);
$items_special=$json["data"]["items_special"];
$fans_count=$json["data"]["fans_count"][0]["fans_count"];
$used_count=$json["data"]["used_count"][0]["used_count"];
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
$array=array('关心列表'=>$items_special,'我关心的'=>$used_count,'关心我的'=>$fans_count);
print_r(jsonjx($array));
}