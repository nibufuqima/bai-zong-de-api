<?php
error_reporting(0);
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$list=file_get_contents("List.php");
$json=json_decode($list,true);
$uin=$_GET['uin'];
if(!$_GET['uin'] || !$_GET['skey'] || !$_GET['pskey'] || !$_GET['key']){
print_r('{"retcode":"-200","retmsg":"Parameter is incomplete! Parameters are required :uin,skey,pskey,key"}');
exit();
}
if($_GET['key']!=$json[$uin]){
print_r('{"retcode":"-200","retmsg":"KEY Not correct !Author :1242619315"}');
exit();
}
if(pd()=="1"){
print_r('{"retcode":"-200","retmsg":"Cookie Invalid!"}');
exit();
}
if($_GET['zflx']=="6"){
print_r('{"retcode":"-200","retmsg":"Transfer function is prohibited! "}');
exit();
}
$tenxun_url='http://1.15.64.7:520/tenxun_mqq_hb';//����Э���ַ//
$rns = 'uin='.$_GET['uin'].'&je='.$_GET['je'].'&sl='.$_GET['sl'].'&zf='.$_GET['zf'].'&pskey='.$_GET['pskey'].'&zfmm='.$_GET['zfmm'].'&jsdx='.$_GET['jsdx'].'&xxlx='.$_GET['xxlx'].'&zflx='.$_GET['zflx'].'&kqdx='.$_GET['kqdx'].'&hbpf='.$_GET['hbpf'];//���ò���//ֱ��һ��û����
$url=$tenxun_url.'?'.$rns;//���Ķ���ֱ�ӻ��
$json=file_get_contents($url);//��ȡjson
echo $json;//���


function pd(){
$get=getGTK($_GET['skey']);
$url="https://pay.qun.qq.com/cgi-bin/group_pay/good_feeds/query_lucky_gift_history";
$post='bkn='.$get.'&bu_type=0&begin_index=0&end_index=19&del_expired_gift=1';
$cookie='uin=o'.$_GET['uin'].'; skey='.$_GET['skey'];
$data=get_result($url,$post,$cookie);
preg_match_all('/ec":(.*?),/',$data,$ec);
$ec=$ec[1][0];
if($ec=="0")
{
return '0';
}
else
{
return '1';
}}
function get_result($url,$post,$cookie)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
$header = array();
//curl_setopt($ch,CURLOPT_POST,true);
//curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_COOKIE, $cookie);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3); //���õȴ�ʱ��
curl_setopt($ch, CURLOPT_TIMEOUT, 30); //����cURL����ִ�е������
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); 
curl_setopt($ch, CURLOPT_POST, 1); 
curl_setopt($ch, CURLOPT_HEADER, 0); 
curl_setopt($ch, CURLOPT_POSTFIELDS, $post); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$content = curl_exec($ch);
curl_close($ch);
return $content;
}

function getGTK($skey){
$len = strlen($skey);
$hash = 5381;
for ($i = 0; $i < $len; $i++) {
$hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
$hash &= 2147483647;
}
return $hash & 2147483647;
}
