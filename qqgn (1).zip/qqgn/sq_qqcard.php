<?php
echo 12;