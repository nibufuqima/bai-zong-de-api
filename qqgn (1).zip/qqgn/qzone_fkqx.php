<?php
//访客权限
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$max=$_REQUEST["max"]?:"10";
$type=$_REQUEST["type"]?:"1";
$lx=$_REQUEST["lx"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://user.qzone.qq.com/p/h5/webapp/json/bmp4th/bmp4thSet?=&g_tk=".getGTK($pskey);
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$bdlb=array(
"1" => "uin=".$uin."&map_kv.map_kv.visit_lst_right=0&bitmap_id=2&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2Fproxy%2Fdomain%2Fqzs.qq.com%2Fqzone%2Fv8%2Fpages%2Fsetting%2Fvisit_record_v8.html%3Fg_iframeUser%3D1",//所有人
"2" => "uin=".$uin."&map_kv.map_kv.visit_lst_right=1&bitmap_id=2&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2Fproxy%2Fdomain%2Fqzs.qq.com%2Fqzone%2Fv8%2Fpages%2Fsetting%2Fvisit_record_v8.html%3Fg_iframeUser%3D1",//好友
"3" => "uin=".$uin."&map_kv.map_kv.visit_lst_right=3&bitmap_id=2&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2Fproxy%2Fdomain%2Fqzs.qq.com%2Fqzone%2Fv8%2Fpages%2Fsetting%2Fvisit_record_v8.html%3Fg_iframeUser%3D1",//自己
);
$data=$bdlb[$type];
$data=curl($url,$data,$header);
print_r($data);


