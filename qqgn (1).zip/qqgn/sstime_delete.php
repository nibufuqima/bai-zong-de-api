<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$tid=$_REQUEST["tid"];
$time=$_REQUEST["time"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Host: user.qzone.qq.com");
$data="hostuin=".$uin."&tid=".$tid."&time=".$time."t1_source=1&code_version=1&format=fs&qzreferrer=https://user.qzone.qq.com/".$uin."/infocenter?via=toolbar";
$url="https://user.qzone.qq.com/proxy/domain/taotao.qzone.qq.com/cgi-bin/emotion_cgi_pubnow_timershuoshuo_v6?&g_tk=".getGTK($pskey);
$data=curl($url,$data,$header);
$data=getSubstr($data,'frameElement.callback(',');');
$json=json_decode($data,true);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
if($json["subcode"]=="0"){
echo "当前操作:删除定时说说成功!";
}else{
echo "当前操作:删除失败!";
}}
