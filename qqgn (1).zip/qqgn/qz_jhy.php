<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);

$uin = @$_REQUEST['uin']; //接收群号
header('Location:mqq://card/show_pslcard?src_type=internal&version=1&uin='.$uin.'&card_type=person&source=sharecard');
