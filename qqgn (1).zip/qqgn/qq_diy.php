<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$msg=$_REQUEST["msg"];
$id=$_REQUEST["id"]?:"2275";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$msg='{"diyText":"'.$msg.'"}';
$url="https://g.vip.qq.com/bubble/bubbleSetup?id=2275&platformId=2&uin=".$uin."&version=8.8.50.6735&diyText=".$msg."&format=jsonp&t=".msectime()."&g_tk=".getGTK($pskey)."&p_tk=".$pskey."&callback=jsonp1";
$header=array("Cookie: uin=o".$uin.";p_uin=o".$uin.";p_skey=".$pskey.";skey=".$skey."","Host: g.vip.qq.com","User-agent: Mozilla/5.0 (Linux; Android 10; HRY-AL00Ta Build/HONORHRY-AL00Ta; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.93 Mobile Safari/537.36 V1_AND_SQ_8.8.50_2324_YYB_D A_8085000 QQ/8.8.50.6735 NetType/WIFI WebP/0.4.1 Pixel/1080 StatusBarHeight/82 SimpleUISwitch/1 QQTheme/2920 InMagicWin/0 StudyMode/0 CurrentMode/1 CurrentFontScale/1.0","accept: */*","x-requested-with: com.tencent.mobileqq","sec-fetch-site: same-site","sec-fetch-mode: no-cors","sec-fetch-dest: script","Referer: https://zb.vip.qq.com/bubble/diy?_wv=16778243&_wvx=2","accept-encoding: gzip, deflate","accept-language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$json=curl($url,null,$header);
print_r(getSubstr($json,"jsonp1(",");"));
function msectime() {
    list($msec, $sec) = explode(' ', microtime());
    $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);
    
    return $msectime;
}
//2551~环游天空，2551~环游太空，2514~萌系虫虫，2516~折纸，2493~热气球，2494~忍者，2463~甜梦，2464~香甜西瓜，2465~小小动物，2428~火龙果，2427~海盗船，2426~传送门，2351~浪漫星云，2319~冰淇淋，2320~可爱小动物，2321~紫色梦幻，2232~简约金属，2237~低调华丽，2238~橙色魅力，2239~幻想之红，2240~清新绿色，2241~蓝色心情，2276~雨蛙呱呱，2275~颜文字，2274~天使之翼，2273~黑色蕾丝，2272~恶魔之翼，2271~纯白蕾丝