<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$type=$_REQUEST["type"];
$uin=$_REQUEST["uin"];
$pskey=$_REQUEST["pskey"];
$skey=$_REQUEST["skey"];
$group=$_REQUEST["group"];
$matchId=$_REQUEST["matchId"];
$roomId=$_REQUEST["roomId"];
$msg=$_REQUEST["msg"];
$max=$_REQUEST["max"]?:"10";
$n=$_REQUEST["n"];
$m=$_REQUEST["m"];
$gtk=getGTK($skey);
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; p_skey=".$pskey."; qq_locale_id=2052; domainid=73","User-Agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.12_1900_YYB_D QQ/8.8.12.5675 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1046369 InMagicWin/0 StudyMode/0");
if($type==open){//允许成员开启
$data='{"allowNonAdminStart":true,"groupId":'.$group.'}';
$url="https://ti.qq.com/watch_together/operate/change_settings?bkn=".GetBkn($skey);
$data=curl($url,$data,$header);
print_r($data);
}
if($type==close){//拒绝成员开启
$data='{"allowNonAdminStart":false,"groupId":'.$group.'}';
$url="https://ti.qq.com/watch_together/operate/change_settings?bkn=".GetBkn($skey);
$data=curl($url,$data,$header);
print_r($data);
}
if($type==stop){//关闭一起看
$data='{"groupId":'.$group.',"roomId":"'.$roomId.'"}';
$url="https://ti.qq.com/watch_together/operate/stop?bkn=".GetBkn($skey);
$data=curl($url,$data,$header);
print_r($data);
}
if($type=="list"&$msg==null){//一起看列表
print_r("游戏 动画\n直播 奥运");
}
if($type=="list"&$msg!=null&$n==null){//一起看列表
$bdlb=array(
"游戏" => "https://ti.qq.com/sportslive/game?group_id=".$group."&category_id=2&_wwv=128&_wv=2",
"动画" => "https://ti.qq.com/sportslive/cartoon?group_id=".$group."&category_id=8&_wwv=128&_wv=2",
"直播" => "https://ti.qq.com/sportslive/live?group_id=".$group."&category_id=10&_wwv=128&_wv=2",
"奥运" => "https://ti.qq.com/sportslive/olympic?group_id=".$group."&category_id=13&_wwv=128&_wv=2"
);
$url=$bdlb[$msg];
$data=curl($url,null,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
if($msg=="游戏"){
$data=$json["gameTypes"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["gameName"]."\n";
}
}elseif($msg=="动画"){
$data=$json["videoSeriesList"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["title"]."\n";

}

}elseif($msg=="直播"){
$data=$json["videoList"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["title"]."\n";
}

}elseif($msg=="奥运"){
$data=$json["videoSeriesList"];
foreach ($data as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["title"]."\n";

}
}}
if($type=="list"&$msg!=null&$n!=null){//一起看列表
$bdlb=array(
"游戏" => "https://ti.qq.com/sportslive/game?group_id=".$group."&category_id=2&_wwv=128&_wv=2",
"动画" => "https://ti.qq.com/sportslive/cartoon?group_id=".$group."&category_id=8&_wwv=128&_wv=2",
"直播" => "https://ti.qq.com/sportslive/live?group_id=".$group."&category_id=10&_wwv=128&_wv=2",
"奥运" => "https://ti.qq.com/sportslive/olympic?group_id=".$group."&category_id=13&_wwv=128&_wv=2"
);
$url=$bdlb[$msg];
$data=curl($url,null,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
if($msg=="游戏"){
$categoryId=$json["categoryId"];
$code=$json["gameTypes"][$n-1]["gameCode"];
$url="https://ti.qq.com/watch_together/page_info/get_video_list?bkn=".GetBkn($skey)."&categoryId=2&groupId=".$group."&gameCode=".$code."&pageSize=20&currentPage=1";
$data=curl($url,null,$header);
$json=json_decode($data,true);
foreach ($json["videoList"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["roomInfo"]["roomTitle"]."\n";//观看matchId

}
}elseif($msg=="动画"){
$categoryId=$json["categoryId"];
$seriesId=$json["videoSeriesList"][$n-1]["seriesId"];
$url="https://ti.qq.com/sportslive/authology?group_id=".$group."&category_id=".$categoryId."&seriesId=".$seriesId."&_wwv=128&_wv=2";
$left='__INITIAL_STATE__=';
$right='</script>';
$data=curl($url,null,$header);
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
foreach ($json["videoList"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["title"]."\n";//观看matchId

}
}elseif($msg=="直播"){
$url="https://ti.qq.com/sportslive/live?group_id=".$group."&category_id=10&_wwv=128&_wv=2";
$left='__INITIAL_STATE__=';
$right='</script>';
$data=curl($url,null,$header);
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
$matchId=$json["videoList"][$m-1]["matchId"];
print_r(start($group,$matchId,$header,$skey,$categoryId));}elseif($msg=="奥运"){
$categoryId=$json["categoryId"];
$seriesId=$json["videoSeriesList"][$n-1]["seriesId"];
$url="https://ti.qq.com/sportslive/authology?group_id=".$group."&category_id=".$categoryId."&seriesId=".$seriesId."&_wwv=128&_wv=2";
$left='__INITIAL_STATE__=';
$right='</script>';
$data=curl($url,null,$header);
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
foreach ($json["videoList"] as $key => $value)
{
if($key==$max){
        break; // 当 $k为$m时，终止循环
    }
echo ($key+1).":".$value["title"]."\n";//观看matchId

}
}
}
if($type=="start"&$n!=null&$m!=null&$msg!=null){//开启一起看
$bdlb=array(
"游戏" => "https://ti.qq.com/sportslive/game?group_id=".$group."&category_id=2&_wwv=128&_wv=2",
"动画" => "https://ti.qq.com/sportslive/cartoon?group_id=".$group."&category_id=8&_wwv=128&_wv=2",
"直播" => "https://ti.qq.com/sportslive/live?group_id=".$group."&category_id=10&_wwv=128&_wv=2",
"奥运" => "https://ti.qq.com/sportslive/olympic?group_id=".$group."&category_id=13&_wwv=128&_wv=2"
);
$url=$bdlb[$msg];
$data=curl($url,null,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
if($msg=="游戏"){
$categoryId=$json["categoryId"];
$code=$json["gameTypes"][$n-1]["gameCode"];
$url="https://ti.qq.com/watch_together/page_info/get_video_list?bkn=".GetBkn($skey)."&categoryId=2&groupId=".$group."&gameCode=".$code."&pageSize=20&currentPage=1";
$data=curl($url,null,$header);
$json=json_decode($data,true);
$matchId=$json["videoList"][$m-1]["matchId"];
print_r(start($group,$matchId,$header,$skey,$categoryId));}elseif($msg=="动画"){
$categoryId=$json["categoryId"];
$seriesId=$json["videoSeriesList"][$n-1]["seriesId"];
$url="https://ti.qq.com/sportslive/authology?group_id=".$group."&category_id=".$categoryId."&seriesId=".$seriesId."&_wwv=128&_wv=2";
$left='__INITIAL_STATE__=';
$right='</script>';
$data=curl($url,null,$header);
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
$matchId=$json["videoList"][$m-1]["matchId"];
print_r(start($group,$matchId,$header,$skey,$categoryId));}elseif($msg=="直播"){
$url="https://ti.qq.com/sportslive/live?group_id=".$group."&category_id=10&_wwv=128&_wv=2";
$left='__INITIAL_STATE__=';
$right='</script>';
$data=curl($url,null,$header);
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
$matchId=$json["videoList"][$m-1]["matchId"];
print_r(start($group,$matchId,$header,$skey,$categoryId));}elseif($msg=="奥运"){
$categoryId=$json["categoryId"];
$seriesId=$json["videoSeriesList"][$n-1]["seriesId"];
$url="https://ti.qq.com/sportslive/authology?group_id=".$group."&category_id=".$categoryId."&seriesId=".$seriesId."&_wwv=128&_wv=2";
$left='__INITIAL_STATE__=';
$right='</script>';
$data=curl($url,null,$header);
$data=getSubstr($data,$left,$right);
$json=json_decode($data,true);
$matchId=$json["videoList"][$m-1]["matchId"];
print_r(start($group,$matchId,$header,$skey,$categoryId));
}
}
function start($group,$matchId,$header,$skey,$categoryId){
$data='{"groupId":'.$group.',"categoryId":'.$categoryId.',"matchId":"'.$matchId.'"}';
$url="https://ti.qq.com/watch_together/operate/start_or_switch?bkn=".GetBkn($skey);
$data=curl($url,$data,$header);
return $data;
}