<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$start=$_REQUEST["allow"]?:"0";
$flag=$_REQUEST["flag"]?:"0";
$stop=$_REQUEST["stop"]?:"0";
$start_hour=$_REQUEST["start_hour"]?:"8";
$end_hour=$_REQUEST["stopend_hour"]?:"22";
$m=$_REQUEST["max"]?:"15";
$week_days=urlencode($_REQUEST["week_days"]?:'[1]');
$type=$_REQUEST["type"]?:"time";
$itemid=$_REQUEST["itemid"];
$uin=$_REQUEST["uin"];
$p_skey=$_REQUEST["pskey"];
$skey=$_REQUEST["skey"];
$group=$_REQUEST["group"];
$msg=$_REQUEST["msg"];
$n=$_REQUEST["n"];
$gtk=getGTK($skey);
$gpk=getGTK($p_skey);
if(!$uin || !$skey || !$p_skey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; p_skey=".$p_skey."; qq_locale_id=2052; domainid=73","Host: web.qun.qq.com","Connection: keep-alive","Accept: application/json","X-Requested-With: XMLHttpRequest","User-Agent: Mozilla/5.0 (Linux; Android 12; Redmi K30 Build/SKQ1.210908.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/98.0.4758.102 MQQBrowser/6.2 TBS/046337 Mobile Safari/537.36 V1_AND_SQ_8.9.28_3700_YYB_D QQ/8.9.28.10155 NetType/WIFI WebP/0.3.0 AppId/537147632 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/2031218 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AllowLandscape/false InMagicWin/0","Content-Type: application/x-www-form-urlencoded","Origin: https://web.qun.qq.com","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Accept-Encoding: gzip, deflate, br","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
//开启听歌
if($type=="set"&$n==1)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/set_media_state?t=0.5225180512240759&g_tk=".$gtk."&state=1&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
$W=$json["tips"];
print_r(code($C,$W));
}
//关闭听歌
if($type=="set"&$n==2)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/set_media_state?t=0.5225180512240759&g_tk=".$gtk."&state=0&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
$W=$json["tips"];
print_r(code($C,$W));
}
if($type=="task"&$n==1)//开启定时
{
$data="time_zone=8&start_hour=".$start_hour."&start_minutes=0&end_hour=".$end_hour."&end_minutes=0&repeat_type=0&gcode=".$group."&qua=V1_AND_SQ_8.9.28_3700_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8";
$data=curl("https://web.qun.qq.com/cgi-bin/media/set_schedule_play_task?t=0.030982191169576456&g_tk=".$gtk,$data,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
$W=$json["tips"];
//print_r($json);
print_r(code($C,$W));

}
//关闭定时
if($type=="task"&$n==2)
{
$data="gcode=".$group."&qua=V1_AND_SQ_8.9.28_3700_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8";
$data=curl("https://web.qun.qq.com/cgi-bin/media/close_schedule_play_task?t=0.030982191169576456&g_tk=".$gtk,$data,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
$W=$json["tips"];
print_r(code($C,$W));
}
if($type=="flag")//允许/拒绝成员开启，添加歌曲，保留列表
{
$data="allow_member_start=".$start."&allow_member_add=".$flag."&stop_save_songlist=".$stop."&gcode=".$group."&qua=V1_AND_SQ_8.9.28_3700_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8";
$data=curl("https://web.qun.qq.com/cgi-bin/media/set_aio_flag?t=0.2300103311773607&g_tk=".$gtk,$data,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
$W=$json["tips"];
print_r(code($C,$W));

}
if($type=="time")//无循环播放
{
$data="time_zone=8&start_hour=".$start_hour."&start_minutes=0&end_hour=".$end_hour."&end_minutes=0&repeat_type=0&gcode=".$group."&qua=V1_AND_SQ_8.9.28_3700_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8";
$data=curl("https://web.qun.qq.com/cgi-bin/media/set_schedule_play_task?t=0.45555224008434214&g_tk=".$gtk,$data,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
$W=$json["tips"];
print_r(code($C,$W));

}
if($type=="time1")//循环每天播放
{
$data="time_zone=8&start_hour=".$start_hour."&start_minutes=0&end_hour=".$end_hour."&end_minutes=0&repeat_type=1&week_days=%5B%5D&gcode=".$group."&qua=V1_AND_SQ_8.9.28_3700_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8";
$data=curl("https://web.qun.qq.com/cgi-bin/media/set_schedule_play_task?t=0.45555224008434214&g_tk=".$gtk,$data,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
$W=$json["tips"];
print_r(code($C,$W));

}
if($type=="time2")//循环每周播放
{
$data="time_zone=8&start_hour=".$start_hour."&start_minutes=0&end_hour=".$end_hour."&end_minutes=0&repeat_type=2&week_days=".$week_days."&gcode=".$group."&qua=V1_AND_SQ_8.9.28_3700_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8";

$data=curl("https://web.qun.qq.com/cgi-bin/media/set_schedule_play_task?t=0.45555224008434214&g_tk=".$gtk,$data,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
$W=$json["tips"];
print_r(code($C,$W));
}
//歌曲列表
if($type=="list")
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/get_music_list?t=0.23605343538908485&g_tk=".$gtk."&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);

$json=json_decode($data,true);
$C=$json["retcode"];
if($C==0)
{
foreach($json["result"]["song_list"] as $k=>$v)
{
echo ($k+1)."：".$v["song"]["bytes_name"]."-".$v["song"]["rpt_bytes_singer"][0]."\n";
}
}else if($C==100000)
{
echo jsonsj(1002,"Cookie已失效");
}else{
echo jsonsj(1004,"获取失败，未知错误".$C);
}
}
//听歌人数
if($type=="number")
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/get_member_list?t=0.09641726303614995&g_tk=".$gtk."&page=2&limit=20&gcode=".$group."&qua=V1_AND_SQ_8.9.28_3700_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
if($C==100000)
{
echo jsonsj(1002,"Cookie已失效");
}else{
print_r("当前听歌人数:".$json["result"]["total"]."人");
}
}
//搜索歌曲
if($type=="add"&$n==null)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/search_music?t=0.6535849364849067&g_tk=".$gtk."&keyword=".$msg."&page=1&limit=50&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
//print_r($json);
if($C==0)
{
foreach($json["result"]["song_list"] as $k=>$v)
{
if($k==$m){
        break; 
    }
echo ($k+1)."：".$v["name"]."--".$v["singer_list"][0]["name"]."\n";
}
}else if($C==100000)
{
echo jsonsj(1002,"Cookie已失效");
}else{
echo jsonsj(1004,"获取失败，未知错误".$C);
}
}
//添加歌曲
if($type=="add"&$n!=null)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/search_music?t=0.6535849364849067&g_tk=".$gtk."&keyword=".$msg."&page=1&limit=50&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
if($C==0)
{
$songdata=curl("https://web.qun.qq.com/cgi-bin/media/oper_music?t=0.27844544816923666&g_tk=".$grk,'oper_type=1&song_list=[{"song_id":"'.$json["result"]["song_list"][($n-1)]["songid"].'","name":"'.$json["result"]["song_list"][($n-1)]["name"].'","sub_title":"","singer_list":["'.$json["result"]["song_list"][($n-1)]["singer_list"][0]["name"].'"],"cover":"'.$json["result"]["song_list"][($n-1)]["pic"].'","duration":248,"has_added":0}]&gcode='.$group.'&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin='.$uin.'&format=json&inCharset=utf-8&outCharset=utf-8',$header);
$songjson=json_decode($songdata,true);
$songC=$songjson["retcode"];
if($songC==0)
{
echo "成功添加歌曲[".$json["result"]["song_list"][($n-1)]["name"]."]";
}else if($C==100000)
{
echo jsonsj(1002,"Cookie已失效");
}else{
echo jsonsj(1004,"获取失败，未知错误".$C);
}
}
}
//删除歌曲
if($type=="remove"&$n==null)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/get_music_list?t=0.23605343538908485&g_tk=".$gtk."&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
//print_r($json);
if($C==0)
{
foreach($json["result"]["song_list"] as $k=>$v)
{
$array[($k+1)]["songname"]=$v["song"]["bytes_name"];
$array[($k+1)]["singername"]=$v["song"]["rpt_bytes_singer"][0];
}
echo jsonsj(1001,$array);
}else if($C==100000)
{
echo jsonsj(1002,"Cookie已失效");
}else{
echo jsonsj(1004,"获取失败，未知错误".$C);
}
}
if($type=="remove"&$n!=null)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/get_music_list?t=0.23605343538908485&g_tk=".$gtk."&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
$msg='[{"song_id":"'.$json["result"]["song_list"][($n-1)]["song"]["str_song_id"].'","name":"'.$json["result"]["song_list"][($n-1)]["song"]["bytes_name"].'","sub_title":"","singer_list":["'.$json["result"]["song_list"][($n-1)]["song"]["rpt_bytes_singer"][0].'"],"cover":"'.$json["result"]["song_list"][($n-1)]["song"]["bytes_cover"].'","duration":248,"current":0,"is_invalid":0,"can_delete":1}]';
$json1='oper_type=2&song_list='.urlencode($msg).'&gcode='.$group.'&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin='.$uin.'&format=json&inCharset=utf-8&outCharset=utf-8';
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; p_skey=".$p_skey."; qq_locale_id=2052; domainid=73","Referer: https://web.qun.qq.com/qunmusic/index?uin=".$group."&uinType=1&showlrc=0&_wv=2&_wwv=128&isJoin=1&from=0&isNew=1");
$songdata=curl("https://web.qun.qq.com/cgi-bin/media/oper_music?t=0.2965655077708127&g_tk=".$gtk,$json1,$header);
$songjson=json_decode($songdata,true);
$songC=$songjson["retcode"];
if($songC==0)
{
echo "成功删除歌曲[".$json["result"]["song_list"][($n-1)]["song"]["bytes_name"]."]";
}else if($C==100000)
{
echo jsonsj(1002,"Cookie已失效");
}else{
echo jsonsj(1004,"获取失败，未知错误".$C);
}
}
//切换歌曲
if($type=="switch"&$n==null)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/get_music_list?t=0.23605343538908485&g_tk=".$gtk."&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
//print_r($json);
if($C==0)
{
foreach($json["result"]["song_list"] as $k=>$v)
{
$array[($k+1)]["songname"]=$v["song"]["bytes_name"];
$array[($k+1)]["singername"]=$v["song"]["rpt_bytes_singer"][0];
}
echo jsonsj(1001,$array);
}else if($C==100000)
{
echo jsonsj(1002,"Cookie已失效");
}else{
echo jsonsj(1004,"获取失败，未知错误".$C);
}
}
if($type=="switch"&$n!=null)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/get_music_list?t=0.23605343538908485&g_tk=".$gtk."&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);
$json=json_decode($data,true);
$C=$json["retcode"];
$songdata=curl("https://web.qun.qq.com/cgi-bin/media/play_next_song?t=0.5211076363362979&g_tk=".$gtk."&song_id=".$json["result"]["song_list"][($n-1)]["song"]["str_song_id"]."&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",null,$header);
$jsona=json_decode($songdata,true);
$songc=$jsona["retcode"];
if($songc==0)
{
echo "播放成功！";
}else{
echo jsonsj(1002,"切换失败，未知错误".$songc);
}
}
//切换播放模式
if($type=="setmode"&$n==3)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/set_play_mode?t=0.7881741714474337&g_tk=".$gtk,"play_mode=1&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",$header);
$json=json_decode($data,true);
$C=$json["retcode"];
if($C==0)
{
echo "成功切换[单曲循环]播放模式";
}else if($C==100000)
{
echo jsonsj(1002,"Cookie已失效");
}else{
echo jsonsj(1003,"切换失败，未知错误".$C);
}
}
if($type=="setmode"&$n==2)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/set_play_mode?t=0.7881741714474337&g_tk=".$gtk,"play_mode=2&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",$header);
$json=json_decode($data,true);
$C=$json["retcode"];
if($C==0)
{
echo "成功切换[顺序播放]播放模式";
}else if($C==100000)
{
echo jsonsj(1002,"Cookie已失效");
}else{
echo jsonsj(1003,"切换失败，未知错误".$C);
}
}
if($type=="setmode"&$n==1)
{
$data=curl("https://web.qun.qq.com/cgi-bin/media/set_play_mode?t=0.7881741714474337&g_tk=".$gtk,"play_mode=3&gcode=".$group."&qua=V1_AND_SQ_8.4.8_1492_YYB_D&uin=".$uin."&format=json&inCharset=utf-8&outCharset=utf-8",$header);
$json=json_decode($data,true);
$C=$json["retcode"];
if($C==0)
{
echo "成功切换[随机播放]播放模式";
}else if($C==100000)
{
echo jsonsj(1002,"Cookie已失效");
}else{
echo jsonsj(1003,"切换失败，未知错误".$C);
}
}

if($type=="theme"&$n==null)//听歌氛围
{
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; p_skey=".$p_skey.";","Host: zb.vip.qq.com","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045714 Mobile Safari/537.36 V1_AND_SQ_8.8.20_1976_YYB_D A_8082000 QQ/8.8.20.5865 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1047693 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0");
$data=curl("https://zb.vip.qq.com/v2/musicTheme?type=1&uin=".$group."&uinType=1&_wv=5123",null,$header);
$url=getSubstr($data,"window.syncData = ",";</script>");
$url=json_decode($url,true);
foreach($url["musicList"] as $k=>$v)
{
echo ($k+1)."：".$v["name"]."(".$v["itemId"].")\n";
}

}
if($type=="bfq"&$n==null)//听歌播放器
{
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; p_skey=".$p_skey.";","Host: zb.vip.qq.com","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045714 Mobile Safari/537.36 V1_AND_SQ_8.8.20_1976_YYB_D A_8082000 QQ/8.8.20.5865 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1047693 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0");
$data=curl("https://zb.vip.qq.com/v2/musicTheme?type=2&uin=".$group."&uinType=1&_wv=5123",null,$header);
$url=getSubstr($data,"window.syncData = ",";</script>");
$url=json_decode($url,true);
foreach($url["musicList"] as $k=>$v)
{
echo ($k+1)."：".$v["name"]."(".$v["itemId"].")\n";
}

}
if($type=="bfq"&$n!=null)//播放器
{
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; p_skey=".$p_skey.";","Host: zb.vip.qq.com","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045714 Mobile Safari/537.36 V1_AND_SQ_8.8.20_1976_YYB_D A_8082000 QQ/8.8.20.5865 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1047693 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0");
$data=curl("https://zb.vip.qq.com/v2/musicTheme?type=2&uin=".$group."&uinType=1&_wv=5123",null,$header);
$url=getSubstr($data,"window.syncData = ",";</script>");
$url=json_decode($url,true);
$itemid=$url["musicList"][$n - 1]["itemId"];
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; p_skey=".$p_skey.";");
$data='{"stLogin":{"iKeyType":1,"iOpplat":2,"lUin":'.$uin.',"sClientIp":"","sClientVer":"8.8.20","sSKey":"'.$skey.'"},"stHamletItem":{},"stUniBusinessItem":{"appid":39,"itemid":'.$itemid.'}}';
$url="https://zb.vip.qq.com/srf/QC_UniBusinessLogicServer_UniBusinessLogicObj/uniSet?g_tk=".$gpk;
$dat=curl($url,$data,$header);
$json=json_decode($dat,true);
$C=$json["retcode"];
print_r($dat);
}
if($type=="theme"&$n!=null)//氛围
{
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; p_skey=".$p_skey.";","Host: zb.vip.qq.com","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045714 Mobile Safari/537.36 V1_AND_SQ_8.8.20_1976_YYB_D A_8082000 QQ/8.8.20.5865 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1047693 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0");
$data=curl("https://zb.vip.qq.com/v2/musicTheme?type=1&uin=".$group."&uinType=1&_wv=5123",null,$header);
$url=getSubstr($data,"window.syncData = ",";</script>");
$url=json_decode($url,true);
$itemid=$url["musicList"][$n - 1]["itemId"];
$header=array("Cookie: p_uin=o".$uin."; uin=o".$uin."; skey=".$skey."; p_skey=".$p_skey.";");
$data='{"stLogin":{"iKeyType":1,"iOpplat":2,"lUin":'.$uin.',"sClientIp":"","sClientVer":"8.8.20","sSKey":"'.$skey.'"},"stHamletItem":{"itemlist":[{"appid":38,"itemid":'.$itemid.'}],"locationtype":3,"uid":'.$group.'},"stUniBusinessItem":{"appid":38,"itemid":'.$itemid.'}}';
$url="https://zb.vip.qq.com/srf/QC_UniBusinessLogicServer_UniBusinessLogicObj/uniSet?g_tk=".$gpk;
$dat=curl($url,$data,$header);
$json=json_decode($dat,true);
$C=$json["retcode"];
print_r($dat);
}


function jsonsj($msg,$data) {
$array=array($msg=>$data);
return jsonjx($array);
}

function code($C,$W) {
if($C==0)
{
return "success!";
}else if($C==100000)
{
return "Cookie已失效";
}else if($C==100061)
{
return "已是当前状态!";
}else{
return "执行失败，错误:".$W;
}
}

