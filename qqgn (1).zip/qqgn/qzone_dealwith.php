<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$n=$_REQUEST["n"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$max=$_REQUEST["max"]?:"10";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_uin=o".$uin.";p_skey=".$pskey."","Host: user.qzone.qq.com");
$url="https://user.qzone.qq.com/proxy/domain/r.qzone.qq.com/cgi-bin/tfriend/getfriendmsglist.cgi?uin=".$uin."&fupdate=1&rd=&version=8&g_tk=".getGTK($pskey)."&g_tk=".getGTK($pskey);
$data=curl($url,null,$header);
$data=str_replace('_Callback(','',$data);
$data=str_replace(');','',$data);
$data=str_replace('0x0','"0x0"',$data);
$json=json_decode($data,true);
$qq=$json["data"]["items"][$n -1]["uin"];
$name=$json["data"]["items"][$n -1]["name"];
$time=$json["data"]["items"][$n -1]["time"];
/*$url="https://user.qzone.qq.com/proxy/domain/w.qzone.qq.com/cgi-bin/tfriend/procfriendreq.cgi?=&g_tk=".getGTK($pskey);
$dat="uin=".$uin."&ouin=".$qq."&flag=100&key=".$qq."&msgTime=".$time."&type=1&groupId=0&from_source=11&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F".$uin."%2Fmyhome%2Ffriends%2Fcenter";*/
$data=curl("https://user.qzone.qq.com/proxy/domain/w.qzone.qq.com/cgi-bin/tfriend/procfriendreq.cgi?=&g_tk=1172269355","uin=1242619315&ouin=2985490393&flag=100&key=2985490393&msgTime=1630309562&type=1&groupId=0&from_source=11&qzreferrer=https%3A%2F%2Fuser.qzone.qq.com%2F1242619315%2Fmyhome%2Ffriends%2Fcenter",$header);
$data=getSubstr($data,'frameElement.callback(',');');
print_r($data);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{

}

