<?php
$uin=$_REQUEST['uin'];
$skey=$_REQUEST['skey'];
file_put_contents("data/".$uin.".json",$skey);

print_r($uin);