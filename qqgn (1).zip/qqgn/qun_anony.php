<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$group=$_REQUEST["group"];
$uin=$_REQUEST["uin"];
$value=$_REQUEST["value"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.5_1858_YYB_D A_8080500 QQ/8.8.5.5570 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1046369 InMagicWin/0 StudyMode/0","Referer: https://qinfo.clt.qq.com/qinfo_v3/setting.html?groupuin=".$group."");
$url="https://qqweb.qq.com/c/anonymoustalk/set_anony_switch";
$data='value='.$value.'&group_code='.$group.'&src=qinfo_v3&bkn='.GetBkn($skey);
//src=qinfo_v3&bkn=1090087568&value=1&group_code=599348102
$data=curl($url,$data,$header);
$json=json_decode($data,true);
print_r($data);



