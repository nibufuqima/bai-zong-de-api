<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$txt=$_REQUEST["txt"];
$msg=$_REQUEST["msg"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$url="https://admin.qun.qq.com/cgi-bin/qun_admin/create_group";
$header=array("Host: admin.qun.qq.com","Connection: keep-alive","User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36","Content-type: application/x-www-form-urlencoded","Accept: */*","Origin: https://admin.qun.qq.com","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Referer: https://admin.qun.qq.com/create/index.html","Accept-Encoding: gzip, deflate, br","Accept-Language: zh-CN,zh;q=0.9","Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; traceid=6055258e30; pgv_info=ssid=s9222110930; pgv_pvid=3638706782");
$data="gn=".$msg."&memo=&rmemo=&gCls=10023&gClsTxt=".$txt."&t=1&flag=0&v=2&ct=1&s=0&open=1&speak=0&mn=0&m=&bkn=".GetBkn($skey);
$data=curl($url,$data,$header);
print_r($data);