<?php
header("Content-Type:text/html;charset=utf-8");//输出头
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$type=$_REQUEST['type']?:"信息条数";
$bdlb=array(
"信息条数" => "msgInfo",
"活跃人数" => "activeData",
"申请人数" => "applyData",
"退群人数" => "exitData",
"入群人数" => "joinData"
);
$type=$bdlb[$type];
$uin=$_REQUEST["uin"];
$lx=$_REQUEST["lx"];
$group=$_REQUEST["group"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qun.qq.com/m/qun/activedata/active.html?_wv=3&_wwv=128&gc=".$group."&src=2";
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Host: qun.qq.com",'Connection: keep-alive',"Upgrade-Insecure-Requests: 1",'User-Agent: Mozilla/5.0 (Linux; Android 12; Redmi K30 Build/SKQ1.210908.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/046011 Mobile Safari/537.36 V1_AND_SQ_8.8.88_2770_YYB_D A_8088800 QQ/8.8.88.7830 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537117930',"Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,image/sharpp,image/apng,image/tpg,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",'Sec-Fetch-Site: none',"Sec-Fetch-Mode: navigate",'Sec-Fetch-User: ?1',"Sec-Fetch-Dest: document",'Accept-Encoding: gzip, deflate, br',"Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7");
$return=curl($url,null,$header);
$left='__INITIAL_STATE__=';
$right='</script>';
$url=getSubstr($return,$left,$right);
$json=json_decode($url,true);
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($url);
}else{
Back($json[$type]);
}
