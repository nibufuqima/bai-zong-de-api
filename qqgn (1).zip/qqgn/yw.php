<?php
header("Content-Type:text/html;charset=UTF-8");//输出头
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$qq=$_GET['qq'];
$skey=$_GET['skey'];
if(!$qq || !$skey){
print_r("参数不完整!需要参数:qq，skey");
exit();
}
$url=file_get_contents("http://api.unipay.qq.com/v1/r/1450000172/wechat_query?cmd=7&session_id=uin&session_type=skey&openid=".$qq."&openkey=".$skey);
$json=json_decode($url,true);
if($json["ret"]=="0")
{
echo "查询账号".":".$qq."\n--------------\n";
//print_r($json);
foreach ($json["service"] as $key => $value)
{
echo pd($value["service_name"],$value["end_time"]);
echo pd2($value["service_name"],$value["end_time"]);
echo pd3($value["service_name"],$value["end_time"]);
if($value["upgrade_service_name"]!=null){
echo pd($value["upgrade_service_name"],$value["upgrade_end_time"]);
echo pd2($value["upgrade_service_name"],$value["upgrade_end_time"]);
echo pd3($value["upgrade_service_name"],$value["upgrade_end_time"]);
}
}
echo "一个热爱生活的男孩!";
}
else
{
echo "cookie已失效，请重新获取!";
}
function pd($name,$str){
date_default_timezone_set("PRC");
if(strtotime($str)>time()){
$time=date("Y-m-d H:i:s", time());
$finish_time=file_get_contents("http://".$_SERVER['HTTP_HOST']."/API/other/time1.php?start=".urlencode($time)."&end=".urlencode($str));
return "业务名称".":".$name."\n";
}else{
}}
function pd2($name,$str){
date_default_timezone_set("PRC");
if(strtotime($str)>time()){
$time=date("Y-m-d H:i:s", time());
$finish_time=file_get_contents("http://".$_SERVER['HTTP_HOST']."/API/other/time1.php?start=".urlencode($time)."&end=".urlencode($str));
return "到期时间".":".$str."\n";
}else{
}
}
function pd3($name,$str){
date_default_timezone_set("PRC");
if(strtotime($str)>time()){
$time=date("Y-m-d H:i:s", time());
$finish_time=file_get_contents("http://".$_SERVER['HTTP_HOST']."/API/other/time1.php?start=".urlencode($time)."&end=".urlencode($str));
return "剩余".":".$finish_time."\n--------------\n";
}else{
}}
   
?>