<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$group=$_REQUEST["group"];
$id=$_REQUEST["id"];
$uin=$_REQUEST["uin"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Host: qun.qq.com","sec-fetch-mode: cors","qname-service: 976321:131072","origin: https://qun.qq.com","User-agent: Mozilla/5.0 (Linux; Android 11; Redmi K30 Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045710 Mobile Safari/537.36 V1_AND_SQ_8.8.12_1900_YYB_D QQ/8.8.12.5675 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/96 SimpleUISwitch/0 QQTheme/1046369 InMagicWin/0 StudyMode/0","content-type: application/json;charset=UTF-8","accept: application/json, text/plain, */*","qname-space: Production","x-requested-with: com.tencent.mobileqq","sec-fetch-site: same-origin","Referer: https://qun.qq.com/v2/luckyword/index?qunid=".$group."&_wv=67108865&_nav_txtclr=FFFFFF&_wvSb=0&source=enter");
$url="https://qun.qq.com/v2/luckyword/proxy/domain/qun.qq.com/cgi-bin/group_lucky_word/equip?bkn=".GetBkn($skey);
$data='{"group_code":'.$group.',"word_id":"'.$id.'"}';
$data=curl($url,$data,$header);
$json=json_decode($data,true);
$code=$json["retcode"];
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
if($code=="0"){

print_r("当前操作:使用字符成功!");
}else
if($code=="11201"){

print_r("当前操作:已使用该字符!");
}else
if($code == "41"){
    echo 'Cookie失效，请重新获取！';
    exit();
}else
if($code == "10005"){
    echo '群信息获取错误';
    exit();
}else{
echo $code;
echo "\n";
echo $Msg;
//if(
}}


