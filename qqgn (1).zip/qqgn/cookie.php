<p></p><pre>
接口:QQCookie获取
请求示例
http://api.klizi.cn/API/qqgn/a/login.php?type=1&qrsig=
参数说明
参数	是否必填	参数类型	说明
类型	是	type	type为1获取二维码,2登录vip.qq.com,3登录qzone.qq.com,4登录qun.qq.com,5登录id.qq.com，6登录ti.qq.com,7登录huifu.qq.com,8登录docs.qq.com,9登录connect.qq.com,10登录graph.qq.com,11登录tenpay.com,12登录game.qq.com,13登录show.qq.com
qrsig	是	qrsig	验证登录且获取cookie
</pre>
