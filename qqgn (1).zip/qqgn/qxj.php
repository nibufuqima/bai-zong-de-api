<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST['skey'];
$uin=$_REQUEST['uin'];
$pskey=$_REQUEST['pskey'];
$group=$_REQUEST['group'];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey，group");
exit();
}
$url="https://qqweb.qq.com/c/activedata/get_credit_level_info?";
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Referer: https://qqweb.qq.com/m/business/qunlevel/index.html?gc=".$group."&from=0&_wv=1027");
$data="uin=".$uin."&gc=".$group."&bkn=".getGTK($skey);
$return=get_result($url,$data,$header);
$json=json_decode($return,true);
print_r(jsonjx($json));
