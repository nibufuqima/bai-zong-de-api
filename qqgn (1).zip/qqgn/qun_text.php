<?php
include("tj.php");
include("function.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
$type=$_REQUEST["type"];
$uin=$_REQUEST["uin"];
$pskey=$_REQUEST["pskey"];
$qq=$_REQUEST["qq"];
$skey=$_REQUEST["skey"];
$group=$_REQUEST["group"];
if($type=="1"){
$url="https://qun.qq.com/cgi-bin/qun_mgr/search_group_members?gc=".$group."&key=".$qq."st=0&end=30&sort=15&bkn=".getGTK($skey);
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ");
$data="bkn=".getGTK($skey)."&uin=".$uin."";
$return=curl($url,$data,$header);
$data=json_decode($return,true);
//date_default_timezone_set("PRC");
$time=date("Y-m-d H:i:s", time());
$join_time = date("Y-m-d H:i:s", $data["mems"][0]["join_time"]);
$last_speak_time = date("Y-m-d H:i:s", $data["mems"][0]["last_speak_time"]);
$finish_time=file_get_contents("http://".$_SERVER['HTTP_HOST']."/API/other/time1.php?start=".urlencode($join_time)."&end=".urlencode($time));
print_r("账号:".$data["mems"][0]["uin"]."\n群称:".$data["mems"][0]["card"]."\n昵称:".$data["mems"][0]["nick"]."\n群积分:".$data["mems"][0]["lv"]["point"]."\n群等级:".$data["mems"][0]["lv"]["level"]."\n入群时间:".$join_time."\n已入时间:".$finish_time."\n最后发言:".$last_speak_time);
}elseif($type=="2"){
$url1=curl("https://".$_SERVER['HTTP_HOST']."/API/qqgn/qxx.php?uin=".$uin."&skey=".$skey."&pskey=".$pskey."&group=".$group."&qq=".$qq);
$url1=json_decode($url1,true);
print_r("群号:".$url1["gc"]."\n群名:".$url1["gName"]."\n群主:".$url1["gOwner"]."\n当前人数:".$url1["gMemNum"]."\n最大人数:".$url1["gMaxMem"]."\n建群时间:".$url1["time"]."\n本群标签:".$url1["class"]."\n本群介绍:".$url1["gIntro"]);
}
?>