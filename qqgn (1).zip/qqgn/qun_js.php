<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$uin=$_REQUEST["uin"];
$group=$_REQUEST["group"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$header=array("Cookie: uin=o".$uin.";skey=".$skey.";p_skey=".$pskey.";p_uin=o".$uin.";ldw=".$ldw."","Accept: */*","User-Agent: Mozilla/5.0 (Linux; Android 6.0.1; OPPO R9s Plus Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36","Referer: https://id.qq.com/proxy.html","Connection: Keep-Alive","Charset: UTF-8","Accept-Encoding: gzip","Content-Type: application/x-www-form-urlencoded; charset=UTF-8","Host: id.qq.com");
$url="https://id.qq.com/qun/dismiss_group";
$data="vc=undefined&gc=".$group."&uin=".$uin."&s=1&bkn=".GetBkn($skey);
$data=curl($url,$data,$header);
$json=json_decode($data,true);
print_r($data);
