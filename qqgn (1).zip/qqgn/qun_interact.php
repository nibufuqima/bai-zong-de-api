<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$switch=$_REQUEST["switch"];
$uin=$_REQUEST["uin"];
$group=$_REQUEST["group"];
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
if(!$uin || !$skey || !$pskey || !$group){
print_r("参数不完整!需要参数:uin，skey，pskey,group");
exit();
}
$url="https://qinfo.clt.qq.com/cgi-bin/qun_info/set_honour_flag";
$header=array("Cookie: p_uin=".$uin."; p_skey=".$pskey."; uin=".$uin."; skey=".$skey."; ","Host: qinfo.clt.qq.com","Connection: keep-alive","User-Agent: Mozilla/5.0 (Linux; Android 12; Redmi K30 Build/SKQ1.210908.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.72 MQQBrowser/6.2 TBS/046029 Mobile Safari/537.36 V1_AND_SQ_8.8.93_2862_HDBM_T A_8089300 QQ/8.8.93.8060 NetType/WIFI WebP/0.3.0 Pixel/1080 StatusBarHeight/95 SimpleUISwitch/0 QQTheme/1103 InMagicWin/0 StudyMode/0 CurrentMode/0 CurrentFontScale/1.0 GlobalDensityScale/0.9818182 AppId/537121117","Content-Type: text/plain;charset=UTF-8","Accept: */*","Origin: https://qinfo.clt.qq.com","Sec-Fetch-Site: same-origin","Sec-Fetch-Mode: cors","Sec-Fetch-Dest: empty","Referer: https://qinfo.clt.qq.com/qlevel/setting.html?_wv=4&_bid=125","Accept-Encoding: gzip, deflate, br","Accept-Language: zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7","Q-UA2: QV=3&PL=ADR&PR=QQ&PP=com.tencent.mobileqq&PPVN=8.8.93&TBSVC=44196&CO=BK&COVC=046029&PB=GE&VE=GA&DE=PHONE&CHID=0&LCID=9422&MO=Unknown&RL=1080*2261&OS=12&API=31","Q-GUID: d8214e8260d8ba6283e3ba7813b788cb","q-header-ctrl: 3","Q-Auth: 31045b957cf33acf31e40be2f3e71c5217597676a9729f1b");
$data='gc='.$group.'&flag='.$switch.'&bkn='.GetBkn($skey).'&sid=';
$data=curl($url,$data,$header);
print_r($data);