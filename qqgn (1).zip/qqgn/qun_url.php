<?php
include("tj.php");
$base = str_replace('.php','',substr($_SERVER['PHP_SELF'],strripos($_SERVER['PHP_SELF'],"/")+1));
tongji($base);
include("function.php");
$skey=$_REQUEST["skey"];
$pskey=$_REQUEST["pskey"];
$uin=$_REQUEST["uin"];
$group=$_REQUEST["group"];
$num=$_REQUEST["num"]?:"1";
if(!$uin || !$skey || !$pskey){
print_r("参数不完整!需要参数:uin，skey，pskey");
exit();
}
$data="gc=".$group."&bkn=".GetBkn($skey);
$header=array("Cookie: uin=o".$uin."; p_uin=o".$uin."; skey=".$skey."; p_skey=".$pskey.";","Referer :https://qun.qq.com/proxy.html?callback=1&id=1");
$data=curl("https://qun.qq.com/proxy/domain/admin.qun.qq.com/cgi-bin/qun_admin/get_join_k",$data,$header);
$json=json_decode($data,true);
$ec=$json["ec"];
$Dat=$_REQUEST["data"];
if($Dat=="json"){
print_r($data);
}else{
if($ec==4)
{
print_r(jsonjx(array("code"=>-1,"error"=>"Logon information is invalid")));
}else if($ec==0)
{
print_r("https://qm.qq.com/cgi-bin/qm/qr?k=".$json["k"]."&jump_from=webapi&qr=1");
}}