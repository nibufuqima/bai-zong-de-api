<?php
error_reporting(0);
include("tongji.php");
$jk=$_REQUEST["jk"];
$type=$_REQUEST["type"];
$rq=$_REQUEST["rq"];
if($type==1){
Add_Transfer($jk);
}
if($type==2){
echo GetTransfer($jk);
}
if($type==3){
echo GetToday();
}
if($type==4){
GetTotalTransfer();
}
if($type==5){
GetWeekTransfer();
}



