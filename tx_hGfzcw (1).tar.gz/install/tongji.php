<?php

/*

数据库语句

CREATE TABLE `transfer` (
  `id` text NOT NULL COMMENT '接口ID',
  `date` text NOT NULL COMMENT '调用状况',
  `total` text NOT NULL COMMENT '总调用'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

*/
/* 
  服务器地址 用户名 密码 数据库名
*/
include("../inc/config.php");
$database_name=$dbconfig["database_name"];
$username=$dbconfig["username"];
$password=$dbconfig["password"];
$mysql=@new mysqli("localhost",$username,$password,$database_name);

function Add_Transfer($id)
{
$sql="SELECT * FROM `transfer` WHERE id = '".$id."'";
$data=$GLOBALS["mysql"]->query($sql);
if($data->num_rows==0)
{
$date=json_encode(array(date("Y-m-d")=>1));
$sql="INSERT INTO `transfer` (`id`, `date`, `total`) VALUES ('".$id."', '".$date."', '1')";
}else{
$info=$data->fetch_assoc();
$array=json_decode($info["date"],true);
if(!$array[date("Y-m-d")])
{
$array[date("Y-m-d")]=0;
}
foreach($array as $key=>$value)
{
if($key==date("Y-m-d"))
{
$arr[$key]=$value+1;
}else{
$arr[$key]=$value;
}
}
$arr=json_encode($arr);
$sql="UPDATE transfer SET date='".$arr."',total='".($info["total"]+1)."' WHERE id = '".$id."'";
}
$GLOBALS["mysql"]->query($sql);
}

function GetWeekTransfer()
{
$transfers1=0;
$transfers2=0;
$transfers3=0;
$transfers4=0;
$transfers5=0;
$transfers6=0;
$transfers7=0;
$data=$GLOBALS["mysql"]->query("SELECT * FROM `transfer`");
while($records=mysqli_fetch_array($data))
{
$apis[]=$records;
}
foreach($apis as $row)
{
$json=json_decode($row["date"],true);
$transfers1+=$json[date('Y-m-d')];//今天
$transfers2+=$json[date('Y-m-d',strtotime('-1 day'))];//昨天
$transfers3+=$json[date('Y-m-d',strtotime('-2 day'))];//前天
$transfers4+=$json[date('Y-m-d',strtotime('-3 day'))];//省略....
$transfers5+=$json[date('Y-m-d',strtotime('-4 day'))];
$transfers6+=$json[date('Y-m-d',strtotime('-5 day'))];
$transfers7+=$json[date('Y-m-d',strtotime('-6 day'))];
}
print_r(date('Y-m-d').":".$transfers1."\n");
print_r(date('Y-m-d',strtotime('-1 day')).":".$transfers2."\n");
print_r(date('Y-m-d',strtotime('-2 day')).":".$transfers3."\n");
print_r(date('Y-m-d',strtotime('-3 day')).":".$transfers4."\n");
print_r(date('Y-m-d',strtotime('-4 day')).":".$transfers5."\n");
print_r(date('Y-m-d',strtotime('-5 day')).":".$transfers6."\n");
print_r(date('Y-m-d',strtotime('-6 day')).":".$transfers7."\n");

}


function GetTotalTransfer()//查询全部调用
{
$data=$GLOBALS["mysql"]->query("SELECT * FROM `transfer`");
while($records=mysqli_fetch_array($data))
{
$apis[]=$records;
}
$total=0;
foreach($apis as $row)
{
$total+=$row["total"];//今天
}
print_r($total);

}

function GetTransfer($id)//查询单个文件的调用
{
$data=$GLOBALS["mysql"]->query("SELECT * FROM `transfer` WHERE id = '".$id."'");
$info=$data->fetch_assoc();
return $info["total"]?:0;
}


function GetToday()//查询当天总调用
{
$transfers1=0;
$data=$GLOBALS["mysql"]->query("SELECT * FROM `transfer`");
while($records=mysqli_fetch_array($data))
{
$apis[]=$records;
}
foreach($apis as $row)
{
$json=json_decode($row["date"],true);
$transfers1+=$json[date('Y-m-d')];//今天
}
return $transfers1;
}
