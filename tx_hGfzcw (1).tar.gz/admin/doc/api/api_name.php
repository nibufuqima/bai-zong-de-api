<?php
include '../../../inc/connect.php';
$datas = $db->select("api_list","name");
header('content-type:application/json');
echo json_encode($datas);