<?php
include '../../../inc/connect.php';
@$url = $_POST['url'];
@$name = $_POST['name'];
@$explain = $_POST['explain'];
@$request = $_POST['request'];
@$back = $_POST['back'];
@$description = $_POST['description'];
@$back_e = $_POST['back_e']?:"无";
@$code = $_POST['code']?:"无";
if($db->has("api_list", ["name"=>"$name"])){
    $arr =array('re'=>'0');
    header('content-type:application/json');
    echo json_encode($arr);
}else{
$data = array('url'=>"$url",'name'=>"$name",'details'=>"$explain",'request'=>"$request",'back'=>"$back",'example'=>"$description",'back_e'=>"$back_e",'code'=>"$code",'state'=>"正常");
$datas = $db->insert('api_list', $data);
$file = fopen("test.json","w") or exit("无法打开文件");
$data1 = json_encode($data);
fwrite($file,$data1);
fclose($file);
$arr =array('re'=>'1');
header('content-type:application/json');
echo json_encode($arr);
}