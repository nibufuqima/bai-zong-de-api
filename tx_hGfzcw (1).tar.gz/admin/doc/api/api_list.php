<?php
include '../../../inc/connect.php';
$datas = $db->select("api_list",['name','details','url','state']);
$count = count($datas);
$number = $db->count('api_list');
$normal = $db->count('api_list',["state"=>"正常"]);
$abnormal = $db->count('api_list',["state"=>"维护中"]);
$ym="http://".$_SERVER['HTTP_HOST']."";
$dysl=file_get_contents($ym."/inc/tongji1.php?type=4");
$jrdy=file_get_contents($ym."/inc/tongji1.php?type=3");
$datas=array_reverse($datas);
$arr = array('code'=>0,'msg'=>' ',"count"=>"$count",'data'=>$datas,'number'=>"$number",'normal'=>"$normal",'abnormal'=>"$abnormal","dysl"=>"$dysl","jrdy"=>"$jrdy");
header('content-type:application/json');
echo json_encode($arr);

