<?php
include '../../inc/connect.php';
@$field = $_POST['field'];
@$value = $_POST['value'];
@$id = $_POST['id'];
$data = array("$field"=>"$value");
$upda = $db->update("api_parameter",$data,['id'=>$id]);