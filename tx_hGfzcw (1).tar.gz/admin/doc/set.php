<?php
include '../../inc/connect.php';
$datas = $db->select("api_web","*");
header('content-type:application/json');
echo json_encode($datas);
$file = fopen("test.json","w") or exit("无法打开文件");
$data1 = json_encode($datas);
fwrite($file,$data1);
fclose($file);