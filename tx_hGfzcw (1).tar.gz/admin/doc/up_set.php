<?php
include '../../inc/connect.php';
@$title=$_POST['title'];
@$subtitle=$_POST['subtitle'];
@$logo=$_POST['logo'];
@$ico=$_POST['ico'];
@$keywords=$_POST['keywords'];
@$description=$_POST['description'];
@$notice=$_POST['notice'];
@$beian=$_POST['beian'];
$data = array('title'=>"$title",'subtitle'=>"$subtitle",'logo'=>"$logo",'ico'=>"$ico",'keywords'=>"$keywords",'description'=>"$description",'notice'=>"$notice",'beian'=>"$beian");
$upda = $db->update("api_web", $data,['id'=>1]);