<?php
include '../../../inc/connect.php';
@$name = $_POST['name'];
$datas = $db->delete('api_links',["AND" => ["name" =>"$name"]]);
$file = fopen("test.json","w") or exit("无法打开文件");
$data1 = json_encode($name);
fwrite($file,$data1);
fclose($file);