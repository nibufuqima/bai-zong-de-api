<?php
include '../../../inc/connect.php';
$datas = $db->select("api_links",['name','jian','url','time']);
$count = count($datas);
$arr = array('code'=>0,'msg'=>' ',"count"=>"$count",'data'=>$datas);
header('content-type:application/json');
echo json_encode($arr);