<?php
include '../../../inc/connect.php';
@$name=$_POST["link_name"];
@$url=$_POST["link_url"];
@$jian=$_POST["link_jian"];
@$tx=$_POST["link_tx"];
@$time=$_POST["link_time"];
if($db->has("api_links", ["name"=>"$name"])){
    $arr =array('re'=>'0');
    header('content-type:application/json');
    echo json_encode($arr);
}else{
$data=array("name"=>"$name","url"=>"$url","jian"=>"$jian","tx"=>"$tx","time"=>"$time");
$datas = $db->insert('api_links', $data);
$file = fopen("test.json","w") or exit("无法打开文件");
$data1 = json_encode($data);
fwrite($file,$data1);
fclose($file);
$arr =array('re'=>'1');
header('content-type:application/json');
echo json_encode($arr);
}