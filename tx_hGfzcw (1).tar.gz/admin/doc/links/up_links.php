<?php
include '../../../inc/connect.php';
@$name=$_POST["link_name"];
@$url=$_POST["link_url"];
@$jian=$_POST["link_jian"];
@$tx=$_POST["link_tx"];
@$time=$_POST["link_time"];
@$id=$_POST["id"];
$ide =$db->get("api_links","id", ["name"=>"$name"]);
if($db->has("api_links", ["name"=>"$name"])&&$id!==$ide){
    $arr =array('re'=>'0');
}else{
$data=array("name"=>"$name","url"=>"$url","jian"=>"$jian","tx"=>"$tx","time"=>"$time");
$upda = $db->update("api_links", $data,['id'=>$id]);
$arr =array('re'=>'1');
}
header('content-type:application/json');
echo json_encode($arr);