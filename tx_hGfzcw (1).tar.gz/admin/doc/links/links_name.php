<?php
$data = $_POST['name'];
$file = fopen("dataname.json","w") or exit("无法打开文件");
$data1 = json_encode($data);
fwrite($file,$data1);
fclose($file);