<?php
include '../../../inc/connect.php';
$string = file_get_contents("../links/dataname.json");
$name = json_decode($string, true);
$datas = $db->select("api_links","*",['name'=>$name]);
$arr = array('api'=>$datas);
header('content-type:application/json');
echo json_encode($arr);