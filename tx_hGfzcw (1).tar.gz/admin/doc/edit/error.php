<?php
include '../../../inc/connect.php';
$string = file_get_contents("../api/dataname.json");
$name = json_decode($string, true);
$datas = $db->select("api_list","*",['name'=>"$name"]);
$list_id = $datas[0]['id'];
$error = $db->select("api_parameter","*",['list_id'=>$list_id,'type'=>3]);
$arr = array('code'=>0,'msg'=>'ok','count'=>1000,'data'=>$error);
header('content-type:application/json');
echo json_encode($arr);