<?php
include '../../inc/connect.php';
@$url = $_POST['url'];
@$name = $_POST['name'];
@$explain = $_POST['explain'];
@$request = $_POST['request'];
@$back = $_POST['back'];
@$description = $_POST['description'];
@$back_e = $_POST['back_e'];
@$code = $_POST['code'];
@$state =$_POST['state'];
@$id = $_POST['id'];
$ide =$db->get("api_list","id", ["name"=>"$name"]);
if($db->has("api_list", ["name"=>"$name"])&&$id!==$ide){
    $arr =array('re'=>'0');
    header('content-type:application/json');
    echo json_encode($arr);
}else{
$data = array('url'=>"$url",'name'=>"$name",'details'=>"$explain",'request'=>"$request",'back'=>"$back",'example'=>"$description",'back_e'=>"$back_e",'code'=>"$code",'state'=>"$state");
$upda = $db->update("api_list", $data,['id'=>$id]);
$arr =array('re'=>'1');
header('content-type:application/json');
echo json_encode($arr);
}