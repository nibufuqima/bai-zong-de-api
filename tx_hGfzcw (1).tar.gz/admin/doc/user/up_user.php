<?php
include '../../../inc/connect.php';
include "../functions.php";
@$name = $_POST['admin_name'];
@$user = $_POST['admin_user'];
@$email = $_POST['admin_email'];
@$js=$_POST["admin_jian"];
@$passwds=$_POST["admin_passwd"];
$passwd = encrypt($passwds, 'E', 'a');
if($passwd==""){
    $data=array("name"=>"$name","user"=>"$user","email"=>"$email","js"=>"$js");
}else{
    $data=array("name"=>"$name","user"=>"$user","email"=>"$email","js"=>"$js","passwd"=>"$passwd");
}
$upda = $db->update("api_user",$data,['ID'=>1]);