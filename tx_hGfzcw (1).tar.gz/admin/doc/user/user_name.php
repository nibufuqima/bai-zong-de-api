<?php
include '../../../inc/connect.php';
$data = $db->select("api_user","name",["ID"=>1]);
$arr=array("code"=>0,"msg"=>"ok","name"=>$data[0]);
header('content-type:application/json');
echo json_encode($arr);