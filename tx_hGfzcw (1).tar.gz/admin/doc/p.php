<?php
$tgurl='https://sharechain.qq.com/81c262b46bd83e1d3524274b0994b4d9';
$wwwtext=get_url_content($tgurl);
function get_url_content($url){
    if(function_exists("curl_init")){
        $ch = curl_init();
        $timeout = 30;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $str = curl_exec($ch);
        curl_close($ch);
    }else{
        if(ini_get('allow_url_fopen')){$str = file_get_contents($url);}
    }
    return $str;
}
$str=$wwwtext;
//取head标签内容
preg_match("/<head>(.*)<\/head>/si",$str,$match);
echo $headstr = trim($match[1]);
//取body内容
preg_match("/<body.*?>(.*?)<\/body>/is", $str, $match1);
echo $bodystr = trim($match1[0]);
?>
