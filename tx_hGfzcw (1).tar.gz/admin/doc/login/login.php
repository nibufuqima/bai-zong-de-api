<?php
include '../../../inc/connect.php';
include '../functions.php';
$datas = $db->select("api_user",['user','passwd']);
$user = $datas[0]["user"];
$passwds = $datas[0]["passwd"];
$passwd =encrypt($passwds, 'D', 'a');
$token = encrypt($passwd, 'E', 'a');
$username = $_POST["username"];
$password = $_POST["password"];
$data =array("name"=>"$username","pass"=>"$password");
$file = fopen("test.json","w") or exit("无法打开文件");
$data1 = json_encode($data);
fwrite($file,$data1);
fclose($file);
if($user == $username && $passwd == $password){
    $arr = array('code'=>0,'msg'=>'',"re"=>1,"data"=>["access_token"=>"$token"]);
}
else{
    $arr = array('code'=>0,'msg'=>'',"re"=>0,"data"=>["access_token"=>""]);
}
header('content-type:application/json');
echo json_encode($arr);