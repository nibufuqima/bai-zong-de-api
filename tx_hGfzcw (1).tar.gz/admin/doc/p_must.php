<?php
include '../../inc/connect.php';
@$field = "p_must";
@$value = $_POST['value'];
@$id = $_POST['id'];
$data = array("$field"=>"$value");
$upda = $db->update("api_parameter",$data,['id'=>$id]);
$file = fopen("test.json","w") or exit("无法打开文件");
$data1 = json_encode($data);
fwrite($file,$data1);
fclose($file);