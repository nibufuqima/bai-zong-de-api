<?php
include '../../inc/connect.php';
@$name = $_POST['name'];
$id = $db->select("api_list","id",['name'=>"$name"]);
$list_id =$id[0];
$data = $db->delete('api_parameter',["AND" => ["list_id" =>$list_id]]);
$datas = $db->delete('api_list',["AND" => ["id" =>$list_id]]);