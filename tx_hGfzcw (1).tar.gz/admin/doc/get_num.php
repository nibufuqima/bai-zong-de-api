<?php
include '../../inc/connect.php';
$api_list=$db->count("api_list");
$ym="http://".$_SERVER['HTTP_HOST']."";
$dysl=file_get_contents($ym."/inc/tongji1.php?type=3");
$normal=$db->count("api_list",["state"=>"正常"]);
$abnormal=$db->count("api_list",["state"=>"维护中"]);
$links=$db->count("api_links");
$arr=array("api"=>"$api_list","links"=>"$links","abnormal"=>"$abnormal","normal"=>"$normal","dysl"=>"$dysl");
header('content-type:application/json');
echo json_encode($arr);