<?php
include '../../inc/connect.php';
@$name=$_POST["name"];
$list_ids=$db->select("api_list","id",["name"=>"$name"]);
$list_id = $list_ids[0];
@$p_name = $_POST["p_name"];
@$p_type = $_POST["p_type"];
@$p_must = $_POST["p_must"];
@$request= $_POST["request"];
@$type=$_POST["type"];
$data =array("list_id"=>"$list_id","p_name"=>"$p_name","p_type"=>"$p_type","p_must"=>"$p_must","type"=>"$type","p_explain"=>"$request");
$datas = $db->insert('api_parameter', $data);