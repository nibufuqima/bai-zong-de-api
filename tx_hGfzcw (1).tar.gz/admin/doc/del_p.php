<?php
include '../../inc/connect.php';
@$id = $_POST['id'];
$data = $db->delete('api_parameter',["AND" => ["id" =>$id]]);
$file = fopen("test.json","w") or exit("无法打开文件");
$data1 = json_encode($id);
fwrite($file,$data1);
fclose($file);