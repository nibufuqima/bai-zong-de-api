<?php
$old = 2.01;//当前版本号
// 获取网页内容
$data= file_get_contents('https://sharechain.qq.com/81c262b46bd83e1d3524274b0994b4d9');
$str=$data;
//取body内容
preg_match('/<span class="tit".*?>(.*?)<\/span>/is', $str, $match1);
$datas = trim($match1[0]);
// 获取｛｝里边的内容
preg_match("/{(.*)}/si",$datas,$match2);
$data2 = trim($match2[0]);
// 去除多余的符号
$data3 =str_replace('&quot;','',$data2);
$data4=str_replace('{','',$data3);
$data5=str_replace('}','',$data4);
// 分割成数组
$data6=explode("￥",$data5);
$arr =array("time"=>$data6[0],"banben"=>$data6[1],"url"=>$data6[2],'oldban'=>$old);
header('content-type:application/json');
echo json_encode($arr);