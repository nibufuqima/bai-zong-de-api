<?php
include 'inc/functions.php';
include "inc/common.php";
include "inc/model.php";

?>
<?php
for ($i=0; $i<=238; $i++)
{
$name=$list[$i]["name"];
$infos = $db->select("api_list","*",["name"=>"$name"]);
$info = $infos[0];
$list_id=$info["id"];
$re = $db->select("api_parameter","*",["list_id"=>"$list_id","type"=>1]);
preg_match_all('/\/(.*?).php/',$info["url"],$data1);
$name=$info['name'];
$enname=$data1[1][0];
$desc=$info['details'];
$url=$info['url'];
$example_url=$info['example'];
$format=$info['back'];
$method=$info['request'];
preg_match_all("/\[(.*?)-(.*?)-(.*?)-(.*?)\]/", str_replace('[---]','',data(json_encode($re))), $a, PREG_SET_ORDER);
$request=[];
		foreach ($a as $k => $v) {
			$request[] = [
				"name" => $v[1],
				"type" => $v[2],
				"required" => $v[3],
				"info" => $v[4],
			];
		}
		$request2 = [
			"data" => $request
		];
		$request_json = json_encode($request2, 320);
		if ($name && $enname && $desc && $url && $example_url&& $request_json) {
		$add_result = $db->query("INSERT INTO `mxgapi_api`(`name`, `enname`, `desc`, `url`, `format`, `method`, `example_url`, `request_parameter`) VALUES ('{$name}','{$enname}','{$desc}','{$url}','{$format}','{$method}','{$example_url}','{$request_json}')");
			if ($add_result) {
				print_r(1);
			} else {
				print_r(0);
			}

}
}



function data($data)
{
$data=json_decode($data,true);
foreach ($data as $key => $value)
{
$data3=$data3."[".$value["p_name"]."-".$value["p_type"]."-".str_replace('0','否',str_replace('1','是',$value["p_must"]))."-".$value["p_explain"]."]";
}
return $data3;
}
