<?php
include 'inc/functions.php';
include "inc/common.php";
include 'inc/model.php';
?>
<!doctype html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
		content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?php echo $model["title"]; ?></title>
    <meta name="Description" content="<?php echo $model["description"] ?>"/>
    <meta name="Keywords" content="<?php echo $model["keywords"]; ?>"/>
	<meta name="founder" content="<?php echo $model["title"] ?>">
	<link href="access/doc/other/css/site.min.css" rel="stylesheet">
	<link href="access/doc/other/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="access/doc/other/css/layui.css">
	<link href="https://cdn.bootcdn.net/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet">
	<script src="https://cdn.bootcdn.net/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
	<link href="access/doc/other/css/oneui.css" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo $model["ico"] ?>">
	<script src="access/doc/other/js/jquery.min.js"></script>
	<script src="access/doc/layui/layui.all.js"></script>
</script>
</head>
<body>
	<header class="site-header">
		<nav class="nav_jsxs">
		<span style="float: left;"><a class="logo_jsxs" href=""></a></span>
			<a href="../">首页</a>
			<a href="/tx">QQ类</a>
			<a href="/lt">反馈室</a>
			<a href="/link.php">友情链接</a>
		</nav>
		<div class="box-text">
			<h1><?php echo $model["title"] ?></h1>
			<p>稳定、快速、免费的 API 接口服务<br>
				<span class="package-amount">共收录了
					<strong> <?php
            $number = $db->count('api_list');
            echo $number;
            ?> </strong>个接口
				</span>
			</p>
			<!-- 搜索框 -->
			<div class="search-wraper" role="search">
				<div class="form-group">
					<input class="form-control search clearable" placeholder="搜索API如：一言" autocomplete="off" autofocus="" tabindex="0" autocorrect="off" autocapitalize="off" v-model='search' spellcheck="false" id="api-search" />
				</div>
			</div>
		</div>
		</div>
	</header>
	<section class="content content-boxed">
 <p class="p-jsxs">拒绝流量劫持，全面使用 HTTPS！</p>
  <div class="row row_jsxs" id="listApi">
<?php
$list=array_reverse($list);
foreach($list as $k=>$val){
echo '<div class="col-sm-4"><a target="_blank" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="doc.php?name='.$val["name"].'"><div class="ribbon-box font-w600">状态:'.$val["state"].'</div><div class="block-content">';
echo '<div class="h4 push-5">'.$val["name"].'</div><p class="text-muted text-truncate">'.$val["details"].'</p></div></a></div>';
}
            ?> 



  </div>
</section>
<section class="content content-boxed">
    <div class="row row_jsxs" id="listApi">
        <div class="col-sm-12">
            <div class="block block-link-hover2 ribbon ribbon-modern ribbon-success">
                <div class="block-content">
                    <p class="text-center" style="margin-bottom: 10px">
                        反馈或建议请
                        <a style="color:#01AAED; text-decoration: none;" target="_blank" href="https://jq.qq.com/?_wv=1027&k=hxoE6T4y">加入交流群</a>
                        或
                        <a style="color:#01AAED; text-decoration: none;" target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin={$qq}&amp;site=qq&amp;menu=yes">联系站长</a>
                    </p>
                    <p class="text-center" style="margin-bottom: 10px">
                        Copyright © 2021 <?php echo $model["title"]; ?> All Rights Reserved. <a style="color:#01AAED" href="https://beian.miit.gov.cn/" target="_blank">{$icp}</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<script>

/* 搜索框监听 */
$(function() {
    $("#api-search").bind('input propertychange', function() {
    ApiSearchLoad();
    });
});
/* 搜索事件 */
function ApiSearchLoad() {
    var search = $("#api-search").val();
    $.get('/tx/SearchApi.php?url=' + search.trim(),
   function(data, status) {
        var json = JSON.parse(data);
        var html = "";
        for (i = 0; i < json['data'].length; i++) {
            var status = json['data'][i]['state'];
            var name = json['data'][i]['name'];
            var info = json['data'][i]['details'];
            // 遍历获取并输出接口列表
          if (status == "维护中") {
                var href = "javascript:alert('该接口正在维护！');";
                var htmlH = '<div class="col-sm-4"><a target="_blank" class="block block-link-hover2 ribbon ribbon-modern ribbon-info" href="' + href + '"><div class="ribbon-box font-w600">维护中...</div><div class="block-content">';
            } else if (status == "正常") {
                var href = "doc.php?name=" + name;
                var htmlH = '<div class="col-sm-4"><a target="_blank" class="block block-link-hover2 ribbon ribbon-modern ribbon-success" href="' + href + '"><div class="ribbon-box font-w600">状态:'+status+'</div><div class="block-content">';
            }
            html += htmlH + '<div class="h4 push-5">' + name + '</div><p class="text-muted text-truncate">' + info + '</p></div></a></div>';
        }
        // 赋值
        $('#listApi').html(html);
    });
}
</script>
    <script>
var announce ='交流群:1021789873';
if(announce !=null | announce !='undefined' | announce !='')
{
swal("公告！",announce, "success");
}
</script>
</body>
</html>