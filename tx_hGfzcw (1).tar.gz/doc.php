<?php
include 'inc/functions.php';
include "inc/common.php";
include 'inc/model.php';
?>
<!doctype html>
<html lang="zh">

<head>
	<meta charset="UTF-8">
	<meta name="viewport"
		content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?php echo $model["title"]."-".$info["name"] ?></title>
    <meta name="Description" content="<?php echo $model["description"] ?>"/>
    <meta name="Keywords" content="<?php echo $model["keywords"]."-".$info["name"] ?>"/>
	<meta name="founder" content="<?php echo $model["title"] ?>">
	<link href="access/doc/other/css/site.min.css" rel="stylesheet">
	<link href="access/doc/other/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="access/doc/other/css/layui.css">
	<link href="https://cdn.bootcdn.net/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet">
	<script src="https://cdn.bootcdn.net/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
	<link href="access/doc/other/css/oneui.css" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo $model["ico"] ?>">
	<script src="access/doc/other/js/jquery.min.js"></script>
	<script src="access/doc/layui/layui.all.js"></script>
</script>
</head>

<body>
	<header class="site-header">
		<nav class="nav_jsxs">
			<span style="float: left;"><a class="logo_jsxs" href=""></a></span>
			<a href="../">首页</a>
			<a href="/link.php">友情链接</a>
		</nav>
		<div class="box-text">
			<h1><?php echo $model["title"] ?></h1>
			<p>稳定、快速、免费的 API 接口服务<br>
				<span class="package-amount">共收录了
					<strong> <?php
            $number = $db->count('api_list');
            echo $number;
            ?> </strong>个接口
				</span>
			</p>
		</div>
	</header>
<style>
	.url {
		word-break: break-all;
		cursor: pointer;
		margin-left: 5px;
		color: #777;
		border: none;
		border-radius: 0;
		border-bottom: 2px solid #5FB878;
	}

	.simpleTable {
		line-height: 20px;
		padding-bottom: 16px;
	}

	.linep {
		font-size: 14px;
		font-weight: 700;
		color: #555;
		padding-left: 14px;
		height: 16px;
		line-height: 16px;
		margin-bottom: 18px;
		position: relative;
		margin-top: 15px;
	}

	.linep:before {
		content: '';
		width: 4px;
		height: 16px;
		background: #00aeff;
		border-radius: 2px;
		position: absolute;
		left: 0;
		top: 0;
	}

	::-webkit-scrollbar {
		width: 9px;
		height: 9px
	}

	::-webkit-scrollbar-track-piece {
		background-color: #ebebeb;
		/* -webkit-border-radius: 4px */
	}

	::-webkit-scrollbar-thumb:vertical {
		height: 32px;
		background-color: #ccc;
		/* -webkit-border-radius: 4px */
	}

	::-webkit-scrollbar-thumb:horizontal {
		width: 32px;
		background-color: #ccc;
		/* -webkit-border-radius: 4px */
	}

	.layui-container {
		min-height: 273px;
	}
</style>
<div class="layui-container">
	<div class="layui-row">
		<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
			<legend><?php echo $info["name"]; ?></legend>
		</fieldset>
		<blockquote class="layui-elem-quote"><?php echo $info["details"]; ?></blockquote>
	</div>
	<div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
		<ul class="layui-tab-title" style="text-align: center!important;">
			<li class="layui-this">API文档</li>
			<li>错误码参照</li>
			<li>示例代码</li>

		</ul>
		<div class="layui-tab-content">
			<div class="layui-tab-item layui-show">
				<p class="simpleTable">
					<span class="layui-badge layui-bg-black">接口地址：</span>
					<span class="url" data-clipboard-text="<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["url"]; echo $url; ?>">
						<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["url"]; echo $url;
?>
					</span>
				</p>
				<p class="simpleTable">
					<span class="layui-badge layui-bg-green">返回格式：</span>
					<span class="url" data-clipboard-text="
					<?php echo $info["back"]; ?>
					">
						<?php echo $info["back"]; ?>
					</span>
				</p>
				<p class="simpleTable">
					<span class="layui-badge">请求方式：</span>
					<span class="url" data-clipboard-text="
					<?php echo $info["request"]; ?>
					">
						<?php echo $info["request"]; ?>
					</span>
				</p>
					<p class="simpleTable">
					<span class="layui-badge layui-bg-cyan">接口状态：</span>
					<span class="url" data-clipboard-text="
					<?php echo $info["state"]; ?>
					">
					<?php echo $info["state"]; ?>
					</span>
				</p>
				<p class="simpleTable">
					<span class="layui-badge layui-bg-blue">请求示例：</span>
					<span class="url" data-clipboard-text="<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["example"];
 echo $url; ?>">
<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["example"];
 echo $url; ?>					</span>
				</p>
<!--				<p class="simpleTable">
					<span class="layui-badge layui-bg-orange">上次修改：</span>
					<span class="url" data-clipboard-text="{$ApiData.time|date_format:'%Y-%m-%d %H:%M:%S'}">
						{$ApiData.time|date_format:'%Y-%m-%d %H:%M:%S'}
					</span>
				</p>-->

				<p class="linep">请求参数说明：</p>
				<table class="layui-table" lay-size="sm">
					<thead>
						<tr>
							<th>名称</th>
							<th>必填</th>
							<th>类型</th>
							<th>说明</th>
						</tr>
					</thead>
					<tbody>
                  <?php
                        if(empty($request)){
                            echo "<tr>";
                               echo "<td>NULL</td>";
                               echo "<td>NULL</td>";
                               echo "<td>NULL</td>";
                               echo "<td>NULL</td>";
                           echo "</tr>";
                           }else{
                    foreach($request as $k=>$val){
                        if($val['p_must']==1){
                            $p_must="是";
                        }else{
                            $p_must="否";
                        }
                        $p_name=$val['p_name'];
                        $p_type=$val['p_type'];
                        $p_explain=$val['p_explain'];

                         echo "<tr>";
                            echo "<td>$p_name</td>";
                            echo "<td>$p_must</td>";
                            echo "<td>$p_type</td>";
                            echo "<td>$p_explain</td>";
                        echo "</tr>";
                    }};
                    ?>
					</tbody>
				</table>
				<p class="linep">返回参数说明：</p>
				<table class="layui-table" lay-size="sm">
					<thead>
						<tr>
							<th>名称</th>
							<th>类型</th>
							<th>说明</th>
						</tr>
					</thead>
					<tbody>
                    <?php
                        if(empty($back)){
                            echo "<tr>";
                               echo "<td>NULL</td>";
                               echo "<td>NULL</td>";
                               echo "<td>NULL</td>";
                           echo "</tr>";
                           }else{
                    foreach($back as $k=>$val){
                        $p_name=$val['p_name'];
                        $p_type=$val['p_type'];
                        $p_explain=$val['p_explain'];

                         echo "<tr>";
                            echo "<td>$p_name</td>";
                            echo "<td>$p_type</td>";
                            echo "<td>$p_explain</td>";
                        echo "</tr>";
                    }};
                    ?>
                   </tbody>
				</table>
				<p class="linep">返回示例：</p>
				<pre class="layui-code"><?php
              /* $slhttp = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://'; 
                    if($info["back"]=="JSON"||$info["back"]=="text"){
                    print_r(file_get_contents($slhttp.$_SERVER['HTTP_HOST']."/".$info["example"]));
                    }else{
                    echo '<img src="'.$slhttp.$_SERVER['HTTP_HOST']."/".$info["example"].'">';
                    }
                 */   echo "自己测试吧！";
                    ?>
</pre>
			</div>
			<div class="layui-tab-item">
				<p class="linep">错误码格式说明：</p>
				<table class="layui-table" lay-size="sm">
					<thead>
						<tr>
							<th>名称</th>
							<th>类型</th>
							<th>说明</th>
						</tr>
					</thead>
					<tbody>
                  <?php
                        if(empty($error)){
                            echo "<tr>";
                               echo "<td>NULL</td>";
                               echo "<td>NULL</td>";
                               echo "<td>NULL</td>";
                           echo "</tr>";
                           }else{
                    foreach($error as $k=>$val){
                        $p_name=$val['p_name'];
                        $p_type=$val['p_type'];
                        $p_explain=$val['p_explain'];

                         echo "<tr>";
                            echo "<td>$p_name</td>";
                            echo "<td>$p_type</td>";
                            echo "<td>$p_explain</td>";
                        echo "</tr>";
                    }};
                    ?>
					</tbody>
				</table>
			</div>
			<div class="layui-tab-item">
				<p class="linep">PHP代码示例：</p>
				<pre class="layui-code" lay-title="Get请求"><Cpre><code>
$get="<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["example"];
 echo $url; ?>";
$result=file_get_contents($get);
if($result)
{
//请求成功
echo $result;
}else{
//请求失败
}</code></Cpre></pre>
				<pre class="layui-code" lay-title="Post请求"><Cpre><code>
$url='<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["url"]; echo $url;
?>';
$data=array(
<?php
                       if(empty($request)){
                           }else{
                    foreach($request as $k=>$val){
                        if($val['p_must']==1){
                            $p_must="是";
                        }else{
                            $p_must="否";
                        }
                        $p_name=$val['p_name'];
                        $p_type=$val['p_type'];
                        $p_explain=$val['p_explain'];
echo "".$p_type."=>".$p_explain.",\n";
                    }};
                    ?>
                    
);
$data=http_build_query($data);
$option =array('http'=>array('method'=>'POST','content'=>$data));
$context=stream_context_create($option);
$result=file_get_contents($url,false,$context);
if($result)
{
  //成功
  echo $result;
}else{
  //失败
}</code></Cpre></pre>
				<p class="linep">Java代码示例：</p>
				<pre class="layui-code" lay-title="Get请求"><Cpre><code>
String httpurl = "<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["example"];
 echo $url; ?>";
HttpURLConnection connection = null;
InputStream is = null;
BufferedReader br = null;
String result = null;
try {
URL url = new URL(httpurl);
connection = (HttpURLConnection) url.openConnection();
connection.setRequestMethod("GET");
connection.setConnectTimeout(15000);
connection.setReadTimeout(60000);
connection.connect();
if (connection.getResponseCode() == 200) {
is = connection.getInputStream();
br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
StringBuffer sbf = new StringBuffer();
String temp = null;
while ((temp = br.readLine()) != null) {
sbf.append(temp);
}
result = sbf.toString();
}
} catch (MalformedURLException e) {
e.printStackTrace();
} catch (IOException e) {
e.printStackTrace();
} finally {
if (null != br) {
try {
br.close();
} catch (IOException e) {
e.printStackTrace();
}
}
if (null != is) {
try {
is.close();
} catch (IOException e) {
e.printStackTrace();
}
}
connection.disconnect();
}
System.out.println(result);//返回内容</code></Cpre></pre>
<pre class="layui-code" lay-title="Post请求"><Cpre><code>
PrintWriter out = null;
BufferedReader in = null;
String result = "";
String param ="<?php
                       if(empty($request)){
                           }else{
                    foreach($request as $k=>$val){
                        if($val['p_must']==1){
                            $p_must="是";
                        }else{
                            $p_must="否";
                        }
                        $p_name=$val['p_name'];
                        $p_type=$val['p_type'];
                        $p_explain=$val['p_explain'];
echo "".$p_type."=".$p_explain."&";
                    }};
                    ?>";
String url ="<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["url"]; echo $url;
?>";
try {
URL realUrl = new URL(url);
URLConnection conn = realUrl.openConnection();
conn.setRequestProperty("accept", "*/*");
conn.setRequestProperty("connection", "Keep-Alive");
conn.setRequestProperty("user-agent","Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
conn.setDoOutput(true);
conn.setDoInput(true);
out = new PrintWriter(conn.getOutputStream());
out.print(param);
out.flush();
in = new BufferedReader(
new InputStreamReader(conn.getInputStream()));
String line;
while ((line = in.readLine()) != null) {
result += line;
}
} catch (Exception e) {
System.out.println("发送 POST 请求出现异常！"+e);
e.printStackTrace();
}
finally{
try{
if(out!=null){
out.close();
}
if(in!=null){
in.close();
}
}
catch(IOException ex){
ex.printStackTrace();
}
}
System.out.println(result);//返回内容</code></Cpre></pre>
				<p class="linep">JavaScript代码示例：</p>
				<pre class="layui-code" lay-title="Get请求"><Cpre><code>
var url = "<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["example"];
 echo $url; ?>"
var xhrGet = new XMLHttpRequest();
xhrGet.open('GET',url, true);
xhrGet.send();
xhrGet.onreadystatechange = function() {
if (xhrGet.readyState == 4 && xhrGet.status == 200) {
//成功
var result = xhrGet.responseText;
console.log(result);
} else {
//失败
}
}</code></Cpre></pre>
				<pre class="layui-code" lay-title="Post请求"><Cpre><code>
var url ="<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["url"]; echo $url;
?>";
var data = "<?php
                       if(empty($request)){
                           }else{
                    foreach($request as $k=>$val){
                        if($val['p_must']==1){
                            $p_must="是";
                        }else{
                            $p_must="否";
                        }
                        $p_name=$val['p_name'];
                        $p_type=$val['p_type'];
                        $p_explain=$val['p_explain'];
echo "".$p_type."=".$p_explain."&";
                    }};
                    ?>";
String url ="<?php $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
$url=$http_type.$_SERVER['HTTP_HOST']."/".$info["url"]; echo $url;
?>";
var xhrPost = new XMLHttpRequest();
xhrPost.open('POST', url, true);
xhrPost.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xhrPost.send(data);
xhrPost.onreadystatechange = function() {
if (xhrPost.readyState == 4 && xhrPost.status == 200) {
//成功
var result = xhrPost.responseText;
console.log(result);
} else {
//失败
}
}</code></Cpre></pre>
			</div>
		</div>
	</div>
</div>
		<script src="access/js/clipboard.min.js"></script>
<script>
	layui.use('code', function () { //加载code模块
		layui.code(); //引用code方法
	});
	var clipboard = new ClipboardJS('.url');
	clipboard.on('success', function (e) {
		layer.msg('复制成功!');
	});
	clipboard.on('error', function (e) {
		layer.msg('复制成功!');
	});
</script>
<section class="content content-boxed">
    <div class="row row_jsxs" id="listApi">
        <div class="col-sm-12">
            <div class="block block-link-hover2 ribbon ribbon-modern ribbon-success">
                <div class="block-content">
                    <p class="text-center" style="margin-bottom: 10px">
                        反馈或建议请
                        <a style="color:#01AAED; text-decoration: none;" target="_blank" href="https://jq.qq.com/?_wv=1027&k=sDvAAwpU">加入交流群</a>
                        或
                        <a style="color:#01AAED; text-decoration: none;" target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1242619315&amp;site=qq&amp;menu=yes">联系站长</a>
                    </p>
                    <p class="text-center" style="margin-bottom: 10px">
                        Copyright © 2021 小白API All Rights Reserved. <a style="color:#01AAED" href="https://beian.miit.gov.cn/" target="_blank">无</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
    <script>
var announce ='交流群:1021789873';
if(announce !=null | announce !='undefined' | announce !='')
{
swal("公告！",announce, "success");
}
</script>

</body>
</html>