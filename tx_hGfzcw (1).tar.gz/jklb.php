<?php
include 'inc/functions.php';
include "inc/common.php";
include "inc/model.php";

?>
<?php
$n=$_REQUEST['n'];
$type=$_REQUEST['type'];
$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
if($type==1){
$list=array_reverse($list);
$name=$list[$n-1]["name"];
$infos = $db->select("api_list","*",["name"=>"$name"]);
$info = $infos[0];
$list_id=$info["id"];
$request = $db->select("api_parameter","*",["list_id"=>"$list_id","type"=>1]);
$data="接口名称:".$info["name"]."\n接口地址:".$http_type.$_SERVER['HTTP_HOST']."/".$info["url"]."\n返回类型:".$info["back"]."\n请求示例:".$http_type.$_SERVER['HTTP_HOST']."/".$info["example"]."\n------请求参数------";
print_r($data);
foreach($request as $k=>$val){
    if($val['p_must']==1){
         $p_must="yes";
     }else{
         $p_must="no";
     }
$p_name=$val['p_name'];
$p_type=$val['p_type'];
$p_explain=$val['p_explain'];
       echo "\n".($k+1).":参数:".$p_name."\n";
         echo "类型:".$p_type."\n";
         echo "说明:".$p_explain;
}
}if($type==2){
$list=array_reverse($list);
$name=$list[$n-1]["name"];
$infos = $db->select("api_list","*",["name"=>"$name"]);
$info = $infos[0]["example"];
$data=file_get_contents($info);
echo $data;
}if($type==null){
$list=array_reverse($list);
        foreach($list as $k=>$val){
            $c=count($list);
            $name=$val['name'];
            echo ($k+1).":".$name."\n";
            }

}
if($type==3){
$list=array_reverse($list);
$name=$list[$n-1]["name"];
$url="http://xiaobai.klizi.cn/doc.php?name=".urlencode($name);
print_r("(".$url.")");
}if($type==4){
$keyword=$_REQUEST["keyword"]?:"QQ";
$mysql=@new mysqli("localhost",$dbconfig["username"],$dbconfig["password"],$dbconfig["database_name"]);
$searchData=$mysql->query("SELECT * FROM api_list WHERE name LIKE '%%".$keyword."%%' ");
$searchApi=array();
while($records=mysqli_fetch_array($searchData))
{
$searchApi[]=$records;
}
        foreach($searchApi as $k=>$val){
             $name=$val['name'];
            echo ($k+1).":".$name."\n";
            }
}if($type==5){
$keyword=$_REQUEST["keyword"];
$mysql=@new mysqli("localhost",$dbconfig["username"],$dbconfig["password"],$dbconfig["database_name"]);
$searchData=$mysql->query("SELECT * FROM api_list WHERE name LIKE '%%".$keyword."%%' ");
$searchApi=array();
while($records=mysqli_fetch_array($searchData))
{
$searchApi[]=$records;
}
$name=$searchApi[$n-1]["name"];
$infos = $db->select("api_list","*",["name"=>"$name"]);
$info = $infos[0];
$list_id=$info["id"];
$request = $db->select("api_parameter","*",["list_id"=>"$list_id","type"=>1]);
$data="接口名称:".$info["name"]."\n接口地址:".$http_type.$_SERVER['HTTP_HOST']."/".$info["url"]."\n返回类型:".$info["back"]."\n请求示例:".$http_type.$_SERVER['HTTP_HOST']."/".$info["example"]."\n------请求参数------";
print_r($data);
foreach($request as $k=>$val){
    if($val['p_must']==1){
         $p_must="yes";
     }else{
         $p_must="no";
     }
$p_name=$val['p_name'];
$p_type=$val['p_type'];
$p_explain=$val['p_explain'];
       echo "\n".($k+1).":参数:".$p_name."\n";
         echo "类型:".$p_type."\n";
         echo "说明:".$p_explain;
}
}
?>