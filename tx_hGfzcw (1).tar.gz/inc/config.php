<?php
            /*数据库配置*/
            $dbconfig=array(
                "database_type" => "mysql",
                "database_name" => "xiaobai", //数据库名
                "server" =>  "localhost", //数据库服务器
                "username" => "xiaobai", //数据库用户名
                "password" => "cnj.5218013", //数据库密码
                "port" => 3306, //数据库端口
                "charset" => "utf8",
                "logging" => true
            );
            ?>