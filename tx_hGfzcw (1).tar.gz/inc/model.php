<?php
include 'connect.php';
$datas = $db->select("api_web","*");
$model = $datas[0];
@$name = $_GET["name"];
$infos = $db->select("api_list","*",["name"=>"$name"]);
$info = $infos[0];
$list_id = $info["id"];
$request = $db->select("api_parameter","*",["list_id"=>"$list_id","type"=>1]);
$error = $db->select("api_parameter","*",["list_id"=>"$list_id","type"=>3]);
$back = $db->select("api_parameter","*",["list_id"=>"$list_id","type"=>2]);
$list = $db->select("api_list",["name","details"]);
$links =  $db->select("api_links","*");
$ico = ["1.ico","2.ico","3.ico","4.ico","5.ico","6.ico","7.ico","8.ico","9.ico","10.ico","11.ico","12.ico","13.ico","14.ico","15.ico","16.ico","17.ico","18.ico","19.ico","20.ico","21.ico","22.ico"];
