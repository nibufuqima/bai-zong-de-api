<?php
require 'Medoo.php';
use Medoo\Medoo;
include('config.php');
$db = new Medoo($dbconfig);
