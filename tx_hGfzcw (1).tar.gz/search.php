

 <?php
include 'inc/functions.php';
include "inc/common.php";
include "inc/model.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="access/css/mzb.css">
    <title><?php echo $model["title"] ?></title>
    <meta name="Description" content="<?php echo $model["description"] ?>"/>
    <meta name="Keywords" content="<?php echo $model["keywords"] ?>"/>
    <link rel="shortcut icon" href="<?php echo $model["ico"] ?>">
</head>

<body>
    <div class="container-body">
        <div class="content-left">
            <div class="avatar">
                <img src="<?php echo $model["logo"] ?>" class="logo">
            </div>
            <H2 class="name"><?php echo $model["title"] ?></H2>
            <p class="qq">
            <?php
            $number = $db->count('api_list');
            echo "ღ 共收录接口:".$number."个 ღ<br>";
            echo "ღ url为搜索参数 ღ<br>";

                        ?></p>
            <ul class="menu">
                <li class="active">
                </li>
            </ul>
        </div>
    </div>
    <div class="main">
        <div class="container">
<?php 
$keyword=$_REQUEST["url"]?:"QQ";
$mysql=@new mysqli("localhost",$dbconfig["username"],$dbconfig["password"],$dbconfig["database_name"]);
$searchData=$mysql->query("SELECT * FROM api_list WHERE name LIKE '%%".$keyword."%%' ");
$searchApi=array();
while($records=mysqli_fetch_array($searchData))
{
$searchApi[]=$records;
}
foreach($searchApi as $k=>$val): 
$c=count($list);
$name=$val['name'];
$details=$val['details'];
?> 
             <div class='box'>
                <a class='img' href='doc.php?name=<?php echo $name;?>'>
                   <img src='access/icos/<?php echo $ico[mt_rand(0, count($ico) - 1)] ?>' />
                   <div class='titleName'>
                        <div class='namee'>
                            <p><?php echo $name;?></p>
                        </div>
                       <div class='subname'>
                            <p><?php echo $details;?></p>
                        </div>
                    </div>
                </a>
           </div>
           <?php endforeach; ?>
        </div>
    </div>
    <div class="index-link">
        <div class="link-title">
            <h3>友情链接</h3>
        </div>
        <ul>
            <?php 
             foreach($links as $k=>$val){
                $link_name=$val['name'];
                $link_url=$val['url'];
                $link_jian=$val['jian'];
                echo "<li><a href='$link_url' tppabs title='$link_jian' target='_blank'>$link_name</a></li>";
             };
            ?>
        </ul>
    </div>
    <footer>
        <span class="footer-left"><?php echo $model["beian"] ?></a></span>
        <span class="footer-right">
        <?php echo $model["notice"] ?>
    </span>
    </footer>
</body>
</script>
</html>

