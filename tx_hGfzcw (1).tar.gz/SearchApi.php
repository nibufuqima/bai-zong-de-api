<?php
include 'inc/functions.php';
include "inc/common.php";
include "inc/model.php";
?><?php 
$keyword=$_REQUEST["url"]?:"QQ";
$mysql=@new mysqli("localhost",$dbconfig["username"],$dbconfig["password"],$dbconfig["database_name"]);
$searchData=$mysql->query("SELECT * FROM api_list WHERE name LIKE '%%".$keyword."%%' ");
$searchApi=array();
while($records=mysqli_fetch_array($searchData))
{
$searchApi[]=$records;
}
$array=array('data'=>$searchApi);
print_r(json_encode($array));
/*foreach($searchApi as $k=>$val): 
$c=count($list);
$name=$val['name'];
$details=$val['details'];*/
?>