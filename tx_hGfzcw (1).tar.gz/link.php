<?php
include 'inc/functions.php';
include "inc/common.php";
include 'inc/model.php';
?><!doctype html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
		content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>友情链接 - <?php echo $model["title"] ?></title>
    <meta name="Description" content="<?php echo $model["description"] ?>"/>
    <meta name="Keywords" content="<?php echo $model["keywords"]."-".$info["name"] ?>"/>
	<meta name="founder" content="<?php echo $model["title"] ?>">
	<meta name="referrer" content="no-referrer">
	<link href="access/doc/other/css/site.min.css" rel="stylesheet">
	<link href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="access/doc/other/css/layui.css">
	<link href="access/doc/other/css/oneui.css" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo $model["ico"] ?>">
	<script src="access/doc/other/js/jquery.min.js"></script>
	<script src="access/doc/layui/layui.all.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
	<header class="site-header">
		<nav class="nav_jsxs">
			<span style="float: left;"><a class="logo_jsxs" href=""></a></span>
			<a href="../">首页</a>
		</nav>
		<div class="box-text">
			<h1><?php echo $model["title"] ?></h1>
			<p>稳定、快速、免费的 API 接口服务<br>
				<span class="package-amount">共收录了
					<strong><?php
            $number = $db->count('api_list');
            echo $number;
            ?></strong>个接口
				</span>
			</p>
		</div>
	</header>
	<section class="content content-boxed">
              <?php 
             foreach($links as $k=>$val){
                 echo '<div class="list-group">';
                echo '<a href="'.$val["url"].'" class="list-group-item list-group-item-action">'.$val["name"].'<br><br>'.$val["jian"].'';
             };
            ?>
    
    </a>
  </div>
</section>
</body>
</html>